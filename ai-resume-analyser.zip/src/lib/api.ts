import { ResumeAnalysis, User, JobMatchResult } from '../types.js';

const BASE_URL = '/api';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem('404codex_token') || sessionStorage.getItem('404codex_token');
  } catch {
    return null;
  }
}

function getAuthHeaders(explicitToken?: string): Record<string, string> {
  const token = explicitToken || getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export async function fetchHealth() {
  try {
    const res = await fetch(`${BASE_URL}/health`);
    return await res.json();
  } catch {
    return { status: 'offline', hasGeminiKey: false };
  }
}

export async function getSampleDemo(): Promise<ResumeAnalysis> {
  const res = await fetch(`${BASE_URL}/demo/sample`);
  if (!res.ok) throw new Error('Failed to load demo sample');
  const data = await res.json();
  return data.analysis;
}

export async function registerUser(
  name: string,
  email: string,
  password: string,
  targetRole?: string,
  experienceLevel?: string
): Promise<{ user: User; token: string }> {
  const res = await fetch(`${BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password, targetRole, experienceLevel })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Registration failed');
  return data;
}

export async function loginUser(email: string, password: string): Promise<{ user: User; token: string }> {
  const res = await fetch(`${BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Login failed');
  return data;
}

export async function logoutUser(token?: string): Promise<void> {
  try {
    await fetch(`${BASE_URL}/auth/logout`, {
      method: 'POST',
      headers: getAuthHeaders(token)
    });
  } catch (err) {
    console.warn('Logout notification error:', err);
  }
}

export async function forgotPassword(email: string): Promise<{ message: string; tempPasswordHint?: string }> {
  const res = await fetch(`${BASE_URL}/auth/forgot-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to request password reset');
  return data;
}

export async function getCurrentUser(token?: string): Promise<User | null> {
  try {
    const headers = getAuthHeaders(token);
    const res = await fetch(`${BASE_URL}/auth/me`, { headers });
    if (!res.ok) return null;
    const data = await res.json();
    return data.user || null;
  } catch {
    return null;
  }
}

export async function updateUserProfile(profile: Partial<User>, token?: string): Promise<User> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/auth/profile`, {
    method: 'PUT',
    headers,
    body: JSON.stringify(profile)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update profile');
  return data.user;
}

export async function uploadResumeFile(
  file: File,
  token?: string
): Promise<{ resumeId: string; fileName: string; fileSize: number; rawText: string; parsedData: any; fileUrl: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = (reader.result as string).split(',')[1];
        const headers = getAuthHeaders(token);
        const res = await fetch(`${BASE_URL}/resume/upload`, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            fileName: file.name,
            fileType: file.type || 'application/pdf',
            fileBase64: base64
          })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Resume upload failed');
        resolve(data);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file from disk'));
    reader.readAsDataURL(file);
  });
}

export async function uploadResumeText(
  fileName: string,
  rawTextContent: string,
  token?: string
): Promise<{ resumeId: string; fileName: string; fileSize: number; rawText: string; parsedData: any; fileUrl: string }> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/resume/upload`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      fileName,
      fileType: 'text/plain',
      rawTextContent
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Resume text upload failed');
  return data;
}

export async function runResumeAnalysis(
  payload: {
    resumeId?: string;
    fileName: string;
    fileSize: number;
    rawText: string;
    parsedData?: any;
  },
  token?: string
): Promise<ResumeAnalysis> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/resume/analyze`, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Analysis failed');
  return data.analysis;
}

export async function reanalyzeResumeById(id: string, token?: string): Promise<ResumeAnalysis> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/resume/${id}/reanalyze`, {
    method: 'POST',
    headers
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Re-analysis failed');
  return data.analysis;
}

export async function getAllResumes(token?: string): Promise<ResumeAnalysis[]> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/resume`, { headers });
  if (!res.ok) {
    if (res.status === 401) return [];
    throw new Error('Failed to fetch resumes');
  }
  const data = await res.json();
  return data.resumes || [];
}

export async function getResumeById(id: string, token?: string): Promise<ResumeAnalysis> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/resume/${id}`, { headers });
  if (!res.ok) throw new Error('Resume not found');
  const data = await res.json();
  return data.analysis || data.resume;
}

export async function deleteResumeById(id: string, token?: string): Promise<boolean> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/resume/${id}`, {
    method: 'DELETE',
    headers
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to delete resume');
  }
  return true;
}

export function getResumeFileDownloadUrl(resumeId: string): string {
  const token = getStoredToken();
  return `${BASE_URL}/resume/${resumeId}/file${token ? `?token=${encodeURIComponent(token)}` : ''}`;
}

export async function matchJobDescription(
  payload: {
    resumeId: string;
    jobTitle: string;
    companyName?: string;
    jobDescription: string;
  },
  token?: string
): Promise<JobMatchResult> {
  const headers = getAuthHeaders(token);
  const res = await fetch(`${BASE_URL}/job-match`, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Job match failed');
  return data.matchResult;
}

export async function regenerateSummary(payload: {
  summary: string;
  tone: 'Professional' | 'Technical' | 'Concise' | 'Recruiter-Friendly';
  skills?: string[];
}): Promise<string> {
  const res = await fetch(`${BASE_URL}/ai/summary`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Summary generation failed');
  return data.summary;
}
