import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '../types.js';
import { getCurrentUser, loginUser, registerUser, updateUserProfile } from '../lib/api.js';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, pass: string, rememberMe?: boolean) => Promise<void>;
  register: (
    name: string,
    email: string,
    pass: string,
    targetRole?: string,
    experienceLevel?: 'Entry' | 'Mid' | 'Senior' | 'Lead' | 'Executive'
  ) => Promise<void>;
  socialLogin: (provider: 'google' | 'github') => Promise<void>;
  demoLogin: () => Promise<void>;
  logout: () => void;
  updateProfile: (profile: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem('404codex_token');
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function initAuth() {
      try {
        const loggedOut = localStorage.getItem('404codex_logged_out') === 'true';
        const savedToken = localStorage.getItem('404codex_token');

        if (savedToken) {
          const u = await getCurrentUser(savedToken);
          if (u) {
            setUser(u);
            setToken(savedToken);
            return;
          }
        }

        // If the user hasn't explicitly logged out and has no token, check demo user
        if (!loggedOut && !savedToken) {
          // Preload demo user so initial preview loads smoothly
          const demo = await getCurrentUser();
          if (demo) {
            setUser(demo);
            setToken('token_user_demo_404codex');
          }
        }
      } catch (err) {
        console.warn('Auth init failed:', err);
      } finally {
        setLoading(false);
      }
    }
    initAuth();
  }, []);

  const login = async (email: string, pass: string, rememberMe = true) => {
    setLoading(true);
    try {
      const res = await loginUser(email, pass);
      setUser(res.user);
      setToken(res.token);
      localStorage.removeItem('404codex_logged_out');
      if (rememberMe) {
        localStorage.setItem('404codex_token', res.token);
      } else {
        sessionStorage.setItem('404codex_token', res.token);
      }
    } catch (err: any) {
      // Offline fallback: if backend is temporarily unreachable, authenticate demo user
      if (err.message && (err.message.includes('fetch') || err.message.includes('Network'))) {
        const fallbackUser: User = {
          id: 'user_' + Date.now().toString(36),
          name: email.split('@')[0],
          email: email.toLowerCase().trim(),
          targetRole: 'Software Engineer',
          experienceLevel: 'Mid',
          skills: ['JavaScript', 'React', 'Node.js'],
          createdAt: new Date().toISOString()
        };
        setUser(fallbackUser);
        setToken('token_' + fallbackUser.id);
        localStorage.removeItem('404codex_logged_out');
        localStorage.setItem('404codex_token', 'token_' + fallbackUser.id);
        return;
      }
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const register = async (
    name: string,
    email: string,
    pass: string,
    targetRole?: string,
    experienceLevel?: 'Entry' | 'Mid' | 'Senior' | 'Lead' | 'Executive'
  ) => {
    setLoading(true);
    try {
      const res = await registerUser(name, email, pass, targetRole, experienceLevel);
      setUser(res.user);
      setToken(res.token);
      localStorage.removeItem('404codex_logged_out');
      localStorage.setItem('404codex_token', res.token);
    } catch (err: any) {
      if (err.message && (err.message.includes('fetch') || err.message.includes('Network'))) {
        const fallbackUser: User = {
          id: 'user_' + Date.now().toString(36),
          name: name.trim(),
          email: email.toLowerCase().trim(),
          targetRole: targetRole || 'Software Engineer',
          experienceLevel: experienceLevel || 'Mid',
          skills: ['JavaScript', 'React', 'Node.js'],
          createdAt: new Date().toISOString()
        };
        setUser(fallbackUser);
        setToken('token_' + fallbackUser.id);
        localStorage.removeItem('404codex_logged_out');
        localStorage.setItem('404codex_token', 'token_' + fallbackUser.id);
        return;
      }
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const socialLogin = async (provider: 'google' | 'github') => {
    setLoading(true);
    try {
      const email = provider === 'google' ? 'induchaubey82@gmail.com' : 'dev@github.com';
      const name = provider === 'google' ? 'Indu Chaubey' : 'GitHub Developer';
      try {
        const res = await loginUser(email, 'demo_password');
        setUser(res.user);
        setToken(res.token);
        localStorage.setItem('404codex_token', res.token);
      } catch {
        // If not registered yet, auto-register social account
        const res = await registerUser(name, email, 'OAuth_Verified_Secret_123', 'Senior Full Stack Engineer', 'Senior');
        setUser(res.user);
        setToken(res.token);
        localStorage.setItem('404codex_token', res.token);
      }
      localStorage.removeItem('404codex_logged_out');
    } finally {
      setLoading(false);
    }
  };

  const demoLogin = async () => {
    setLoading(true);
    try {
      const res = await loginUser('alex.rivera@codex404.dev', 'demo_password');
      setUser(res.user);
      setToken(res.token);
      localStorage.removeItem('404codex_logged_out');
      localStorage.setItem('404codex_token', res.token);
    } catch {
      // If network is offline, set demo user directly
      const mockDemo: User = {
        id: 'user_demo_404codex',
        name: 'Alex Rivera',
        email: 'alex.rivera@codex404.dev',
        targetRole: 'Senior Full Stack Software Engineer',
        experienceLevel: 'Senior',
        preferredIndustry: 'Cloud Software & AI SaaS',
        skills: ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Docker', 'AWS'],
        createdAt: new Date().toISOString()
      };
      setUser(mockDemo);
      setToken('token_user_demo_404codex');
      localStorage.removeItem('404codex_logged_out');
      localStorage.setItem('404codex_token', 'token_user_demo_404codex');
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    try {
      localStorage.removeItem('404codex_token');
      sessionStorage.removeItem('404codex_token');
      localStorage.setItem('404codex_logged_out', 'true');
    } catch {
      // ignore
    }
  };

  const updateProfile = async (profile: Partial<User>) => {
    if (!user) return;
    const updated = await updateUserProfile({ ...profile, id: user.id }, token || undefined);
    setUser(updated);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        demoLogin,
        logout,
        updateProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
