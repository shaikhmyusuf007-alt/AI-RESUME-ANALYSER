export interface User {
  id: string;
  name: string;
  email: string;
  targetRole?: string;
  experienceLevel?: 'Entry' | 'Mid' | 'Senior' | 'Lead' | 'Executive';
  preferredIndustry?: string;
  skills?: string[];
  createdAt: string;
}

export interface ScoreBreakdown {
  overall: number;
  atsCompatibility: number;
  skills: number;
  experience: number;
  projects: number;
  education: number;
  formatting: number;
  keywords: number;
}

export interface SkillCategory {
  name: string;
  skills: {
    name: string;
    level: number; // 0 - 100
    category: 'Technical' | 'Soft' | 'Tools' | 'Frameworks' | 'Languages' | 'Other';
    verifiedInResume: boolean;
  }[];
}

export interface AIRecommendation {
  id: string;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  category: 'Impact' | 'Keywords' | 'Formatting' | 'Structure' | 'Skills';
  problem: string;
  whyItMatters: string;
  suggestedImprovement: string;
  beforeExample?: string;
  afterExample?: string;
}

export interface JobRoleRecommendation {
  id: string;
  role: string;
  matchPercentage: number;
  description: string;
  requiredSkills: string[];
  matchingSkills: string[];
  missingSkills: string[];
  salaryRange: string;
  demandLevel: 'High' | 'Very High' | 'Moderate';
}

export interface ATSCheckItem {
  id: string;
  title: string;
  status: 'passed' | 'warning' | 'failed';
  description: string;
  scoreImpact: number;
  recommendation: string;
}

export interface ParsedResumeData {
  name: string;
  email: string;
  phone: string;
  location: string;
  linkedin?: string;
  github?: string;
  portfolio?: string;
  summary: string;
  education: {
    degree: string;
    institution: string;
    year: string;
    gpa?: string;
  }[];
  experience: {
    role: string;
    company: string;
    period: string;
    highlights: string[];
  }[];
  projects: {
    title: string;
    techStack: string[];
    description: string;
    link?: string;
  }[];
  skills: {
    technical: string[];
    soft: string[];
    tools: string[];
    frameworks: string[];
    languages: string[];
  };
  certifications: string[];
  achievements: string[];
  extracurricular: string[];
  rawText: string;
}

export interface ResumeAnalysis {
  id: string;
  resumeId: string;
  resumeFileName: string;
  fileSize: number;
  uploadedAt: string;
  isDemo?: boolean;
  scores: ScoreBreakdown;
  parsedData: ParsedResumeData;
  strengths: string[];
  weaknesses: string[];
  recommendations: AIRecommendation[];
  skillsBreakdown: SkillCategory[];
  missingRecommendedSkills: {
    role: string;
    skills: string[];
  }[];
  jobRoleRecommendations: JobRoleRecommendation[];
  atsChecks: ATSCheckItem[];
  atsExplanation: {
    summary: string;
    parsedWordCount: number;
    detectedHeadings: string[];
    quantifiableMetricsFound: number;
    actionVerbsCount: number;
    readabilityScore: string;
  };
  professionalSummary: {
    original: string;
    tones: {
      Professional: string;
      Technical: string;
      Concise: string;
      'Recruiter-Friendly': string;
    };
    currentTone: 'Professional' | 'Technical' | 'Concise' | 'Recruiter-Friendly';
  };
}

export interface JobMatchResult {
  id: string;
  resumeId: string;
  jobTitle: string;
  companyName?: string;
  jobDescription: string;
  overallMatchScore: number;
  matchPercentage: number;
  matchingSkills: string[];
  missingSkills: string[];
  matchingKeywords: string[];
  missingKeywords: string[];
  experienceMatch: {
    score: number;
    status: 'Strong' | 'Moderate' | 'Low';
    notes: string;
  };
  educationMatch: {
    score: number;
    status: 'Qualified' | 'Matches Requirements' | 'Gap Detected';
    notes: string;
  };
  recommendations: string[];
  analyzedAt: string;
}

export interface UserReview {
  id: string;
  userId: string;
  userName: string;
  userRole?: string;
  rating: number; // 1 to 5
  reviewText: string;
  isApproved: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ReviewsResponse {
  reviews: UserReview[];
  averageRating: number;
  totalReviews: number;
  ratingDistribution: Record<number, number>;
}
