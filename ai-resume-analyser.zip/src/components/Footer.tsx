import React from 'react';
import { Sparkles, Heart, Shield, Terminal, ExternalLink } from 'lucide-react';

export const Footer: React.FC<{ onNavigate: (view: string) => void }> = ({ onNavigate }) => {
  return (
    <footer className="w-full border-t border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 py-12 px-4 sm:px-6 lg:px-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
        {/* Brand info */}
        <div className="md:col-span-2 space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-bold text-slate-900 dark:text-white text-base">AI Resume Analyser</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-500/30">
              Team 404_codeX
            </span>
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-400 max-w-md leading-relaxed">
            “Turn your resume into your career roadmap.” AI-powered ATS scoring, skill gap detection,
            and role matching engineered for modern tech talent.
          </p>
          <div className="flex items-center gap-4 text-xs text-slate-500 pt-2">
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400" /> Secure in-memory parser
            </span>
            <span className="flex items-center gap-1">
              <Terminal className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" /> Gemini 3.8 Flash AI layer
            </span>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-200 mb-3">
            Product Features
          </h4>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={() => onNavigate('analyze')} className="hover:text-slate-900 dark:hover:text-white transition-colors">
                Resume ATS Scanner
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('job-matcher')} className="hover:text-slate-900 dark:hover:text-white transition-colors">
                Job Match Analyzer
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('skill-gap')} className="hover:text-slate-900 dark:hover:text-white transition-colors">
                Skill Gap Matrix
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('suggestions')} className="hover:text-slate-900 dark:hover:text-white transition-colors">
                Actionable Recommendations
              </button>
            </li>
          </ul>
        </div>

        {/* Hackathon & Legal */}
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-200 mb-3">
            Hackathon & Team
          </h4>
          <ul className="space-y-2 text-sm">
            <li className="text-slate-700 dark:text-slate-300 font-medium">Team 404_codeX</li>
            <li>
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white transition-colors"
              >
                GitHub Repository <ExternalLink className="w-3 h-3" />
              </a>
            </li>
            <li className="text-xs text-slate-500 pt-1">
              Privacy Policy • Terms of Service
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-6 border-t border-slate-200 dark:border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <p>© 2026 AI Resume Analyser. Built by Team 404_codeX. All rights reserved.</p>
        <p className="flex items-center gap-1">
          Crafted with <Heart className="w-3 h-3 text-rose-500 inline fill-rose-500" /> for Next-Gen Engineers
        </p>
      </div>
    </footer>
  );
};
