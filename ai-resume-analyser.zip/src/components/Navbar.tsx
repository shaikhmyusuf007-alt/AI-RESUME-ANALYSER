import React from 'react';
import { Sparkles, Sun, Moon, LogIn, UserPlus, LogOut, LayoutDashboard, ArrowRight, ShieldCheck, PlayCircle, User as UserIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useTheme } from '../context/ThemeContext.js';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onTryDemo: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onTryDemo
}) => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className={`sticky top-0 z-40 w-full border-b transition-colors duration-200 backdrop-blur-md ${
      theme === 'dark'
        ? 'border-slate-800/80 bg-slate-950/90 text-slate-100'
        : 'border-slate-200 bg-white/90 text-slate-900 shadow-sm'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div
          onClick={() => onNavigate('landing')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 p-[1px] shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <div className={`w-full h-full rounded-[11px] flex items-center justify-center ${
              theme === 'dark' ? 'bg-slate-950' : 'bg-white'
            }`}>
              <Sparkles className="w-5 h-5 text-indigo-500 group-hover:text-cyan-500 transition-colors" />
            </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-slate-900 dark:text-white text-base sm:text-lg">
                AI Resume Analyser
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border border-indigo-500/30">
                404_codeX
              </span>
            </div>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:inline">
              Turn your resume into your career roadmap.
            </span>
          </div>
        </div>

        {/* Center Nav Links (when on landing or non-dashboard) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => onNavigate('landing')}
            className={`transition-colors hover:text-slate-900 dark:hover:text-white ${currentView === 'landing' ? 'text-indigo-600 dark:text-indigo-400 font-semibold' : ''}`}
          >
            Features
          </button>
          <button
            onClick={() => onNavigate('landing')}
            className="transition-colors hover:text-slate-900 dark:hover:text-white"
          >
            How It Works
          </button>
          <button
            onClick={() => onNavigate('dashboard')}
            className={`transition-colors hover:text-slate-900 dark:hover:text-white ${currentView === 'dashboard' ? 'text-indigo-600 dark:text-indigo-400 font-semibold' : ''}`}
          >
            Dashboard
          </button>
          <button
            onClick={() => onNavigate('job-matcher')}
            className={`transition-colors hover:text-slate-900 dark:hover:text-white ${currentView === 'job-matcher' ? 'text-indigo-600 dark:text-indigo-400 font-semibold' : ''}`}
          >
            Job Matcher
          </button>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {/* Hackathon Judge Demo Button */}
          <button
            onClick={onTryDemo}
            className="hidden sm:inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 text-amber-300 hover:border-amber-400 transition-all shadow-sm active:scale-95"
          >
            <PlayCircle className="w-3.5 h-3.5" />
            Try Demo
          </button>

          {/* Theme Toggle */}
          <button
            id="theme-toggle-button"
            onClick={toggleTheme}
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className={`p-2 rounded-xl transition-all border cursor-pointer ${
              theme === 'dark'
                ? 'text-amber-400 hover:text-amber-300 bg-slate-900/80 hover:bg-slate-800 border-slate-800 shadow-sm'
                : 'text-indigo-600 hover:text-indigo-700 bg-white hover:bg-slate-100 border-slate-200 shadow-sm'
            }`}
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 transition-transform hover:rotate-45" />
            ) : (
              <Moon className="w-4 h-4 transition-transform hover:-rotate-12" />
            )}
          </button>

          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('profile')}
                className="hidden md:inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800 transition-colors"
                title="View Profile"
              >
                <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-[10px]">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <span className="max-w-[100px] truncate">{user.name}</span>
              </button>

              <button
                onClick={() => onNavigate('dashboard')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-sm shadow-indigo-600/25"
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                Dashboard
              </button>

              <button
                onClick={() => {
                  logout();
                  onNavigate('login');
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                title="Sign Out / Switch Account"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('login')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <LogIn className="w-3.5 h-3.5" />
                Sign In
              </button>
              <button
                onClick={() => onNavigate('register')}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-sm shadow-indigo-600/25 active:scale-95"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Create Account</span>
                <span className="sm:hidden">Sign Up</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
