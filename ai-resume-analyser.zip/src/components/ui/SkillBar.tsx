import React from 'react';
import { CheckCircle2 } from 'lucide-react';

interface SkillBarProps {
  name: string;
  level: number;
  category?: string;
  verified?: boolean;
}

export const SkillBar: React.FC<SkillBarProps> = ({
  name,
  level,
  category,
  verified = true
}) => {
  // Generate block visualization: 10 blocks (e.g. 9 filled, 1 empty)
  const filledBlocks = Math.round(level / 10);
  const emptyBlocks = 10 - filledBlocks;
  const blockString = '█'.repeat(filledBlocks) + '░'.repeat(emptyBlocks);

  let barColor = 'bg-indigo-500';
  let textColor = 'text-indigo-400';
  if (level >= 90) {
    barColor = 'bg-emerald-500';
    textColor = 'text-emerald-400';
  } else if (level >= 80) {
    barColor = 'bg-cyan-500';
    textColor = 'text-cyan-400';
  } else if (level >= 70) {
    barColor = 'bg-indigo-500';
    textColor = 'text-indigo-400';
  } else {
    barColor = 'bg-amber-500';
    textColor = 'text-amber-400';
  }

  return (
    <div className="p-3 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-300 dark:border-slate-800/80 hover:border-slate-400 dark:hover:border-slate-700 shadow-sm transition-colors">
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-900 dark:text-slate-200 text-sm">{name}</span>
          {verified && (
            <span className="inline-flex items-center text-[10px] text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-300 dark:border-emerald-500/20 font-semibold">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Verified in resume
            </span>
          )}
          {category && (
            <span className="text-[10px] font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2 py-0.5 rounded">
              {category}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="hidden sm:inline text-slate-500 dark:text-slate-500 select-none tracking-tighter">
            {blockString}
          </span>
          <span className={`font-bold ${textColor}`}>{level}%</span>
        </div>
      </div>

      {/* Graphical Bar */}
      <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${barColor}`}
          style={{ width: `${level}%` }}
        />
      </div>
    </div>
  );
};
