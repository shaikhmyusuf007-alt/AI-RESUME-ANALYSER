import React, { useEffect, useState } from 'react';

interface CircularProgressProps {
  score: number;
  max?: number;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  label?: string;
  sublabel?: string;
  showPercentSymbol?: boolean;
  colorVariant?: 'auto' | 'indigo' | 'emerald' | 'amber' | 'cyan';
}

export const CircularProgress: React.FC<CircularProgressProps> = ({
  score,
  max = 100,
  size = 'md',
  label,
  sublabel,
  showPercentSymbol = false,
  colorVariant = 'auto'
}) => {
  const [animatedScore, setAnimatedScore] = useState(0);

  useEffect(() => {
    let current = 0;
    const step = Math.max(1, Math.round(score / 35));
    const timer = setInterval(() => {
      current += step;
      if (current >= score) {
        setAnimatedScore(score);
        clearInterval(timer);
      } else {
        setAnimatedScore(current);
      }
    }, 20);
    return () => clearInterval(timer);
  }, [score]);

  const percentage = Math.min(100, Math.max(0, (score / max) * 100));

  const dimMap = {
    sm: { size: 90, stroke: 7, text: 'text-xl', labelText: 'text-xs' },
    md: { size: 130, stroke: 9, text: 'text-3xl', labelText: 'text-xs' },
    lg: { size: 180, stroke: 12, text: 'text-4xl', labelText: 'text-sm' },
    xl: { size: 220, stroke: 14, text: 'text-5xl', labelText: 'text-base' }
  };

  const { size: svgSize, stroke, text: textClass, labelText } = dimMap[size];
  const radius = (svgSize - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  let strokeColor = '#6366f1'; // indigo
  let badgeColor = 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20';

  if (colorVariant === 'auto') {
    if (percentage >= 80) {
      strokeColor = '#10b981'; // emerald
      badgeColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
    } else if (percentage >= 65) {
      strokeColor = '#f59e0b'; // amber
      badgeColor = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
    } else {
      strokeColor = '#f43f5e'; // rose
      badgeColor = 'text-rose-400 bg-rose-500/10 border-rose-500/20';
    }
  } else if (colorVariant === 'emerald') {
    strokeColor = '#10b981';
    badgeColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
  } else if (colorVariant === 'cyan') {
    strokeColor = '#06b6d4';
    badgeColor = 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20';
  }

  const getTier = (val: number) => {
    if (val >= 85) return 'Excellent';
    if (val >= 75) return 'Competitive';
    if (val >= 60) return 'Needs Work';
    return 'Critical Gaps';
  };

  return (
    <div className="flex flex-col items-center justify-center relative">
      <div className="relative flex items-center justify-center">
        <svg width={svgSize} height={svgSize} className="rotate-[-90deg] transition-all duration-700">
          {/* Background track */}
          <circle
            cx={svgSize / 2}
            cy={svgSize / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={stroke}
            className="text-slate-800/80 dark:text-slate-800"
            fill="transparent"
          />
          {/* Active progress */}
          <circle
            cx={svgSize / 2}
            cy={svgSize / 2}
            r={radius}
            stroke={strokeColor}
            strokeWidth={stroke}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="transparent"
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Center label */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className={`font-bold font-mono tracking-tight text-slate-900 dark:text-white ${textClass}`}>
            {animatedScore}
            {showPercentSymbol ? '%' : ''}
          </span>
          {sublabel && (
            <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {sublabel}
            </span>
          )}
        </div>
      </div>

      {label && (
        <div className="mt-2 text-center">
          <p className="font-semibold text-slate-800 dark:text-slate-200 text-sm">{label}</p>
          <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[11px] font-medium border ${badgeColor}`}>
            {getTier(score)}
          </span>
        </div>
      )}
    </div>
  );
};
