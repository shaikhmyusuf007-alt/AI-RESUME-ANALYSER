import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ScoreCardProps {
  title: string;
  score: number;
  icon: LucideIcon;
  description: string;
  weight?: string;
  highlight?: boolean;
}

export const ScoreCard: React.FC<ScoreCardProps> = ({
  title,
  score,
  icon: Icon,
  description,
  weight,
  highlight = false
}) => {
  let color = 'from-indigo-500 to-blue-600';
  let badgeColor = 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20';
  let barColor = 'bg-indigo-500';

  if (score >= 85) {
    color = 'from-emerald-500 to-teal-600';
    badgeColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
    barColor = 'bg-emerald-500';
  } else if (score >= 70) {
    color = 'from-amber-500 to-orange-600';
    badgeColor = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
    barColor = 'bg-amber-500';
  } else {
    color = 'from-rose-500 to-pink-600';
    badgeColor = 'text-rose-400 bg-rose-500/10 border-rose-500/20';
    barColor = 'bg-rose-500';
  }

  return (
    <div
      className={`p-5 rounded-2xl border transition-all duration-200 ${
        highlight
          ? 'bg-white dark:bg-slate-900/90 border-indigo-500/50 shadow-md shadow-indigo-500/10 ring-1 ring-indigo-500/30'
          : 'bg-white dark:bg-slate-900/50 border-slate-300 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-700 shadow-sm'
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700/60 text-indigo-600 dark:text-indigo-400">
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm">{title}</h4>
            {weight && <p className="text-[11px] font-medium text-slate-600 dark:text-slate-400">{weight}</p>}
          </div>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">{score}</span>
          <span className="text-xs text-slate-500 dark:text-slate-500 font-mono">/100</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mt-4">
        <div className="h-2 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ${barColor}`}
            style={{ width: `${score}%` }}
          />
        </div>
      </div>

      <p className="mt-3 text-xs font-medium text-slate-800 dark:text-slate-300 leading-relaxed">{description}</p>
    </div>
  );
};
