import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle, Loader2, Sparkles, BrainCircuit, FileSearch, ShieldCheck, Cpu, Target } from 'lucide-react';

interface LoadingStagesProps {
  onComplete?: () => void;
  isReady?: boolean;
  error?: string | null;
  durationMs?: number;
}

const STAGES = [
  {
    step: 1,
    title: 'Extracting resume content',
    desc: 'Parsing text buffers, contact anchors, and layout blocks...',
    icon: FileSearch
  },
  {
    step: 2,
    title: 'Understanding your experience',
    desc: 'Analyzing role progression, tenure, and responsibility impact...',
    icon: BrainCircuit
  },
  {
    step: 3,
    title: 'Evaluating ATS compatibility',
    desc: 'Checking Taleo & Workday parsing rules, headings, and table bounds...',
    icon: ShieldCheck
  },
  {
    step: 4,
    title: 'Identifying skills',
    desc: 'Extracting technical frameworks, languages, and competencies...',
    icon: Cpu
  },
  {
    step: 5,
    title: 'Comparing industry keywords',
    desc: 'Benchmarking keyword density against top hiring profiles...',
    icon: Target
  },
  {
    step: 6,
    title: 'Generating recommendations',
    desc: 'Formulating high-impact action bullets and tailored job matches...',
    icon: Sparkles
  }
];

export const LoadingStages: React.FC<LoadingStagesProps> = ({
  onComplete,
  isReady = true,
  error = null,
  durationMs = 3000
}) => {
  const [currentStageIndex, setCurrentStageIndex] = useState(0);

  useEffect(() => {
    const stageDuration = durationMs / STAGES.length;
    const interval = setInterval(() => {
      setCurrentStageIndex((prev) => {
        if (prev < STAGES.length - 1) {
          return prev + 1;
        } else {
          return prev;
        }
      });
    }, stageDuration);

    return () => clearInterval(interval);
  }, [durationMs]);

  // Once at final stage AND isReady is true, trigger onComplete
  useEffect(() => {
    if (currentStageIndex >= STAGES.length - 1 && isReady && onComplete && !error) {
      const timeout = setTimeout(() => {
        onComplete();
      }, 500);
      return () => clearTimeout(timeout);
    }
  }, [currentStageIndex, isReady, onComplete, error]);

  const progressPercent = Math.round(((currentStageIndex + 1) / STAGES.length) * 100);

  return (
    <div className="flex flex-col items-center justify-center min-h-[480px] p-6 text-center max-w-xl mx-auto">
      {/* Glowing AI Orb */}
      <div className="relative mb-8">
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 to-cyan-400 blur-xl opacity-40 animate-pulse" />
        <div className="relative w-24 h-24 rounded-2xl bg-slate-900 border border-slate-700/80 flex items-center justify-center shadow-2xl">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
          >
            <Sparkles className="w-12 h-12 text-indigo-400" />
          </motion.div>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-white mb-2 tracking-tight">
        AI is analyzing your resume…
      </h2>
      <p className="text-slate-400 text-sm mb-8">
        Team 404_codeX engine is transforming your experience into a career roadmap.
      </p>

      {/* Progress bar */}
      <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden mb-6 border border-slate-700/50">
        <motion.div
          className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400 rounded-full"
          animate={{ width: `${progressPercent}%` }}
          transition={{ ease: 'easeOut', duration: 0.3 }}
        />
      </div>

      {/* Stages List */}
      <div className="w-full space-y-3 text-left">
        {STAGES.map((stage, idx) => {
          const isDone = idx < currentStageIndex;
          const isCurrent = idx === currentStageIndex;
          const isPending = idx > currentStageIndex;
          const Icon = stage.icon;

          return (
            <div
              key={stage.step}
              className={`p-3.5 rounded-xl border transition-all duration-300 flex items-center gap-3.5 ${
                isCurrent
                  ? 'bg-indigo-500/10 border-indigo-500/40 shadow-md shadow-indigo-500/5'
                  : isDone
                  ? 'bg-slate-900/40 border-slate-800 text-slate-300'
                  : 'bg-slate-900/20 border-slate-800/40 text-slate-600 opacity-60'
              }`}
            >
              <div className="shrink-0">
                {isDone ? (
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                ) : isCurrent ? (
                  <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
                ) : (
                  <div className="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center text-[10px] text-slate-500 font-mono">
                    {stage.step}
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4
                    className={`text-sm font-semibold truncate ${
                      isCurrent
                        ? 'text-white'
                        : isDone
                        ? 'text-slate-200'
                        : 'text-slate-500'
                    }`}
                  >
                    Stage {stage.step}: {stage.title}
                  </h4>
                  {isCurrent && (
                    <span className="text-[10px] font-mono text-indigo-400 font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20">
                      Processing
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 truncate mt-0.5">{stage.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
