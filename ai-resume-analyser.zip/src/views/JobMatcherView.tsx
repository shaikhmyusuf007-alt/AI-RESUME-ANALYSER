import React, { useState } from 'react';
import {
  Briefcase,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Search,
  Building,
  Target,
  Layers,
  Award,
  RefreshCw
} from 'lucide-react';
import { ResumeAnalysis, JobMatchResult } from '../types.js';
import { matchJobDescription } from '../lib/api.js';
import { CircularProgress } from '../components/ui/CircularProgress.js';

interface JobMatcherViewProps {
  currentResume?: ResumeAnalysis | null;
  resumes: ResumeAnalysis[];
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const SAMPLE_JOB_DESCRIPTIONS = [
  {
    title: 'Senior Full Stack Software Engineer',
    company: 'Stripe / Vercel Partner',
    desc: `We are looking for a Senior Full Stack Engineer with 4+ years of hands-on experience building mission-critical web platforms.
Required Qualifications:
• Mastery of TypeScript, React, Next.js, and modern CSS (Tailwind).
• Proven background architecting backend microservices in Node.js, Express, or Python.
• Strong knowledge of relational databases (PostgreSQL) and caching (Redis).
• Hands-on proficiency with cloud infrastructure: Docker, AWS (ECS, RDS, S3), CI/CD pipelines.
• Experience designing low-latency REST and GraphQL APIs handling high concurrency.
• Bonus: Familiarity with Kubernetes, Terraform (IaC), and distributed event queues.`
  },
  {
    title: 'Staff Frontend Platform Architect',
    company: 'Linear / Figma Ecosystem',
    desc: `Seeking a Staff Frontend Architect to lead our web client infrastructure, sub-50ms performance budgets, and design system.
Key Requirements:
• Deep expertise in React 19, TypeScript, state management, and real-time WebSockets.
• Mastery of web performance: Core Web Vitals, SSR/SSG caching, bundle-splitting, canvas rendering.
• Experience mentoring junior and mid-level software engineers and driving cross-team technical RFCs.
• Excellent eye for polished design, micro-interactions, and accessibility standards.`
  },
  {
    title: 'Cloud DevOps & Site Reliability Engineer',
    company: 'Scale AI Cloud Infrastructure',
    desc: `We need a DevOps/SRE Engineer to maintain high-availability container fleets and telemetry infrastructure.
Requirements:
• 3+ years experience with Docker, Kubernetes, and Terraform Infrastructure as Code.
• Advanced proficiency in AWS cloud services (EKS, IAM, CloudWatch, VPC).
• Proven track record building automated CI/CD pipelines in GitHub Actions.
• Experience with Datadog or Prometheus/Grafana observability suites.`
  }
];

export const JobMatcherView: React.FC<JobMatcherViewProps> = ({
  currentResume,
  resumes,
  onShowToast
}) => {
  const [selectedResumeId, setSelectedResumeId] = useState<string>(
    currentResume?.id || resumes[0]?.id || 'demo_analysis_404codex'
  );
  const [jobTitle, setJobTitle] = useState<string>('Senior Full Stack Software Engineer');
  const [companyName, setCompanyName] = useState<string>('Tech Innovators Inc.');
  const [jobDescription, setJobDescription] = useState<string>(SAMPLE_JOB_DESCRIPTIONS[0].desc);
  const [isMatching, setIsMatching] = useState<boolean>(false);
  const [matchResult, setMatchResult] = useState<JobMatchResult | null>(null);

  // Automatically keep selectedResumeId synchronized with currentResume if it updates
  React.useEffect(() => {
    if (currentResume?.id) {
      setSelectedResumeId(currentResume.id);
    } else if (resumes.length > 0 && !resumes.some(r => r.id === selectedResumeId)) {
      setSelectedResumeId(resumes[0].id);
    }
  }, [currentResume?.id, resumes]);

  const activeTargetResume = resumes.find(r => r.id === selectedResumeId) || currentResume || resumes[0];

  const handleSelectSample = (sample: typeof SAMPLE_JOB_DESCRIPTIONS[0]) => {
    setJobTitle(sample.title);
    setCompanyName(sample.company);
    setJobDescription(sample.desc);
  };

  const handleRunMatch = async () => {
    if (!jobDescription || jobDescription.trim().length < 20) {
      onShowToast('Please enter a valid job description with at least 20 characters.', 'error');
      return;
    }

    const targetId = selectedResumeId || activeTargetResume?.id || 'demo_analysis_404codex';

    setIsMatching(true);
    try {
      const result = await matchJobDescription({
        resumeId: targetId,
        jobTitle,
        companyName,
        jobDescription
      });
      setMatchResult(result);
      onShowToast(`Job Match Analysis completed: ${result.matchPercentage}% match!`, 'success');
    } catch (err: any) {
      onShowToast(err.message || 'Job match failed', 'error');
    } finally {
      setIsMatching(false);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
          <Briefcase className="w-3.5 h-3.5 text-indigo-400" />
          <span>AI Job Description Parser & Match Engine</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Target Job Matcher
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Compare your uploaded resume against any job description to compute precision keyword alignment and role readiness.
        </p>
      </div>

      {/* Input Section */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-6">
        {/* Resume Selector & Sample Buttons */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-300">
              Select Resume to Compare
            </label>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={selectedResumeId}
                onChange={(e) => setSelectedResumeId(e.target.value)}
                className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-medium focus:outline-none focus:border-indigo-500"
              >
                {resumes.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.parsedData.name || 'Candidate'} — {r.resumeFileName} ({r.scores.overall} Score)
                  </option>
                ))}
                {resumes.length === 0 && (
                  <option value="demo_analysis_404codex">
                    Alex Rivera — Sample Resume (84 Score)
                  </option>
                )}
              </select>
              {activeTargetResume && (
                <span className="text-[11px] px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-medium flex items-center gap-1.5">
                  <FileText className="w-3 h-3 text-indigo-400" />
                  Active: {activeTargetResume.parsedData.name || 'Candidate'} ({activeTargetResume.scores.overall} Score)
                </span>
              )}
            </div>
          </div>

          <div>
            <span className="block text-[11px] text-slate-400 font-semibold mb-1">
              Or Test with Sample Job Descriptions:
            </span>
            <div className="flex flex-wrap gap-2">
              {SAMPLE_JOB_DESCRIPTIONS.map((sample, i) => (
                <button
                  key={i}
                  onClick={() => handleSelectSample(sample)}
                  className="px-2.5 py-1 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors"
                >
                  {sample.title.split(' ')[0]} {sample.title.split(' ')[1]}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Title & Company */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Job Title
            </label>
            <input
              type="text"
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
              placeholder="e.g. Senior Full Stack Engineer"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Company Name (Optional)
            </label>
            <input
              type="text"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="e.g. Acme Cloud Corp"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Job Description Textarea */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            Paste Job Description (Requirements, Responsibilities, Qualifications)
          </label>
          <textarea
            rows={8}
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            placeholder="Paste the target job description here..."
            className="w-full p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs font-mono leading-relaxed focus:outline-none focus:border-indigo-500 resize-y"
          />
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleRunMatch}
            disabled={isMatching || !jobDescription}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 active:scale-98 disabled:opacity-50"
          >
            {isMatching ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Analyzing Match Against Resume…
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                Analyze Job Match
              </>
            )}
          </button>
        </div>
      </div>

      {/* Results Section */}
      {matchResult && (
        <div className="space-y-8 animate-in fade-in duration-300">
          {/* Top Score Banner */}
          <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-2 text-center md:text-left">
              <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider">
                Alignment Report
              </span>
              <h2 className="text-2xl font-bold text-white">
                {matchResult.jobTitle} {matchResult.companyName ? `at ${matchResult.companyName}` : ''}
              </h2>
              <p className="text-xs text-slate-400 max-w-xl leading-relaxed">
                Resume matches <strong className="text-emerald-400">{matchResult.matchingSkills.length}</strong> required technical skills with an overall fit of <strong className="text-indigo-300">{matchResult.overallMatchScore}%</strong>.
              </p>
            </div>

            <div className="shrink-0 flex items-center justify-center p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <CircularProgress
                score={matchResult.matchPercentage}
                size="md"
                label="Role Match Fit"
                sublabel="MATCH"
                colorVariant="auto"
              />
            </div>
          </div>

          {/* Experience & Education Alignment Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Experience Alignment */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-indigo-400" />
                  <h3 className="font-bold text-sm text-white">Experience Alignment</h3>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${
                  matchResult.experienceMatch?.status === 'Strong'
                    ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                    : matchResult.experienceMatch?.status === 'Moderate'
                    ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                    : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                }`}>
                  {matchResult.experienceMatch?.status || 'Moderate'} ({matchResult.experienceMatch?.score || 75}%)
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {matchResult.experienceMatch?.notes || 'Candidate experience demonstrates foundational relevance to target role requirements.'}
              </p>
            </div>

            {/* Education Alignment */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-indigo-400" />
                  <h3 className="font-bold text-sm text-white">Education & Credentials</h3>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${
                  matchResult.educationMatch?.status === 'Qualified'
                    ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                    : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                }`}>
                  {matchResult.educationMatch?.status || 'Qualified'} ({matchResult.educationMatch?.score || 85}%)
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {matchResult.educationMatch?.notes || 'Academic and professional qualifications satisfy baseline screening criteria.'}
              </p>
            </div>
          </div>

          {/* Skill Comparison Grids */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Matching Skills */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-emerald-500/20 space-y-4">
              <div className="flex items-center justify-between text-emerald-400">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  <h3 className="font-bold text-sm text-white">
                    Matching Skills ({matchResult.matchingSkills.length})
                  </h3>
                </div>
                <span className="text-xs font-mono font-semibold">Verified in Resume</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {matchResult.matchingSkills.length > 0 ? (
                  matchResult.matchingSkills.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-xs font-medium"
                    >
                      ✓ {s}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-500 italic">No direct keyword overlap detected with this JD.</span>
                )}
              </div>
            </div>

            {/* Missing Skills */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-amber-500/20 space-y-4">
              <div className="flex items-center justify-between text-amber-400">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  <h3 className="font-bold text-sm text-white">
                    Missing Skills to Add ({matchResult.missingSkills.length})
                  </h3>
                </div>
                <span className="text-xs font-mono font-semibold">Target Gaps</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {matchResult.missingSkills.length > 0 ? (
                  matchResult.missingSkills.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/20 text-xs font-medium"
                    >
                      + {s}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-emerald-400 font-medium">Outstanding! All identified key skills are present in your resume.</span>
                )}
              </div>
            </div>
          </div>

          {/* Keywords & Recommendations */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Industry Keywords */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Search className="w-4 h-4 text-indigo-400" />
                Industry Keyword Alignment
              </h3>
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-400 font-semibold block mb-1">
                    Matching Keywords:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {matchResult.matchingKeywords.length > 0 ? (
                      matchResult.matchingKeywords.map((k, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px]">
                          {k}
                        </span>
                      ))
                    ) : (
                      <span className="text-slate-500 italic text-[11px]">None identified</span>
                    )}
                  </div>
                </div>

                {matchResult.missingKeywords.length > 0 && (
                  <div>
                    <span className="text-slate-400 font-semibold block mb-1">
                      Missing Recommended Keywords:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {matchResult.missingKeywords.map((k, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-amber-300 text-[11px] border border-amber-500/20">
                          {k}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Recommendations */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                Tailored Recommendations for this Role
              </h3>
              <ul className="space-y-2.5">
                {matchResult.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed">
                    <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-300 flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold">
                      {i + 1}
                    </span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
