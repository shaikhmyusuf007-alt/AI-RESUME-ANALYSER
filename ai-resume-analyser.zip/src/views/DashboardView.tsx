import React, { useState } from 'react';
import {
  Sparkles,
  UploadCloud,
  Briefcase,
  PlayCircle,
  FileText,
  TrendingUp,
  ShieldCheck,
  Sliders,
  ArrowRight,
  Clock,
  Trash2,
  ExternalLink,
  Download,
  RotateCw,
  Award
} from 'lucide-react';
import { ResumeAnalysis } from '../types.js';
import { useAuth } from '../context/AuthContext.js';
import { ScoreCard } from '../components/ui/ScoreCard.js';
import { getResumeFileDownloadUrl, reanalyzeResumeById } from '../lib/api.js';

interface DashboardViewProps {
  resumes: ResumeAnalysis[];
  activeResume: ResumeAnalysis | null;
  onSelectResume: (analysis: ResumeAnalysis) => void;
  onDeleteResume: (id: string) => void;
  onNavigate: (view: string) => void;
  onTryDemo: () => void;
  onUpdateResume?: (updated: ResumeAnalysis) => void;
  onShowToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  resumes,
  activeResume,
  onSelectResume,
  onDeleteResume,
  onNavigate,
  onTryDemo,
  onUpdateResume,
  onShowToast
}) => {
  const { user } = useAuth();
  const [reanalyzingId, setReanalyzingId] = useState<string | null>(null);

  // Use active resume or first resume or fallback to demo
  const current = activeResume || resumes[0];

  const overallScore = current ? current.scores.overall : 0;
  const atsScore = current ? current.scores.atsCompatibility : 0;
  const skillsScore = current ? current.scores.skills : 0;
  const experienceScore = current ? current.scores.experience : 0;

  const handleOpenFile = (r: ResumeAnalysis, e: React.MouseEvent) => {
    e.stopPropagation();
    const targetId = r.resumeId || r.id;
    const url = getResumeFileDownloadUrl(targetId);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleReanalyze = async (r: ResumeAnalysis, e: React.MouseEvent) => {
    e.stopPropagation();
    const targetId = r.resumeId || r.id;
    setReanalyzingId(targetId);
    try {
      if (onShowToast) onShowToast('Re-analyzing resume with AI...', 'info');
      const fresh = await reanalyzeResumeById(targetId);
      if (onUpdateResume) onUpdateResume(fresh);
      if (onShowToast) onShowToast(`Re-analysis complete! New score: ${fresh.scores.overall}/100`, 'success');
    } catch (err: any) {
      if (onShowToast) onShowToast(err.message || 'Re-analysis failed', 'error');
    } finally {
      setReanalyzingId(null);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* 1. WELCOME BANNER */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-500/30">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI Career Roadmap Dashboard</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome back, {user?.name || current?.parsedData?.name || 'Alex'}!
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl leading-relaxed">
            Targeting: <strong className="text-white">{user?.targetRole || 'Senior Full Stack Software Engineer'}</strong> • Current Resume: <span className="text-indigo-400">{current?.resumeFileName || (resumes.length > 0 ? resumes[0].resumeFileName : 'No resumes uploaded yet')}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onNavigate('analyze')}
            className="px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md shadow-indigo-600/25 flex items-center gap-2 active:scale-98"
          >
            <UploadCloud className="w-4 h-4" />
            Upload New Resume
          </button>
          <button
            onClick={() => onNavigate('job-matcher')}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-2"
          >
            <Briefcase className="w-4 h-4" />
            Job Matcher
          </button>
        </div>
      </div>

      {/* 2. TOP KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <ScoreCard
          title="Overall Score"
          score={overallScore}
          icon={Sparkles}
          weight="Weighted Multi-Vector"
          description="Composite readiness across clarity, depth, keywords, and ATS filters."
          highlight={true}
        />
        <ScoreCard
          title="ATS Compatibility"
          score={atsScore}
          icon={ShieldCheck}
          weight="Algorithmic Parser"
          description="Clean standard headings, linear structure, and contact integrity."
        />
        <ScoreCard
          title="Skills Alignment"
          score={skillsScore}
          icon={TrendingUp}
          weight="Domain Taxonomy"
          description="High-demand framework, language, and cloud keyword density."
        />
        <ScoreCard
          title="Experience & Impact"
          score={experienceScore}
          icon={Sliders}
          weight="STAR Methodology"
          description="Quantifiable business outcomes and metric-driven impact verbs."
        />
      </div>

      {/* 3. DUAL COLUMN: RECENT RESUMES + RECOMMENDATIONS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Resumes List (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              Analyzed Resumes ({resumes.length})
            </h2>
            <button
              onClick={() => onNavigate('resumes')}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
            >
              View Repository ({resumes.length})
            </button>
          </div>

          {resumes.length === 0 ? (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-3 shadow-sm">
              <FileText className="w-8 h-8 mx-auto text-slate-400" />
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white">No resumes stored yet</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Upload your resume to have it securely stored and analyzed by the AI engine.
              </p>
              <button
                onClick={() => onNavigate('analyze')}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white inline-flex items-center gap-2"
              >
                <UploadCloud className="w-4 h-4" />
                Upload Resume
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {resumes.map((r) => {
                const isCurrent = current?.id === r.id;
                const targetId = r.resumeId || r.id;
                const isReanalyzing = reanalyzingId === targetId;

                return (
                  <div
                    key={r.id}
                    onClick={() => onSelectResume(r)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                      isCurrent
                        ? 'bg-white dark:bg-slate-900 border-indigo-500 shadow-md ring-1 ring-indigo-500/20'
                        : 'bg-white dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-xs text-slate-900 dark:text-white truncate max-w-[200px]" title={r.resumeFileName}>
                            {r.resumeFileName}
                          </h4>
                          {r.isDemo && (
                            <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20">
                              DEMO
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {r.parsedData?.name || 'Candidate'} • {new Date(r.uploadedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
                      <div className="text-left sm:text-right">
                        <span className="font-mono font-bold text-sm text-emerald-600 dark:text-emerald-400">
                          {r.scores?.overall || 0}/100
                        </span>
                        <span className="block text-[10px] text-slate-500">ATS: {r.scores?.atsCompatibility || 0}%</span>
                      </div>

                      <div className="flex items-center gap-1">
                        {/* Open Original File */}
                        <button
                          onClick={(e) => handleOpenFile(r, e)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Open/Download Original File"
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        {/* Re-analyze */}
                        <button
                          onClick={(e) => handleReanalyze(r, e)}
                          disabled={isReanalyzing}
                          className="p-1.5 rounded-lg text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 disabled:opacity-50"
                          title="Re-analyze with AI"
                        >
                          <RotateCw className={`w-4 h-4 ${isReanalyzing ? 'animate-spin' : ''}`} />
                        </button>

                        {/* View Report */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectResume(r);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="View Full Report"
                        >
                          <ArrowRight className="w-4 h-4" />
                        </button>

                        {/* Delete Resume */}
                        {!r.isDemo && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteResume(r.id);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10"
                            title="Delete Resume"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Priority Action Items (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              High-Impact Recommendations
            </h2>
            <button
              onClick={() => onNavigate('suggestions')}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
            >
              All Action Items
            </button>
          </div>

          <div className="space-y-3">
            {current?.recommendations?.slice(0, 3).map((rec) => (
              <div
                key={rec.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all space-y-2 text-xs shadow-sm"
              >
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20">
                    {rec.priority} PRIORITY
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">{rec.category}</span>
                </div>
                <h4 className="font-semibold text-slate-900 dark:text-slate-200">{rec.problem}</h4>
                <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed line-clamp-2">
                  {rec.suggestedImprovement}
                </p>
              </div>
            ))}
          </div>

          {/* Hackathon Demo Presentation Card */}
          <div className="p-5 rounded-2xl bg-gradient-to-tr from-amber-500/10 via-white dark:via-slate-900 to-white dark:to-slate-900 border border-amber-500/30 space-y-3 shadow-sm">
            <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 text-xs font-bold">
              <Award className="w-4 h-4 text-amber-500" />
              <span>Sample Candidate Presentation</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Showcase the full power of Team 404_codeX's ATS parsing, skill gap matrices, and AI summary generator with the benchmark candidate.
            </p>
            <button
              onClick={onTryDemo}
              className="w-full py-2 rounded-xl text-xs font-semibold bg-amber-500/20 text-amber-800 dark:text-amber-200 border border-amber-500/30 hover:bg-amber-500/30 transition-colors flex items-center justify-center gap-2"
            >
              <PlayCircle className="w-3.5 h-3.5" />
              Launch Sample Candidate (84 Score)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
