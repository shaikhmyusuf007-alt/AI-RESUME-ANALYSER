import React from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  PlayCircle,
  ArrowRight,
  ShieldCheck,
  Zap,
  CheckCircle2,
  FileCheck,
  Search,
  Sliders,
  Award,
  Cpu,
  TrendingUp,
  FileText,
  ChevronDown,
  HelpCircle,
  Lock,
  Layers,
  Code
} from 'lucide-react';
import { CircularProgress } from '../components/ui/CircularProgress.js';

interface LandingViewProps {
  onAnalyze: () => void;
  onTryDemo: () => void;
  onNavigate: (view: string) => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onAnalyze,
  onTryDemo,
  onNavigate
}) => {
  const [openFaq, setOpenFaq] = React.useState<number | null>(null);

  const features = [
    {
      id: 'f1',
      title: 'AI Resume Analysis',
      desc: 'Deep multi-vector analysis evaluating career trajectory, clarity, impact metrics, and role seniority.',
      icon: Cpu,
      color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20'
    },
    {
      id: 'f2',
      title: 'ATS Compatibility Score',
      desc: 'Transparent scoring simulating parsing algorithms used by Taleo, Greenhouse, and Workday systems.',
      icon: ShieldCheck,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
    },
    {
      id: 'f3',
      title: 'Skill Gap Analysis',
      desc: 'Pinpoints missing tech stacks, frameworks, and tools required for your target tier-1 job listings.',
      icon: Sliders,
      color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20'
    },
    {
      id: 'f4',
      title: 'Target Job Matcher',
      desc: 'Paste any target job description to compute precision keyword alignment and role readiness percentage.',
      icon: Search,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/20'
    },
    {
      id: 'f5',
      title: 'Keyword Optimization',
      desc: 'Surface high-frequency industry keywords missing from your bullets to outrank competitor submissions.',
      icon: Zap,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/20'
    },
    {
      id: 'f6',
      title: 'Actionable Improvements',
      desc: 'Step-by-step before-and-after bullet rewrites applying the proven Google XYZ accomplishment formula.',
      icon: TrendingUp,
      color: 'text-rose-400 bg-rose-500/10 border-rose-500/20'
    },
    {
      id: 'f7',
      title: 'AI Professional Summary',
      desc: 'Dynamically re-phrase your executive summary into 4 custom tones: Professional, Technical, Concise, or Recruiter-Friendly.',
      icon: Sparkles,
      color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20'
    },
    {
      id: 'f8',
      title: 'Resume Strengths Matrix',
      desc: 'Highlights what you are already doing well to protect your core competitive advantages.',
      icon: Award,
      color: 'text-teal-400 bg-teal-500/10 border-teal-500/20'
    }
  ];

  const steps = [
    {
      step: '01',
      title: 'Upload Resume',
      desc: 'Drag & drop your current PDF or DOCX file. Our in-memory parser processes raw text securely in milliseconds.',
      icon: FileText
    },
    {
      step: '02',
      title: 'AI Extracts Resume Data',
      desc: 'Automatic parsing detects work history, education credentials, project deliverables, and technical competencies.',
      icon: Cpu
    },
    {
      step: '03',
      title: 'AI Analyzes Resume',
      desc: 'Gemini 3.8 Flash model inspects quantifiable impacts, active verbs, and algorithmic ATS screening compliance.',
      icon: Search
    },
    {
      step: '04',
      title: 'Get Personalized Career Roadmap',
      desc: 'Receive comprehensive scores, prioritized bullet rewrites, job-role recommendations, and tailored summary generators.',
      icon: Award
    }
  ];

  const faqs = [
    {
      q: 'How does the ATS score get calculated?',
      a: 'Our algorithmic engine checks 7 core ATS filters: header contact integrity, canonical section naming, action verb density, quantifiable metrics %, linear parser reading order (no nested tables), and keyword coverage. It simulates modern enterprise ATS parsing engines.'
    },
    {
      q: 'Can I test the application without creating an account?',
      a: 'Yes! Click "Try Demo" at any time. It immediately launches our full hackathon dashboard with a pre-analyzed senior engineer sample profile (Alex Rivera) showcasing all scores, charts, and recommendations.'
    },
    {
      q: 'Is my resume data stored or shared publicly?',
      a: 'Never. Uploaded resumes are parsed strictly within secure session memory for instantaneous analysis and never shared with third-party advertisers.'
    },
    {
      q: 'What file formats are supported?',
      a: 'We support PDF, DOCX (Microsoft Word), and direct plain text pasting with automatic formatting extraction.'
    }
  ];

  return (
    <div className="w-full flex flex-col items-center">
      {/* 1. HERO SECTION */}
      <section className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-20 lg:pt-20 lg:pb-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Heading & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Hackathon Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Team 404_codeX Hackathon Project</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.12]">
              Decode Your Resume <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                Unlock Your Career.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-xl leading-relaxed">
              Upload your resume and let AI analyze your ATS score, skills, experience,
              keywords, and career opportunities. Turn your resume into your career roadmap.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={onAnalyze}
                className="px-6 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 active:scale-98"
              >
                Analyze My Resume
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onTryDemo}
                className="px-6 py-3.5 rounded-xl font-bold text-sm bg-slate-900 border border-amber-500/40 text-amber-300 hover:bg-slate-800 transition-all flex items-center justify-center gap-2 active:scale-98 shadow-md shadow-amber-500/5"
              >
                <PlayCircle className="w-4 h-4 text-amber-400" />
                Try Demo (Instant Preview)
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="pt-6 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>AI-powered analysis</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>ATS-focused insights</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Instant feedback</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                <span>Secure processing</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Interactive Resume / AI Card Mockup */}
          <div className="lg:col-span-5 relative">
            {/* Gradient Glow */}
            <div className="absolute -inset-2 rounded-3xl bg-gradient-to-tr from-indigo-500/30 via-purple-500/20 to-cyan-500/30 blur-2xl -z-10 opacity-70" />

            <div className="relative rounded-2xl bg-slate-900/90 border border-slate-800 p-6 shadow-2xl backdrop-blur-xl">
              {/* Card Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                    <FileCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Alex_Rivera_Resume.pdf</h3>
                    <p className="text-[11px] text-slate-400">542 words • Senior Full Stack Engineer</p>
                  </div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                  ANALYSIS COMPLETE
                </span>
              </div>

              {/* Gauges Side by Side */}
              <div className="py-6 grid grid-cols-2 gap-4 place-items-center bg-slate-950/50 rounded-xl my-4 border border-slate-800/60">
                <CircularProgress score={84} size="sm" label="Overall Score" colorVariant="auto" />
                <CircularProgress score={81} size="sm" label="ATS Compatibility" colorVariant="auto" />
              </div>

              {/* Live Metric Snippets */}
              <div className="space-y-2.5 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-800/60 flex items-center justify-between">
                  <span className="text-slate-300">Technical Skills Match</span>
                  <span className="font-mono font-bold text-emerald-400">88% Verified</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/60 flex items-center justify-between">
                  <span className="text-slate-300">Quantifiable Metrics</span>
                  <span className="font-mono font-bold text-cyan-400">6 Numbers Found</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/60 flex items-center justify-between">
                  <span className="text-slate-300">Target Role Fit</span>
                  <span className="font-mono font-bold text-indigo-400">94% Senior Full Stack</span>
                </div>
              </div>

              {/* AI Badge Overlay */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  Gemini 3.8 Flash Engine
                </span>
                <button
                  onClick={onTryDemo}
                  className="text-indigo-400 hover:text-indigo-300 font-semibold inline-flex items-center gap-1"
                >
                  Explore Report <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. FEATURES SECTION */}
      <section className="w-full bg-slate-900/40 border-y border-slate-800/80 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-400 mb-2">
              Everything You Need to Win Interviews
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Powerful AI Tools Built for Modern Job Seekers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f) => {
              const Icon = f.icon;
              return (
                <div
                  key={f.id}
                  className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all duration-200 flex flex-col justify-between group hover:shadow-xl hover:shadow-indigo-500/5"
                >
                  <div>
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-4 border ${f.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-bold text-white mb-2 group-hover:text-indigo-300 transition-colors">
                      {f.title}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {f.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. HOW IT WORKS SECTION */}
      <section className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400 mb-2 block">
            Streamlined 4-Step Process
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            How AI Resume Analyser Works
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((s, idx) => {
            const Icon = s.icon;
            return (
              <div
                key={s.step}
                className="relative p-6 rounded-2xl bg-slate-900/50 border border-slate-800/80 flex flex-col"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="font-mono text-xl font-bold text-slate-600">
                    {s.step}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white mb-2">{s.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{s.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. INTERACTIVE PREVIEW TEASERS */}
      <section className="w-full bg-slate-900/30 border-t border-slate-800/80 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* ATS Score Preview */}
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-white text-sm">ATS Screening Engine</h3>
                <span className="text-xs font-mono text-emerald-400">Score 81/100</span>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Detects contact integrity, heading hierarchy, quantifiable metrics, and active verbs.
              </p>
              <div className="space-y-2 text-xs">
                <div className="p-2 rounded bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-300">Standard Headings</span>
                  <span className="text-emerald-400 font-semibold">Passed</span>
                </div>
                <div className="p-2 rounded bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-300">Single Column Layout</span>
                  <span className="text-emerald-400 font-semibold">Passed</span>
                </div>
                <div className="p-2 rounded bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-300">Quantified Impact</span>
                  <span className="text-emerald-400 font-semibold">6 Metrics Found</span>
                </div>
              </div>
            </div>

            {/* Skill Gap Matrix Preview */}
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-white text-sm">Skill Gap Matrix</h3>
                <span className="text-xs font-mono text-cyan-400">Market Verified</span>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Identifies missing skills required to step up to Senior and Staff engineering levels.
              </p>
              <div className="space-y-2 text-xs font-mono">
                <div className="p-2 rounded bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-300">TypeScript / React</span>
                  <span className="text-emerald-400">94% Level</span>
                </div>
                <div className="p-2 rounded bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-300">PostgreSQL / Redis</span>
                  <span className="text-cyan-400">88% Level</span>
                </div>
                <div className="p-2 rounded bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-300">Terraform (IaC)</span>
                  <span className="text-amber-400">Missing Gap</span>
                </div>
              </div>
            </div>

            {/* Job Matcher Preview */}
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-white text-sm">Target Job Matcher</h3>
                <span className="text-xs font-mono text-purple-400">JD Alignment</span>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Compare your resume against any job description to compute precision keyword match.
              </p>
              <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-500/20 text-xs mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-white">Full Stack Software Engineer</span>
                  <span className="font-bold text-indigo-400">94% Match</span>
                </div>
                <p className="text-[11px] text-slate-400">Matching 6 of 7 critical competencies</p>
              </div>
              <button
                onClick={() => onNavigate('job-matcher')}
                className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
              >
                Test Job Matcher
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 5. FAQ SECTION */}
      <section className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-12">
          <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-400 mb-2">
            Got Questions?
          </h2>
          <p className="text-2xl sm:text-3xl font-bold text-white">
            Frequently Asked Questions
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden"
            >
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full p-5 text-left flex items-center justify-between text-sm font-semibold text-slate-100 hover:text-white transition-colors"
              >
                <span>{faq.q}</span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                    openFaq === i ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openFaq === i && (
                <div className="px-5 pb-5 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* 6. BOTTOM CTA */}
      <section className="w-full bg-gradient-to-b from-slate-900 to-slate-950 border-t border-slate-800 py-16 text-center">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-medium border border-indigo-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            Hackathon Edition by Team 404_codeX
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Ready to Accelerate Your Career Roadmap?
          </h2>
          <p className="text-sm text-slate-400 leading-relaxed max-w-xl mx-auto">
            Upload your resume now for instant ATS scores, gap analysis, and tailored AI recommendations.
          </p>
          <div className="flex items-center justify-center gap-4 pt-2">
            <button
              onClick={onAnalyze}
              className="px-6 py-3.5 rounded-xl font-bold text-sm bg-indigo-600 hover:bg-indigo-500 text-white shadow-xl shadow-indigo-600/30 transition-all flex items-center gap-2"
            >
              Get Started Free
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onTryDemo}
              className="px-6 py-3.5 rounded-xl font-semibold text-sm bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-all flex items-center gap-2"
            >
              <PlayCircle className="w-4 h-4" />
              Try Demo
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
