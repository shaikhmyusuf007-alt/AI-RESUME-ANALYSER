import React from 'react';
import {
  Sliders,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  ArrowRight,
  Sparkles,
  Layers,
  Award,
  ExternalLink
} from 'lucide-react';
import { ResumeAnalysis } from '../types.js';
import { SkillBar } from '../components/ui/SkillBar.js';

interface SkillGapViewProps {
  analysis: ResumeAnalysis;
  onNavigateToJobMatcher: () => void;
}

export const SkillGapView: React.FC<SkillGapViewProps> = ({
  analysis,
  onNavigateToJobMatcher
}) => {
  const learningRoadmap = [
    {
      skill: 'Terraform & Infrastructure as Code (IaC)',
      estimatedTime: '2 - 3 weeks',
      priority: 'HIGH',
      resources: 'HashiCorp Certified Terraform Associate (003), AWS Cloud Architecture',
      impact: '+12% match rate for Staff / Senior Cloud positions'
    },
    {
      skill: 'Kubernetes Cluster Administration (CKA)',
      estimatedTime: '3 - 4 weeks',
      priority: 'HIGH',
      resources: 'Linux Foundation CKA, Helm chart deployments, Pod networking',
      impact: '+15% match rate for Enterprise Distributed Systems roles'
    },
    {
      skill: 'Observability & APM (Datadog / OpenTelemetry)',
      estimatedTime: '1 - 2 weeks',
      priority: 'MEDIUM',
      resources: 'Distributed tracing, Prometheus metric scrapers, Alert policies',
      impact: '+8% match rate for Production Reliability screening'
    },
    {
      skill: 'Apache Kafka & Event Streaming',
      estimatedTime: '2 weeks',
      priority: 'MEDIUM',
      resources: 'Confluent Developer Course, Partitioning strategies, Exactly-once semantics',
      impact: '+10% match rate for High-Throughput Fintech roles'
    }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
          <Sliders className="w-3.5 h-3.5 text-indigo-400" />
          <span>Market Skill Gap & Competency Matrix</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Skill Gap Analysis
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Benchmarking your resume against Senior and Staff engineer market criteria to highlight your biggest leverage areas.
        </p>
      </div>

      {/* Grid: Current Skills vs Target Role Gaps */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Current Verified Skills */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Verified Competencies in Resume
            </h2>
            <span className="text-xs text-slate-400">Score: {analysis.scores.skills}/100</span>
          </div>

          <div className="space-y-6">
            {analysis.skillsBreakdown.map((group) => (
              <div key={group.name} className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  {group.name}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {group.skills.map((s) => (
                    <SkillBar
                      key={s.name}
                      name={s.name}
                      level={s.level}
                      category={s.category}
                      verified={s.verifiedInResume}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Missing Skills by Role */}
        <div className="lg:col-span-5 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Recommended Skills to Add
            </h2>
            <span className="text-xs text-amber-400 font-mono">Market Demand</span>
          </div>

          <div className="space-y-4">
            {analysis.missingRecommendedSkills.map((gap, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white">{gap.role}</h4>
                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                    High ROI
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Adding these keywords to project deliverables or skills list significantly boosts tier-1 recruiter search ranking:
                </p>
                <div className="flex flex-wrap gap-2">
                  {gap.skills.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 text-amber-200 border border-amber-500/20 text-xs font-medium"
                    >
                      + {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}

            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-500/30 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                Want to test with a real job description?
              </h4>
              <p className="text-xs text-slate-300">
                Paste any job posting in our Job Matcher to generate real-time keyword coverage and missing qualification checks.
              </p>
              <button
                onClick={onNavigateToJobMatcher}
                className="w-full py-2.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5"
              >
                Open Job Matcher
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. RECOMMENDED UPSKILLING ROADMAP */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-6">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-cyan-400" />
            Curated Upskilling Roadmap
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Priority-ordered certifications and competencies that bridge your transition to Staff / Lead roles.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {learningRoadmap.map((item, i) => (
            <div
              key={i}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-2 text-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-100">{item.skill}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    item.priority === 'HIGH'
                      ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  }`}
                >
                  {item.priority}
                </span>
              </div>
              <p className="text-slate-400">
                <strong className="text-slate-300">Time to Complete:</strong> {item.estimatedTime}
              </p>
              <p className="text-slate-400">
                <strong className="text-slate-300">Suggested Focus:</strong> {item.resources}
              </p>
              <div className="pt-1 text-emerald-400 font-medium">
                🎯 {item.impact}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
