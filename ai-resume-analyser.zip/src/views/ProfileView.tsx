import React, { useState } from 'react';
import {
  User,
  Briefcase,
  Layers,
  Save,
  CheckCircle2,
  Sparkles,
  Award,
  Globe,
  Plus,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';

interface ProfileViewProps {
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onShowToast }) => {
  const { user, updateProfile } = useAuth();

  const [name, setName] = useState(user?.name || 'Alex Rivera');
  const [targetRole, setTargetRole] = useState(user?.targetRole || 'Senior Full Stack Software Engineer');
  const [experienceLevel, setExperienceLevel] = useState(user?.experienceLevel || 'Senior');
  const [preferredIndustry, setPreferredIndustry] = useState(user?.preferredIndustry || 'Cloud Software & AI SaaS');
  const [skills, setSkills] = useState<string[]>(
    user?.skills || ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Docker', 'AWS']
  );
  const [newSkill, setNewSkill] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleAddSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter((s) => s !== skillToRemove));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await updateProfile({
        name,
        targetRole,
        experienceLevel: experienceLevel as any,
        preferredIndustry,
        skills
      });
      onShowToast('Profile settings saved successfully!', 'success');
    } catch (err: any) {
      onShowToast(err.message || 'Failed to save profile', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
          <User className="w-3.5 h-3.5 text-indigo-400" />
          <span>Candidate Preferences</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Career Profile Settings
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Customize your target roles and priority skills. Our AI engine uses these to tailor match percentages and upskilling recommendations.
        </p>
      </div>

      <form onSubmit={handleSave} className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-6">
        {/* Name & Target Role */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Target Job Role
            </label>
            <input
              type="text"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              placeholder="e.g. Senior Full Stack Engineer"
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              required
            />
          </div>
        </div>

        {/* Experience Level & Industry */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Experience Level
            </label>
            <select
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            >
              <option value="Entry">Entry Level (0-2 years)</option>
              <option value="Mid">Mid Level (2-4 years)</option>
              <option value="Senior">Senior Level (5-8 years)</option>
              <option value="Lead">Lead / Staff Level (8+ years)</option>
              <option value="Executive">Executive / Director</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Preferred Industry
            </label>
            <input
              type="text"
              value={preferredIndustry}
              onChange={(e) => setPreferredIndustry(e.target.value)}
              placeholder="e.g. Cloud SaaS / Fintech / AI"
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Key Skills Tags */}
        <div className="space-y-3 pt-2">
          <label className="block text-xs font-semibold text-slate-300">
            Target & Primary Skills
          </label>
          <div className="flex flex-wrap gap-2 mb-2">
            {skills.map((s) => (
              <span
                key={s}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-indigo-600/10 text-indigo-300 border border-indigo-500/20 text-xs font-medium"
              >
                {s}
                <button
                  type="button"
                  onClick={() => handleRemoveSkill(s)}
                  className="hover:text-rose-400 transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            ))}
          </div>

          <div className="flex items-center gap-2 max-w-sm">
            <input
              type="text"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddSkill();
                }
              }}
              placeholder="Add skill (e.g. Next.js, Kubernetes)..."
              className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
            <button
              type="button"
              onClick={handleAddSkill}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              Add
            </button>
          </div>
        </div>

        {/* Save button */}
        <div className="pt-4 border-t border-slate-800 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/20 transition-all flex items-center gap-2 active:scale-98 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'Saving Changes…' : 'Save Profile'}
          </button>
        </div>
      </form>
    </div>
  );
};
