import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  AlertCircle,
  X,
  PlayCircle,
  CheckCircle,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  HelpCircle,
  FileType
} from 'lucide-react';
import { uploadResumeFile, uploadResumeText, runResumeAnalysis, getSampleDemo } from '../lib/api.js';
import { ResumeAnalysis } from '../types.js';
import { LoadingStages } from '../components/ui/LoadingStages.js';

interface UploadViewProps {
  onAnalysisComplete: (analysis: ResumeAnalysis) => void;
  onTryDemo: () => void;
}

export const UploadView: React.FC<UploadViewProps> = ({
  onAnalysisComplete,
  onTryDemo
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'text'>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [rawText, setRawText] = useState<string>('');
  const [candidateName, setCandidateName] = useState<string>('');
  const [targetRole, setTargetRole] = useState<string>('Full Stack Software Engineer');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<ResumeAnalysis | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleSelectFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleSelectFile(e.target.files[0]);
    }
  };

  const handleSelectFile = (selected: File) => {
    setError(null);
    const validTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/msword',
      'text/plain'
    ];
    const isDocx = selected.name.endsWith('.docx') || selected.name.endsWith('.doc');
    const isPdf = selected.name.endsWith('.pdf');
    const isTxt = selected.name.endsWith('.txt');

    if (!validTypes.includes(selected.type) && !isDocx && !isPdf && !isTxt) {
      setError('Unsupported file type. Please upload a PDF, DOCX, or TXT file.');
      return;
    }

    if (selected.size > 12 * 1024 * 1024) {
      setError('File exceeds 12MB limit. Please upload a smaller document.');
      return;
    }

    setFile(selected);
  };

  const handleClearFile = () => {
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleLoadSampleText = () => {
    setCandidateName('Alex Rivera');
    setTargetRole('Senior Full Stack Software Engineer');
    setRawText(`Alex Rivera
Senior Full Stack Engineer
San Francisco, CA • alex.rivera@codex404.dev • +1 (415) 555-0198
LinkedIn: linkedin.com/in/alex-rivera-dev • GitHub: github.com/alexrivera-codex

PROFESSIONAL SUMMARY
Senior Full Stack Engineer with 5+ years of experience designing high-throughput web applications, microservices, and distributed cloud systems. Skilled in TypeScript, React, Node.js, and AWS with a track record of driving 40%+ performance gains.

WORK EXPERIENCE
Senior Full Stack Engineer | Vanguard Cloud Systems | 2022 - Present
• Architected and led the development of a real-time event ingestion engine processing 1.5M transactions daily with 99.99% uptime.
• Reduced web application p95 response latency by 38% through Redis tier caching and PostgreSQL query optimization.
• Spearheaded CI/CD migration to GitHub Actions & AWS ECS, cutting deployment duration from 45 to 6 minutes.

Full Stack Software Engineer | Apex Data Labs | 2020 - 2022
• Engineered customer-facing analytics dashboards using React, TypeScript, and Tailwind CSS serving 80,000+ monthly active enterprise users.
• Developed microservice REST APIs in Node.js and Express with automated Jest test suites achieving 89% code coverage.
• Collaborated in Agile sprints with cross-functional product and UX design teams to ship 14 major feature releases on schedule.

TECHNICAL PROJECTS
Distributed Task Queue & Scheduler
• Built a fault-tolerant async worker pool capable of processing 10,000 concurrent jobs with dead-letter queue recovery.
• Tech Stack: TypeScript, Node.js, Redis, Docker

Collaborative Real-Time Whiteboard
• Engineered sub-50ms peer-to-peer sync engine supporting up to 50 active canvas collaborators simultaneously.
• Tech Stack: React, WebSockets, Canvas API, Tailwind CSS

EDUCATION
University of California, Berkeley | 2017 - 2021
B.S. in Computer Science & Applied Mathematics | GPA: 3.86 / 4.0

TECHNICAL SKILLS
Languages: TypeScript, JavaScript, Python, SQL, Bash, HTML5, CSS3
Frameworks: React, Next.js, Express, Tailwind CSS, Prisma, Jest
Cloud & Tools: Docker, AWS (ECS, S3, RDS), Git, Redis, PostgreSQL, Postman, Jira`);
  };

  const handleStartAnalysis = async () => {
    setError(null);
    setIsProcessing(true);
    setAnalysisResult(null);

    try {
      let analysis: ResumeAnalysis;

      if (activeTab === 'upload') {
        if (!file) {
          setError('Please select or drop a resume file first.');
          setIsProcessing(false);
          return;
        }

        // Upload and parse file
        const uploadRes = await uploadResumeFile(file);
        const extractedRaw = uploadRes.rawText || uploadRes.parsedData?.rawText;
        if (!extractedRaw || extractedRaw.trim().length < 30) {
          throw new Error('Could not extract readable text from the uploaded document. If this is a scanned image or photo PDF, please paste your resume text into the "Paste Resume Text" tab.');
        }

        // Run AI analysis
        analysis = await runResumeAnalysis({
          resumeId: uploadRes.resumeId,
          fileName: uploadRes.fileName,
          fileSize: uploadRes.fileSize,
          rawText: extractedRaw,
          parsedData: uploadRes.parsedData
        });
      } else {
        if (!rawText || rawText.trim().length < 40) {
          setError('Please paste your resume text with at least 40 characters.');
          setIsProcessing(false);
          return;
        }

        const fileName = (candidateName ? candidateName.replace(/\s+/g, '_') : 'Resume') + '_Document.txt';
        const uploadRes = await uploadResumeText(fileName, rawText);
        const extractedRaw = uploadRes.rawText || uploadRes.parsedData?.rawText || rawText;

        analysis = await runResumeAnalysis({
          resumeId: uploadRes.resumeId,
          fileName: uploadRes.fileName,
          fileSize: uploadRes.fileSize,
          rawText: extractedRaw,
          parsedData: uploadRes.parsedData
        });
      }

      setAnalysisResult(analysis);
    } catch (err: any) {
      console.error('Analysis error:', err);
      setIsProcessing(false);
      setError(err.message || 'Failed to process resume. Please ensure the document is a readable PDF, DOCX, or TXT file.');
    }
  };

  const handleLoadingComplete = () => {
    if (analysisResult) {
      onAnalysisComplete(analysisResult);
    }
  };

  // If in active multi-stage loading animation
  if (isProcessing) {
    return (
      <div className="w-full max-w-4xl mx-auto px-4 py-12">
        <LoadingStages
          isReady={!!analysisResult}
          error={error}
          onComplete={handleLoadingComplete}
          durationMs={2800}
        />
        {error && (
          <div className="mt-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-center max-w-lg mx-auto">
            <p className="text-xs text-rose-300 mb-3">{error}</p>
            <button
              onClick={() => setIsProcessing(false)}
              className="px-4 py-2 rounded-lg bg-slate-800 text-slate-200 text-xs font-semibold hover:bg-slate-700 transition-colors"
            >
              Back to Upload
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 py-10">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>Team 404_codeX AI Engine</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Upload Your Resume
        </h1>
        <p className="text-sm text-slate-400 mt-2">
          Get comprehensive ATS scoring, skill verification, and job matching in under 5 seconds.
        </p>
      </div>

      {/* Mode Tabs */}
      <div className="flex items-center justify-center gap-2 mb-6">
        <button
          onClick={() => setActiveTab('upload')}
          className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
            activeTab === 'upload'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          <UploadCloud className="w-4 h-4" />
          Upload Document (PDF / DOCX)
        </button>
        <button
          onClick={() => setActiveTab('text')}
          className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
            activeTab === 'text'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          Paste Resume Text
        </button>
      </div>

      {/* Error alert */}
      {error && (
        <div className="mb-6 p-4 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-xs flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
          <div className="flex-1">{error}</div>
          <button onClick={() => setError(null)} className="text-rose-400 hover:text-rose-200">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* TAB 1: File Upload */}
      {activeTab === 'upload' && (
        <div className="space-y-6">
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`cursor-pointer relative p-10 sm:p-14 rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center text-center group ${
              isDragging
                ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]'
                : file
                ? 'border-emerald-500/50 bg-emerald-500/5'
                : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/70'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.docx,.doc,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
              onChange={handleFileChange}
              className="hidden"
            />

            <div className="w-16 h-16 rounded-2xl bg-slate-800/90 border border-slate-700/60 flex items-center justify-center text-indigo-400 mb-4 group-hover:scale-110 group-hover:text-indigo-300 transition-all shadow-lg">
              <UploadCloud className="w-8 h-8" />
            </div>

            <h3 className="text-base font-bold text-white mb-1">
              Drag & Drop your resume here, or <span className="text-indigo-400 underline">Browse</span>
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mb-4">
              Supported formats: PDF, DOCX, DOC (max 12MB). Optimized for standard single-column ATS layouts.
            </p>

            <div className="flex items-center gap-3 text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <FileType className="w-3.5 h-3.5 text-indigo-400" /> PDF / Word
              </span>
              <span>•</span>
              <span>In-Memory Extraction</span>
              <span>•</span>
              <span>Instant AI Scoring</span>
            </div>
          </div>

          {/* Selected File Card */}
          {file && (
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">{file.name}</h4>
                  <p className="text-[11px] text-slate-400">
                    {(file.size / 1024).toFixed(1)} KB • Ready for AI ATS parsing
                  </p>
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleClearFile();
                }}
                className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Text Paste */}
      {activeTab === 'text' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Candidate Name
              </label>
              <input
                type="text"
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                placeholder="e.g. Alex Rivera"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Target Role
              </label>
              <input
                type="text"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                placeholder="e.g. Senior Full Stack Engineer"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Resume Content (Text)
              </label>
              <button
                onClick={handleLoadSampleText}
                className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3" />
                Fill with Sample Resume
              </button>
            </div>
            <textarea
              rows={12}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Paste the full text of your resume here (Summary, Experience, Education, Projects, Skills)..."
              className="w-full p-4 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono leading-relaxed focus:outline-none focus:border-indigo-500 resize-y"
            />
          </div>
        </div>
      )}

      {/* Action Footer */}
      <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onTryDemo}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:bg-slate-800 transition-all shadow-sm"
          >
            <PlayCircle className="w-4 h-4 text-amber-400" />
            Try Preloaded Hackathon Demo
          </button>
          <span className="text-xs text-slate-500 hidden sm:inline">
            (Alex Rivera: 84 Score, 81 ATS)
          </span>
        </div>

        <button
          onClick={handleStartAnalysis}
          disabled={activeTab === 'upload' ? !file : !rawText}
          className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 active:scale-98"
        >
          Analyze Resume
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
