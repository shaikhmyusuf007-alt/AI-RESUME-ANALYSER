import React, { useState } from 'react';
import {
  FileText,
  Trash2,
  ArrowRight,
  UploadCloud,
  Search,
  ExternalLink,
  RotateCw,
  Clock,
  Download,
  CheckCircle2,
  AlertTriangle,
  PlayCircle
} from 'lucide-react';
import { ResumeAnalysis } from '../types.js';
import { getResumeFileDownloadUrl, reanalyzeResumeById } from '../lib/api.js';

interface ResumesViewProps {
  resumes: ResumeAnalysis[];
  onSelectResume: (analysis: ResumeAnalysis) => void;
  onDeleteResume: (id: string) => void;
  onNavigateToUpload: () => void;
  onTryDemo: () => void;
  onUpdateResume?: (updated: ResumeAnalysis) => void;
  onShowToast?: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const ResumesView: React.FC<ResumesViewProps> = ({
  resumes,
  onSelectResume,
  onDeleteResume,
  onNavigateToUpload,
  onTryDemo,
  onUpdateResume,
  onShowToast
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [reanalyzingId, setReanalyzingId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filtered = resumes.filter((r) => {
    const text = `${r.resumeFileName} ${r.parsedData?.name || ''} ${r.parsedData?.experience?.[0]?.role || ''}`.toLowerCase();
    return text.includes(searchQuery.toLowerCase());
  });

  const handleReanalyze = async (r: ResumeAnalysis) => {
    const targetId = r.resumeId || r.id;
    setReanalyzingId(targetId);
    try {
      if (onShowToast) onShowToast('Re-analyzing resume with latest AI models...', 'info');
      const freshAnalysis = await reanalyzeResumeById(targetId);
      if (onUpdateResume) {
        onUpdateResume(freshAnalysis);
      }
      if (onShowToast) onShowToast(`Re-analysis complete! Score: ${freshAnalysis.scores.overall}/100`, 'success');
    } catch (err: any) {
      if (onShowToast) onShowToast(err.message || 'Failed to re-analyze resume.', 'error');
    } finally {
      setReanalyzingId(null);
    }
  };

  const handleOpenFile = (r: ResumeAnalysis) => {
    const targetId = r.resumeId || r.id;
    const url = getResumeFileDownloadUrl(targetId);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-semibold mb-2">
            <FileText className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            <span>Document Repository & Cloud Storage</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            My Resumes ({resumes.length})
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Access previous ATS analysis reports, inspect original uploaded files, and re-run AI evaluation anytime.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onTryDemo}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-amber-700 dark:text-amber-300 border border-amber-500/30 transition-colors flex items-center gap-2 shadow-sm"
          >
            <PlayCircle className="w-4 h-4" />
            Load Sample Candidate
          </button>
          <button
            onClick={onNavigateToUpload}
            className="px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md shadow-indigo-600/20 flex items-center gap-2"
          >
            <UploadCloud className="w-4 h-4" />
            Upload New Resume
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by filename, role, or candidate name..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500 shadow-sm"
        />
      </div>

      {/* Empty State */}
      {filtered.length === 0 && (
        <div className="text-center py-16 px-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
            <FileText className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">
            {searchQuery ? 'No matching resumes found' : 'No resumes uploaded yet'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            {searchQuery
              ? 'Try changing your search query to find previous uploads.'
              : 'Upload your resume in PDF or DOCX format to store it securely and unlock AI-powered ATS scoring.'}
          </p>
          <div className="pt-2">
            <button
              onClick={onNavigateToUpload}
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 inline-flex items-center gap-2"
            >
              <UploadCloud className="w-4 h-4" />
              Upload Your First Resume
            </button>
          </div>
        </div>
      )}

      {/* Resumes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((r) => {
          const targetResumeId = r.resumeId || r.id;
          const isReanalyzing = reanalyzingId === targetResumeId;
          const isDeleting = deleteConfirmId === r.id;

          return (
            <div
              key={r.id}
              className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-slate-700 transition-all flex flex-col justify-between group shadow-sm hover:shadow-md"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="p-3 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-400">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
                      {r.scores?.overall || 0}
                    </span>
                    <span className="block text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                      Overall Score
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate max-w-[200px]" title={r.resumeFileName}>
                    {r.resumeFileName}
                  </h3>
                  {r.isDemo && (
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30">
                      DEMO
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  {r.parsedData?.name || 'Candidate'} • {r.parsedData?.experience?.[0]?.role || 'Software Engineer'}
                </p>

                {/* Score Pills */}
                <div className="grid grid-cols-2 gap-2 my-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 flex items-center justify-between border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500 dark:text-slate-400 text-[11px]">ATS Score</span>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {r.scores?.atsCompatibility || 0}%
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 flex items-center justify-between border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500 dark:text-slate-400 text-[11px]">Skills Score</span>
                    <span className="font-mono font-bold text-cyan-600 dark:text-cyan-400">
                      {r.scores?.skills || 0}%
                    </span>
                  </div>
                </div>

                {/* Upload Timestamp & Metadata */}
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mb-4">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Uploaded {new Date(r.uploadedAt).toLocaleDateString()} at {new Date(r.uploadedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* 1. Open/View Original Resume File */}
                    <button
                      onClick={() => handleOpenFile(r)}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition-colors"
                      title="Open or download original uploaded resume"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>View File</span>
                    </button>

                    {/* 2. Re-analyze with AI */}
                    <button
                      onClick={() => handleReanalyze(r)}
                      disabled={isReanalyzing}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-500/20 border border-indigo-200 dark:border-indigo-500/30 flex items-center gap-1.5 transition-colors disabled:opacity-50"
                      title="Run fresh AI analysis on this stored resume"
                    >
                      <RotateCw className={`w-3.5 h-3.5 ${isReanalyzing ? 'animate-spin' : ''}`} />
                      <span>{isReanalyzing ? 'Analyzing...' : 'Re-analyze'}</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Delete Option */}
                    {!r.isDemo && (
                      isDeleting ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              onDeleteResume(r.id);
                              setDeleteConfirmId(null);
                            }}
                            className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold"
                            title="Confirm delete"
                          >
                            Delete
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(null)}
                            className="px-2 py-1 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px]"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirmId(r.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors"
                          title="Delete resume from cloud storage"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )
                    )}

                    {/* View Full Report */}
                    <button
                      onClick={() => onSelectResume(r)}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-all flex items-center gap-1 shadow-sm shadow-indigo-600/20"
                    >
                      <span>Report</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
