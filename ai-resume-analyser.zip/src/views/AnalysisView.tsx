import React, { useState } from 'react';
import {
  FileText,
  Share2,
  Printer,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Copy,
  Briefcase,
  Layers,
  Search,
  Sliders,
  ChevronRight,
  TrendingUp,
  Cpu,
  ShieldCheck,
  Check,
  RefreshCw,
  ExternalLink,
  DollarSign
} from 'lucide-react';
import { ResumeAnalysis } from '../types.js';
import { CircularProgress } from '../components/ui/CircularProgress.js';
import { ScoreCard } from '../components/ui/ScoreCard.js';
import { SkillBar } from '../components/ui/SkillBar.js';
import { regenerateSummary } from '../lib/api.js';

interface AnalysisViewProps {
  analysis: ResumeAnalysis;
  onNavigateToJobMatcher: (resumeId: string) => void;
  onNavigateToUpload: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({
  analysis,
  onNavigateToJobMatcher,
  onNavigateToUpload,
  onShowToast
}) => {
  const [activeTone, setActiveTone] = useState<'Professional' | 'Technical' | 'Concise' | 'Recruiter-Friendly'>(
    analysis.professionalSummary?.currentTone || 'Professional'
  );
  const [summaryText, setSummaryText] = useState<string>(
    analysis.professionalSummary?.tones?.[activeTone] || analysis.professionalSummary?.original || ''
  );
  const [isRegenerating, setIsRegenerating] = useState<boolean>(false);
  const [copiedSummary, setCopiedSummary] = useState<boolean>(false);
  const [copiedBulletId, setCopiedBulletId] = useState<string | null>(null);

  const [showExtractedData, setShowExtractedData] = useState<boolean>(false);

  // Synchronize summary text when viewing a different resume
  React.useEffect(() => {
    const tone = analysis.professionalSummary?.currentTone || 'Professional';
    setActiveTone(tone);
    setSummaryText(
      analysis.professionalSummary?.tones?.[tone] ||
      analysis.professionalSummary?.original ||
      ''
    );
  }, [analysis.id]);

  // Score mappings
  const scoreCards = [
    {
      title: 'Overall Score',
      score: analysis.scores.overall,
      icon: Cpu,
      weight: 'Weighted Aggregate',
      desc: 'Holistic candidate rating based on impact, keywords, depth, and ATS readiness.'
    },
    {
      title: 'ATS Compatibility',
      score: analysis.scores.atsCompatibility,
      icon: ShieldCheck,
      weight: 'Standard Parser Rules',
      desc: 'Simulates parsing success in Taleo, Workday, and Greenhouse ATS engines.'
    },
    {
      title: 'Skills Coverage',
      score: analysis.scores.skills,
      icon: Sliders,
      weight: 'Tech & Tool Depth',
      desc: 'Keyword presence of modern frameworks, languages, and architecture patterns.'
    },
    {
      title: 'Experience Impact',
      score: analysis.scores.experience,
      icon: TrendingUp,
      weight: 'Quantified Metrics',
      desc: 'Evaluation of action verbs, numerical metrics, and career seniority trajectory.'
    },
    {
      title: 'Projects & Portfolio',
      score: analysis.scores.projects,
      icon: Layers,
      weight: 'Technical Deliverables',
      desc: 'Demonstrated initiative through deployed tools, architectures, and open source.'
    },
    {
      title: 'Education & Honors',
      score: analysis.scores.education,
      icon: CheckCircle2,
      weight: 'Academic & Accreditations',
      desc: 'Degree relevance, GPA/honors, and industry cloud certifications.'
    },
    {
      title: 'Document Formatting',
      score: analysis.scores.formatting,
      icon: FileText,
      weight: 'Layout & Typography',
      desc: 'Single-column structure, clean font hierarchies, and zero parsing traps.'
    },
    {
      title: 'Keyword Density',
      score: analysis.scores.keywords,
      icon: Search,
      weight: 'Relevance Benchmark',
      desc: 'Aligns with top 10% search queries submitted by enterprise tech recruiters.'
    }
  ];

  const handleToneChange = async (tone: 'Professional' | 'Technical' | 'Concise' | 'Recruiter-Friendly') => {
    setActiveTone(tone);
    if (analysis.professionalSummary.tones[tone]) {
      setSummaryText(analysis.professionalSummary.tones[tone]);
    } else {
      // Regenerate on the fly
      setIsRegenerating(true);
      try {
        const generated = await regenerateSummary({
          summary: analysis.professionalSummary.original,
          tone,
          skills: analysis.parsedData.skills.technical
        });
        setSummaryText(generated);
      } catch {
        onShowToast('Could not regenerate summary; keeping current tone.', 'error');
      } finally {
        setIsRegenerating(false);
      }
    }
  };

  const handleCopySummary = () => {
    navigator.clipboard.writeText(summaryText);
    setCopiedSummary(true);
    onShowToast('Professional Summary copied to clipboard!', 'success');
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  const handleCopyBullet = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedBulletId(id);
    onShowToast('Improved bullet point copied to clipboard!', 'success');
    setTimeout(() => setCopiedBulletId(null), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* 1. REPORT HEADER */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {analysis.parsedData.name || 'Candidate'}
            </h1>
            {analysis.isDemo && (
              <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                HACKATHON DEMO SAMPLE
              </span>
            )}
            <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {analysis.parsedData.experience[0]?.role || analysis.parsedData.skills.technical[0] || 'Professional Profile'}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-slate-400">
            <span className="flex items-center gap-1.5 font-medium text-slate-300">
              <FileText className="w-3.5 h-3.5 text-indigo-400" />
              {analysis.resumeFileName}
            </span>
            <span>•</span>
            <span>Word Count: {analysis.atsExplanation.parsedWordCount} words</span>
            <span>•</span>
            <span>Analyzed {new Date(analysis.uploadedAt).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowExtractedData(!showExtractedData)}
            className={`px-3.5 py-2.5 rounded-xl text-xs font-semibold border transition-all flex items-center gap-2 ${
              showExtractedData
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
            }`}
          >
            <FileText className="w-4 h-4 text-indigo-400" />
            {showExtractedData ? 'Hide Extracted Data' : 'View Extracted Data'}
          </button>
          <button
            onClick={() => onNavigateToJobMatcher(analysis.id)}
            className="px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md shadow-indigo-600/20 flex items-center gap-2 active:scale-98"
          >
            <Briefcase className="w-4 h-4" />
            Match Against Job
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            Print / Export
          </button>
          <button
            onClick={onNavigateToUpload}
            className="px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            New Upload
          </button>
        </div>
      </div>

      {/* EXTRACTED RESUME DATA INSPECTION PANEL */}
      {showExtractedData && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-indigo-500/30 shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                Parsed Candidate Profile from Document
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Exact text, contact info, and structural blocks extracted from <strong className="text-slate-200">{analysis.resumeFileName}</strong>
              </p>
            </div>
            <button
              onClick={() => setShowExtractedData(false)}
              className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">Candidate Name</span>
              <p className="text-sm font-semibold text-white">{analysis.parsedData.name || 'Not detected'}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">Email Address</span>
              <p className="text-sm font-mono text-indigo-300 truncate">{analysis.parsedData.email || 'Not detected'}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">Phone Number</span>
              <p className="text-sm font-mono text-slate-200">{analysis.parsedData.phone || 'Not detected'}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">Location</span>
              <p className="text-sm text-slate-200">{analysis.parsedData.location || 'Not detected'}</p>
            </div>
          </div>

          {/* Social Links */}
          {(analysis.parsedData.linkedin || analysis.parsedData.github) && (
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {analysis.parsedData.linkedin && (
                <span className="px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs text-indigo-300 font-mono">
                  LinkedIn: {analysis.parsedData.linkedin}
                </span>
              )}
              {analysis.parsedData.github && (
                <span className="px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs text-cyan-300 font-mono">
                  GitHub: {analysis.parsedData.github}
                </span>
              )}
            </div>
          )}

          {/* Experience list */}
          {analysis.parsedData.experience && analysis.parsedData.experience.length > 0 && (
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Extracted Work Experience ({analysis.parsedData.experience.length} roles)
              </h4>
              <div className="space-y-3">
                {analysis.parsedData.experience.map((exp, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h5 className="text-sm font-bold text-white">
                        {exp.role} <span className="text-slate-400 font-normal">at {exp.company}</span>
                      </h5>
                      <span className="text-xs font-mono text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded">
                        {exp.duration}
                      </span>
                    </div>
                    {exp.bullets && exp.bullets.length > 0 && (
                      <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                        {exp.bullets.map((b, bIdx) => (
                          <li key={bIdx}>{b}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education list */}
          {analysis.parsedData.education && analysis.parsedData.education.length > 0 && (
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Extracted Education ({analysis.parsedData.education.length} entries)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {analysis.parsedData.education.map((edu, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                    <h5 className="text-xs font-bold text-white">{edu.degree}</h5>
                    <p className="text-xs text-slate-400">{edu.institution} • {edu.year}</p>
                    {edu.gpa && <p className="text-[11px] text-emerald-400 font-mono mt-1">GPA: {edu.gpa}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. DUAL HERO GAUGES */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-8 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 shadow-xl flex flex-col items-center justify-center text-center">
          <CircularProgress
            score={analysis.scores.overall}
            size="lg"
            label="Overall Candidate Score"
            sublabel="OVERALL"
            colorVariant="auto"
          />
          <p className="mt-4 text-xs text-slate-400 max-w-xs leading-relaxed">
            Composite score weighting technical depth, ATS compliance, metric quantification, and recruiter readability.
          </p>
        </div>

        <div className="p-8 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 shadow-xl flex flex-col items-center justify-center text-center">
          <CircularProgress
            score={analysis.scores.atsCompatibility}
            size="lg"
            label="ATS Compatibility Score"
            sublabel="ATS READY"
            colorVariant="emerald"
          />
          <p className="mt-4 text-xs text-slate-400 max-w-xs leading-relaxed">
            Meets {analysis.atsChecks.filter(c => c.status === 'passed').length} of {analysis.atsChecks.length} standard Applicant Tracking System parsing checks (Taleo, Greenhouse, Workday).
          </p>
        </div>
      </div>

      {/* 3. 8 SCORE CARDS GRID */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-white tracking-tight">
            Detailed Scoring Breakdown
          </h2>
          <span className="text-xs text-slate-400">8 Core Performance Dimensions</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {scoreCards.map((sc) => (
            <ScoreCard
              key={sc.title}
              title={sc.title}
              score={sc.score}
              icon={sc.icon}
              weight={sc.weight}
              description={sc.desc}
            />
          ))}
        </div>
      </div>

      {/* 4. STRENGTHS & WEAKNESSES SIDE-BY-SIDE */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Strengths */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-emerald-500/20 shadow-lg">
          <div className="flex items-center gap-2.5 mb-4 text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
            <h3 className="font-bold text-base text-white">Core Strengths Detected</h3>
          </div>
          <ul className="space-y-3">
            {analysis.strengths.map((str, idx) => (
              <li key={idx} className="flex items-start gap-3 text-xs text-slate-300 leading-relaxed">
                <span className="w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold border border-emerald-500/30">
                  ✓
                </span>
                <span>{str}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Weaknesses / Improvements */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-amber-500/20 shadow-lg">
          <div className="flex items-center gap-2.5 mb-4 text-amber-400">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="font-bold text-base text-white">Areas for Immediate Improvement</h3>
          </div>
          <ul className="space-y-3">
            {analysis.weaknesses.map((weak, idx) => (
              <li key={idx} className="flex items-start gap-3 text-xs text-slate-300 leading-relaxed">
                <span className="w-5 h-5 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold border border-amber-500/30">
                  !
                </span>
                <span>{weak}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 5. AI RECOMMENDATIONS WITH BEFORE VS AFTER COMPARISONS */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              Prioritized Action Recommendations
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Targeted improvements powered by Gemini 3.8 Flash applying the Google XYZ accomplishment formula.
            </p>
          </div>
          <span className="text-xs font-mono text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-full border border-indigo-500/20">
            {analysis.recommendations.length} Recommendations
          </span>
        </div>

        <div className="space-y-4">
          {analysis.recommendations.map((rec) => {
            const priorityColors = {
              HIGH: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
              MEDIUM: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
              LOW: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30'
            };

            return (
              <div
                key={rec.id}
                className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-4"
              >
                {/* Header tags */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-mono font-bold border ${priorityColors[rec.priority]}`}
                    >
                      {rec.priority} PRIORITY
                    </span>
                    <span className="text-xs font-medium text-slate-400 bg-slate-800 px-2.5 py-0.5 rounded-md">
                      Category: {rec.category}
                    </span>
                  </div>
                  <span className="text-xs text-slate-500">Action Item #{rec.id}</span>
                </div>

                {/* Problem & Why It Matters */}
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">{rec.problem}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    <strong className="text-indigo-300 font-semibold">Why it matters:</strong> {rec.whyItMatters}
                  </p>
                </div>

                {/* Suggested Improvement */}
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300">
                  <strong className="text-slate-200">Recommended action:</strong> {rec.suggestedImprovement}
                </div>

                {/* Interactive Before vs After Comparison */}
                {rec.beforeExample && rec.afterExample && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                    {/* Before */}
                    <div className="p-3.5 rounded-xl bg-rose-500/5 border border-rose-500/20 text-xs">
                      <span className="text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider block mb-1.5">
                        Before (Weak / Unquantified)
                      </span>
                      <p className="text-slate-300 leading-relaxed italic">"{rec.beforeExample}"</p>
                    </div>

                    {/* After */}
                    <div className="relative p-3.5 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-xs group">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                          After (High-Impact XYZ Formula)
                        </span>
                        <button
                          onClick={() => handleCopyBullet(rec.id, rec.afterExample!)}
                          className="text-[11px] text-slate-400 hover:text-emerald-300 flex items-center gap-1 font-medium transition-colors"
                        >
                          {copiedBulletId === rec.id ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                          Copy
                        </button>
                      </div>
                      <p className="text-emerald-200 font-medium leading-relaxed">
                        "{rec.afterExample}"
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 6. SKILL ANALYSIS & GAP MATRIX */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Identified Skills (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <Sliders className="w-5 h-5 text-indigo-400" />
              Verified Skill Breakdown
            </h2>
            <span className="text-xs text-slate-400">Extracted from Experience & Projects</span>
          </div>

          <div className="space-y-6">
            {analysis.skillsBreakdown.map((group) => (
              <div key={group.name} className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  {group.name}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {group.skills.map((s) => (
                    <SkillBar
                      key={s.name}
                      name={s.name}
                      level={s.level}
                      category={s.category}
                      verified={s.verifiedInResume}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Missing Recommended Skills (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            Target Role Skill Gaps
          </h2>

          <div className="space-y-4">
            {analysis.missingRecommendedSkills.map((gap, i) => (
              <div
                key={i}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-200">{gap.role}</h4>
                  <span className="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    Recommended Additions
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {gap.skills.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="text-[11px] text-slate-300 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700/60"
                    >
                      + {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 7. JOB ROLE RECOMMENDATIONS */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-indigo-400" />
              Recommended Job Roles & Market Alignment
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Based on your verified skills, project complexity, and experience depth.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {analysis.jobRoleRecommendations.map((role) => (
            <div
              key={role.id}
              className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div>
                    <h3 className="font-bold text-base text-white">{role.role}</h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">{role.description}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xl font-bold font-mono text-emerald-400">
                      {role.matchPercentage}%
                    </span>
                    <span className="block text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                      Match Fit
                    </span>
                  </div>
                </div>

                {/* Salary & Demand Tags */}
                <div className="flex flex-wrap items-center gap-2 my-4 pt-2 border-t border-slate-800/80">
                  {role.salaryRange && (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-300 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                      <DollarSign className="w-3.5 h-3.5" />
                      {role.salaryRange}
                    </span>
                  )}
                  {role.demandLevel && (
                    <span className="text-xs font-medium text-slate-300 bg-slate-800 px-2.5 py-1 rounded-lg">
                      Market Demand: <strong className="text-indigo-300">{role.demandLevel}</strong>
                    </span>
                  )}
                </div>

                {/* Matching vs Missing Skills */}
                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-[11px] text-slate-400 font-semibold block mb-1">
                      Matching Skills ({role.matchingSkills.length})
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {role.matchingSkills.map((s, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-[11px]"
                        >
                          ✓ {s}
                        </span>
                      ))}
                    </div>
                  </div>

                  {role.missingSkills.length > 0 && (
                    <div className="pt-1">
                      <span className="text-[11px] text-slate-400 font-semibold block mb-1">
                        Skills to Acquire ({role.missingSkills.length})
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {role.missingSkills.map((s, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20 text-[11px]"
                          >
                            + {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-end">
                <button
                  onClick={() => onNavigateToJobMatcher(analysis.id)}
                  className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 transition-colors"
                >
                  Analyze with custom {role.role} JD <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 8. AI PROFESSIONAL SUMMARY GENERATOR */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              AI-Generated Professional Summary
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Tailor your executive opening for distinct audiences with one click.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopySummary}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20"
            >
              {copiedSummary ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedSummary ? 'Copied' : 'Copy Summary'}
            </button>
          </div>
        </div>

        {/* Tone Tabs */}
        <div className="flex flex-wrap gap-2">
          {(['Professional', 'Technical', 'Concise', 'Recruiter-Friendly'] as const).map((tone) => (
            <button
              key={tone}
              onClick={() => handleToneChange(tone)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTone === tone
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
              }`}
            >
              {tone}
            </button>
          ))}
        </div>

        {/* Summary Text Box */}
        <div className="relative">
          <textarea
            rows={4}
            value={summaryText}
            onChange={(e) => setSummaryText(e.target.value)}
            disabled={isRegenerating}
            className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm leading-relaxed focus:outline-none focus:border-indigo-500 resize-none font-medium"
          />
          {isRegenerating && (
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm rounded-2xl flex items-center justify-center text-indigo-400 text-xs font-semibold gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              Regenerating in {activeTone} tone…
            </div>
          )}
        </div>
      </div>

      {/* 9. ATS EXPLAINABILITY BREAKDOWN */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              ATS System Diagnostics & Rules
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Transparent assessment simulating enterprise parser rules.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20 font-semibold">
            Score: {analysis.scores.atsCompatibility}/100
          </span>
        </div>

        {/* Summary text */}
        <p className="text-xs text-slate-300 bg-slate-950 p-4 rounded-xl border border-slate-800 leading-relaxed">
          {analysis.atsExplanation.summary}
        </p>

        {/* Checks Table */}
        <div className="space-y-2">
          {analysis.atsChecks.map((check) => {
            const isPassed = check.status === 'passed';
            return (
              <div
                key={check.id}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-start justify-between gap-4 text-xs"
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {isPassed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    )}
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-200">{check.title}</h4>
                    <p className="text-slate-400 text-[11px] mt-0.5">{check.description}</p>
                  </div>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider shrink-0 ${
                    isPassed
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  }`}
                >
                  {check.status}
                </span>
              </div>
            );
          })}
        </div>

        {/* Educational disclaimer */}
        <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800/60 text-[11px] text-slate-500 leading-relaxed">
          <strong>Transparency Notice:</strong> Applicant Tracking Systems parse resume text linearly into candidate database fields. Scores above 80 indicate high compatibility with automated keyword filters. For best results, avoid multi-column templates, headers/footers for key qualifications, and non-standard symbols.
        </div>
      </div>
    </div>
  );
};
