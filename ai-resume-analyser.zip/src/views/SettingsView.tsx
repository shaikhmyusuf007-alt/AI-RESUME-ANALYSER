import React, { useEffect, useState } from 'react';
import {
  Settings,
  Sun,
  Moon,
  ShieldCheck,
  Cpu,
  Terminal,
  Sparkles,
  Info,
  Layers,
  Database,
  CheckCircle2
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext.js';
import { fetchHealth } from '../lib/api.js';

export const SettingsView: React.FC = () => {
  const { theme, toggleTheme, setTheme } = useTheme();
  const [health, setHealth] = useState<any>(null);

  useEffect(() => {
    fetchHealth().then(setHealth);
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
          <Settings className="w-3.5 h-3.5 text-indigo-400" />
          <span>System & Architecture</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Application Settings & Diagnostics
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Inspect backend status, AI model pipelines, and system configuration.
        </p>
      </div>

      {/* Theme Card */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          {theme === 'dark' ? <Moon className="w-4 h-4 text-indigo-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
          Display Appearance
        </h3>
        <p className="text-xs text-slate-400">
          Toggle between dark aesthetic and high-contrast light mode.
        </p>
        <div className="flex items-center gap-3 pt-1">
          <button
            id="settings-theme-dark-btn"
            onClick={() => setTheme('dark')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 cursor-pointer ${
              theme === 'dark'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
            }`}
          >
            <Moon className="w-4 h-4" />
            Dark Mode (Default)
          </button>
          <button
            id="settings-theme-light-btn"
            onClick={() => setTheme('light')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 cursor-pointer ${
              theme === 'light'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
            }`}
          >
            <Sun className="w-4 h-4" />
            Light Mode
          </button>
        </div>
      </div>

      {/* System Diagnostics Card */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          Production Stack Diagnostics
        </h3>
        <p className="text-xs text-slate-400">
          Real-time status of underlying microservices, in-memory parser, and Gemini integration.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Backend API Status</span>
            <span className="text-emerald-400 font-mono font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {health?.status === 'ok' ? 'Online (200 OK)' : 'Connecting…'}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">AI Intelligence Engine</span>
            <span className="text-cyan-400 font-mono font-bold">
              Gemini 3.8 Flash
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Resume Parser Engine</span>
            <span className="text-emerald-400 font-mono font-bold">
              pdf-parse & mammoth (Buffer)
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Database Schema</span>
            <span className="text-indigo-400 font-mono font-bold">
              PostgreSQL / Prisma ORM
            </span>
          </div>
        </div>
      </div>

      {/* Hackathon Project Credits */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30 space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <h3 className="font-bold text-sm text-white">
            Project: AI Resume Analyser
          </h3>
        </div>
        <div className="text-xs text-slate-300 space-y-1">
          <p>
            <strong>Team:</strong> 404_codeX
          </p>
          <p>
            <strong>Tagline:</strong> “Turn your resume into your career roadmap.”
          </p>
          <p>
            <strong>Objective:</strong> Create an AI-powered resume analysis platform where users can upload their resume (PDF/DOCX) and receive detailed ATS scoring, skill analysis, job-role matching, missing skills, improvement suggestions, and an improved resume summary.
          </p>
        </div>
      </div>
    </div>
  );
};
