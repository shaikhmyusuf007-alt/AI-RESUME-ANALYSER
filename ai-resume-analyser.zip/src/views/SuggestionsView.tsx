import React, { useState } from 'react';
import {
  Lightbulb,
  Sparkles,
  Copy,
  Check,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Target,
  Zap,
  ArrowRight
} from 'lucide-react';
import { ResumeAnalysis } from '../types.js';

interface SuggestionsViewProps {
  analysis: ResumeAnalysis;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const SuggestionsView: React.FC<SuggestionsViewProps> = ({
  analysis,
  onShowToast
}) => {
  const [selectedPriority, setSelectedPriority] = useState<string>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredRecs = analysis.recommendations.filter((rec) => {
    if (selectedPriority !== 'ALL' && rec.priority !== selectedPriority) return false;
    return true;
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast('Rewrite copied to clipboard!', 'success');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const actionVerbs = [
    { category: 'Architect & Build', verbs: ['Architected', 'Spearheaded', 'Engineered', 'Pioneered', 'Implemented', 'Developed'] },
    { category: 'Optimize & Scale', verbs: ['Accelerated', 'Consolidated', 'Streamlined', 'Scaled', 'Maximized', 'Automated'] },
    { category: 'Quantify & Deliver', verbs: ['Decreased', 'Eliminated', 'Generated', 'Expanded', 'Reduced', 'Achieved'] }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
          <Lightbulb className="w-3.5 h-3.5 text-indigo-400" />
          <span>Proven Resume Optimization Playbook</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Improvement Suggestions & Rewrites
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Prioritized bullet enhancements powered by Gemini applying the proven Google XYZ accomplishment formula.
        </p>
      </div>

      {/* Google XYZ Formula Explainer */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30 shadow-lg space-y-3">
        <div className="flex items-center gap-2 text-indigo-300 text-xs font-bold uppercase tracking-wider">
          <Target className="w-4 h-4 text-indigo-400" />
          <span>The Google XYZ Formula Standard</span>
        </div>
        <div className="p-4 rounded-xl bg-slate-950 border border-indigo-500/20 font-mono text-xs text-indigo-200">
          “Accomplished <span className="text-emerald-400 font-bold">[X]</span> as measured by{' '}
          <span className="text-cyan-400 font-bold">[Y]</span>, by doing{' '}
          <span className="text-purple-400 font-bold">[Z]</span>.”
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          Recruiters and hiring managers at Google, Apple, and Amazon look for quantifiable results rather than passive duty lists. Contrast “Worked on backend APIs” with “Architected distributed event queue processing 1.5M transactions daily with 38% latency reduction.”
        </p>
      </div>

      {/* Priority Filters */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-slate-400 mr-2 font-medium">Filter Priority:</span>
        {['ALL', 'HIGH', 'MEDIUM', 'LOW'].map((p) => (
          <button
            key={p}
            onClick={() => setSelectedPriority(p)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              selectedPriority === p
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {p}
          </button>
        ))}
      </div>

      {/* Recommendations List */}
      <div className="space-y-6">
        {filteredRecs.map((rec) => {
          const priorityColors = {
            HIGH: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
            MEDIUM: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
            LOW: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30'
          };

          return (
            <div
              key={rec.id}
              className="p-6 rounded-3xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-4 shadow-md"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-md text-[11px] font-mono font-bold border ${priorityColors[rec.priority]}`}
                  >
                    {rec.priority} PRIORITY
                  </span>
                  <span className="text-xs font-semibold text-slate-300 bg-slate-800 px-2.5 py-0.5 rounded-md">
                    {rec.category}
                  </span>
                </div>
                <span className="text-xs text-slate-500">ID: {rec.id}</span>
              </div>

              <div>
                <h3 className="text-base font-bold text-white mb-1">{rec.problem}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  <strong className="text-slate-200">Why it matters:</strong> {rec.whyItMatters}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
                <strong className="text-indigo-400 font-semibold">Recommended Fix:</strong>{' '}
                {rec.suggestedImprovement}
              </div>

              {/* Before vs After */}
              {rec.beforeExample && rec.afterExample && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/20 text-xs space-y-1">
                    <span className="text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider block">
                      Before (Low Signal)
                    </span>
                    <p className="text-slate-300 italic leading-relaxed">"{rec.beforeExample}"</p>
                  </div>

                  <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                        After (High-Impact XYZ Formula)
                      </span>
                      <button
                        onClick={() => handleCopy(rec.id, rec.afterExample!)}
                        className="text-[11px] text-slate-400 hover:text-emerald-300 flex items-center gap-1 font-semibold transition-colors"
                      >
                        {copiedId === rec.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        Copy Bullet
                      </button>
                    </div>
                    <p className="text-emerald-200 font-medium leading-relaxed">
                      "{rec.afterExample}"
                    </p>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Action Verbs Dictionary */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" />
          High-Impact Action Verbs Cheat Sheet
        </h3>
        <p className="text-xs text-slate-400">
          Replace passive phrasing ("responsible for", "helped with") with active power verbs favored by ATS ranking models:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {actionVerbs.map((grp) => (
            <div key={grp.category} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                {grp.category}
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {grp.verbs.map((v) => (
                  <span
                    key={v}
                    className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-indigo-300 border border-indigo-500/20"
                  >
                    {v}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
