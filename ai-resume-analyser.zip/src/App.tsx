import React, { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { ThemeProvider, useTheme } from './context/ThemeContext.js';
import { Navbar } from './components/Navbar.js';
import { Footer } from './components/Footer.js';
import { Sidebar } from './components/Sidebar.js';
import { ToastContainer, ToastMessage } from './components/ui/Toast.js';
import { LandingView } from './views/LandingView.js';
import { DashboardView } from './views/DashboardView.js';
import { UploadView } from './views/UploadView.js';
import { AnalysisView } from './views/AnalysisView.js';
import { JobMatcherView } from './views/JobMatcherView.js';
import { SkillGapView } from './views/SkillGapView.js';
import { SuggestionsView } from './views/SuggestionsView.js';
import { ResumesView } from './views/ResumesView.js';
import { ProfileView } from './views/ProfileView.js';
import { SettingsView } from './views/SettingsView.js';
import { AuthView } from './views/AuthView.js';
import { ResumeAnalysis } from './types.js';
import { getAllResumes, getSampleDemo, deleteResumeById } from './lib/api.js';
import { Menu, Sparkles, PlayCircle } from 'lucide-react';

export function AppContent() {
  const { user, token } = useAuth();
  const { theme } = useTheme();
  const [currentView, setCurrentView] = useState<string>('landing');
  const [resumes, setResumes] = useState<ResumeAnalysis[]>([]);
  const [activeResume, setActiveResume] = useState<ResumeAnalysis | null>(null);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = 'toast_' + Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Load resumes when user or session token changes
  useEffect(() => {
    async function loadData() {
      if (!token && !user) {
        // Visitor/guest mode: load demo sample so preview is instantly exploratory
        try {
          const sample = await getSampleDemo();
          setResumes([sample]);
          setActiveResume(sample);
        } catch (err) {
          console.warn('Demo load error:', err);
        }
        return;
      }

      try {
        const list = await getAllResumes(token || undefined);
        if (list && list.length > 0) {
          setResumes(list);
          setActiveResume((prev) => (prev ? (list.find((r) => r.id === prev.id) || list[0]) : list[0]));
        } else if (user?.id === 'user_demo_404codex') {
          const sample = await getSampleDemo();
          setResumes([sample]);
          setActiveResume(sample);
        } else {
          // Fresh user account with no resumes yet
          setResumes([]);
          setActiveResume(null);
        }
      } catch (err) {
        console.warn('Initial data load error:', err);
      }
    }
    loadData();
  }, [user?.id, token]);

  // 1-Click "Try Demo" handler
  const handleTryDemo = async () => {
    try {
      const sample = await getSampleDemo();
      setActiveResume(sample);
      // Ensure it is in list
      setResumes((prev) => {
        if (!prev.find((r) => r.id === sample.id)) {
          return [sample, ...prev];
        }
        return prev;
      });
      setCurrentView('analysis');
      addToast('Loaded Demo Sample (Alex Rivera - 84 Score, 81 ATS)', 'success');
    } catch {
      addToast('Could not load demo sample. Please try again.', 'error');
    }
  };

  const handleAnalysisComplete = (newAnalysis: ResumeAnalysis) => {
    setResumes((prev) => [newAnalysis, ...prev.filter((r) => r.id !== newAnalysis.id)]);
    setActiveResume(newAnalysis);
    setCurrentView('analysis');
    addToast('Resume uploaded, saved to database, and analyzed successfully!', 'success');
  };

  const handleUpdateResume = (updated: ResumeAnalysis) => {
    setResumes((prev) =>
      prev.map((r) => (r.id === updated.id || (r.resumeId && r.resumeId === updated.resumeId) ? updated : r))
    );
    if (activeResume?.id === updated.id || (activeResume?.resumeId && activeResume?.resumeId === updated.resumeId)) {
      setActiveResume(updated);
    }
  };

  const handleDeleteResume = async (id: string) => {
    try {
      await deleteResumeById(id, token || undefined);
      const remaining = resumes.filter((r) => r.id !== id);
      setResumes(remaining);
      if (activeResume?.id === id) {
        setActiveResume(remaining[0] || null);
      }
      addToast('Resume and associated analysis removed from storage', 'info');
    } catch (err: any) {
      addToast(err.message || 'Failed to delete resume', 'error');
    }
  };

  const isAppView = [
    'dashboard',
    'analyze',
    'analysis',
    'job-matcher',
    'skill-gap',
    'suggestions',
    'resumes',
    'profile',
    'settings'
  ].includes(currentView);

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} font-sans flex flex-col selection:bg-indigo-500/30 selection:text-indigo-200 transition-colors duration-200`}>
      <ToastContainer toasts={toasts} onDismiss={removeToast} />

      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={(view) => setCurrentView(view)}
        onTryDemo={handleTryDemo}
      />

      {/* Main Layout Body */}
      <div className="flex-1 flex w-full">
        {/* Sidebar (visible on app/dashboard views) */}
        {isAppView && (
          <Sidebar
            currentView={currentView}
            onNavigate={(view) => setCurrentView(view)}
            mobileOpen={mobileSidebarOpen}
            onCloseMobile={() => setMobileSidebarOpen(false)}
          />
        )}

        {/* View Content Area */}
        <main className="flex-1 flex flex-col min-w-0">
          {/* Mobile sub-header with hamburger if on app views */}
          {isAppView && (
            <div className="lg:hidden px-4 py-2.5 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between transition-colors">
              <button
                onClick={() => setMobileSidebarOpen(true)}
                className="p-1.5 rounded-lg text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 text-xs font-semibold"
              >
                <Menu className="w-4 h-4" />
                <span>Menu</span>
              </button>
              <button
                onClick={handleTryDemo}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30"
              >
                <PlayCircle className="w-3.5 h-3.5" />
                Demo Mode
              </button>
            </div>
          )}

          <div className="flex-1">
            {currentView === 'landing' && (
              <LandingView
                onAnalyze={() => setCurrentView('analyze')}
                onTryDemo={handleTryDemo}
                onNavigate={(v) => setCurrentView(v)}
              />
            )}

            {currentView === 'dashboard' && (
              <DashboardView
                resumes={resumes}
                activeResume={activeResume}
                onSelectResume={(r) => {
                  setActiveResume(r);
                  setCurrentView('analysis');
                }}
                onDeleteResume={handleDeleteResume}
                onNavigate={(v) => setCurrentView(v)}
                onTryDemo={handleTryDemo}
                onUpdateResume={handleUpdateResume}
                onShowToast={addToast}
              />
            )}

            {currentView === 'analyze' && (
              <UploadView
                onAnalysisComplete={handleAnalysisComplete}
                onTryDemo={handleTryDemo}
              />
            )}

            {currentView === 'analysis' && (
              activeResume ? (
                <AnalysisView
                  analysis={activeResume}
                  onNavigateToJobMatcher={(id) => {
                    const target = resumes.find((r) => r.id === id);
                    if (target) setActiveResume(target);
                    setCurrentView('job-matcher');
                  }}
                  onNavigateToUpload={() => setCurrentView('analyze')}
                  onShowToast={addToast}
                />
              ) : (
                <div className="p-12 text-center">
                  <p className="text-slate-400 mb-4">No resume currently selected.</p>
                  <button
                    onClick={handleTryDemo}
                    className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
                  >
                    Load Sample Candidate
                  </button>
                </div>
              )
            )}

            {currentView === 'job-matcher' && (
              <JobMatcherView
                currentResume={activeResume}
                resumes={resumes}
                onShowToast={addToast}
              />
            )}

            {currentView === 'skill-gap' && (
              activeResume ? (
                <SkillGapView
                  analysis={activeResume}
                  onNavigateToJobMatcher={() => setCurrentView('job-matcher')}
                />
              ) : (
                <div className="p-12 text-center text-slate-400">
                  Select a resume from the dashboard first.
                </div>
              )
            )}

            {currentView === 'suggestions' && (
              activeResume ? (
                <SuggestionsView
                  analysis={activeResume}
                  onShowToast={addToast}
                />
              ) : (
                <div className="p-12 text-center text-slate-400">
                  Select a resume from the dashboard first.
                </div>
              )
            )}

            {currentView === 'resumes' && (
              <ResumesView
                resumes={resumes}
                onSelectResume={(r) => {
                  setActiveResume(r);
                  setCurrentView('analysis');
                }}
                onDeleteResume={handleDeleteResume}
                onNavigateToUpload={() => setCurrentView('analyze')}
                onTryDemo={handleTryDemo}
                onUpdateResume={handleUpdateResume}
                onShowToast={addToast}
              />
            )}

            {currentView === 'profile' && (
              <ProfileView onShowToast={addToast} />
            )}

            {currentView === 'settings' && (
              <SettingsView />
            )}

            {(currentView === 'login' || currentView === 'register') && (
              <AuthView
                initialMode={currentView as 'login' | 'register'}
                onSuccess={() => setCurrentView('dashboard')}
                onShowToast={addToast}
                onNavigate={(v) => setCurrentView(v)}
              />
            )}
          </div>
        </main>
      </div>

      {/* Footer (only on landing or non-dashboard views) */}
      {!isAppView && <Footer onNavigate={(v) => setCurrentView(v)} />}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
