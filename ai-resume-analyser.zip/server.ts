import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { db, verifyPassword } from './server/db.js';
import { extractTextFromBuffer, parseResumeSections } from './server/parser.js';
import { analyzeResumeWithAI, generateSummaryByTone, compareResumeWithJob } from './server/geminiService.js';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body parsing with generous limit for resume buffers
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));

  // Request logger for API endpoints
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      console.log(`[API] ${req.method} ${req.path}`);
    }
    next();
  });

  // ----------------------------------------------------
  // AUTHENTICATION HELPER MIDDLEWARE
  // ----------------------------------------------------
  function extractAuthUser(req: express.Request) {
    const authHeader = req.headers.authorization;
    let token: string | undefined;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7).trim();
    } else if (req.query && typeof req.query.token === 'string') {
      token = req.query.token.trim();
    }

    if (!token) return null;
    return db.getUserByToken(token);
  }

  function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
    const user = extractAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required. Please sign in to access your data.' });
    }
    (req as any).user = user;
    (req as any).userId = user.id;
    next();
  }

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      team: '404_codeX',
      product: 'AI Resume Analyser',
      storage: 'Persistent JSON Database & Local Storage Engine',
      hasGeminiKey: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY')
    });
  });

  // ----------------------------------------------------
  // AUTHENTICATION ROUTES
  // ----------------------------------------------------
  app.post('/api/auth/register', (req, res) => {
    try {
      const { name, email, password, targetRole, experienceLevel } = req.body;
      if (!name || typeof name !== 'string' || !name.trim()) {
        return res.status(400).json({ error: 'Full name is required.' });
      }
      if (!email || typeof email !== 'string' || !email.trim()) {
        return res.status(400).json({ error: 'Valid email address is required.' });
      }
      const cleanEmail = email.toLowerCase().trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(cleanEmail)) {
        return res.status(400).json({ error: 'Please provide a valid email format (e.g. name@domain.com).' });
      }
      if (!password || typeof password !== 'string' || password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      }

      const { user, token } = db.createUser(name, cleanEmail, password, targetRole, experienceLevel);
      return res.status(201).json({ user, token });
    } catch (err: any) {
      return res.status(400).json({ error: err.message || 'Registration failed' });
    }
  });

  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || typeof email !== 'string' || !email.trim()) {
      return res.status(400).json({ error: 'Email address is required.' });
    }
    if (!password || typeof password !== 'string') {
      return res.status(400).json({ error: 'Password is required.' });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = db.getUserByEmail(cleanEmail);
    if (!user) {
      return res.status(401).json({
        error: 'No account found with this email. Please check your credentials or create an account.'
      });
    }

    const isMatch = verifyPassword(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Incorrect password. Please verify and try again.' });
    }

    const token = db.createSession(user.id);
    const { passwordHash, ...safeUser } = user;
    return res.json({
      user: safeUser,
      token
    });
  });

  app.post('/api/auth/logout', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7).trim();
      db.revokeSession(token);
    }
    return res.json({ success: true, message: 'Logged out successfully.' });
  });

  app.post('/api/auth/forgot-password', (req, res) => {
    const { email } = req.body;
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ error: 'Email address is required.' });
    }
    const cleanEmail = email.toLowerCase().trim();
    const user = db.getUserByEmail(cleanEmail);
    if (!user) {
      return res.status(404).json({ error: 'No account was found with that email address.' });
    }
    db.resetUserPassword(cleanEmail, 'temp123456');
    return res.json({
      message: `Password reset instructions sent to ${cleanEmail}. You may use 'temp123456' as your temporary password.`,
      tempPasswordHint: 'temp123456'
    });
  });

  app.get('/api/auth/me', (req, res) => {
    const user = extractAuthUser(req);
    if (!user) {
      return res.json({ user: null });
    }
    const { passwordHash, ...safeUser } = user;
    return res.json({ user: safeUser });
  });

  app.put('/api/auth/profile', requireAuth, (req, res) => {
    try {
      const userId = (req as any).userId;
      const { targetRole, experienceLevel, preferredIndustry, skills, name, bio, phone, location, preferences } = req.body;
      const updated = db.updateUserProfile(userId, {
        targetRole,
        experienceLevel,
        preferredIndustry,
        skills,
        name,
        bio,
        phone,
        location,
        preferences
      });
      return res.json({ user: updated });
    } catch (err: any) {
      return res.status(400).json({ error: err.message });
    }
  });

  // ----------------------------------------------------
  // RESUME UPLOAD & PARSING ROUTES
  // ----------------------------------------------------
  app.post('/api/resume/upload', requireAuth, async (req, res) => {
    try {
      const userId = (req as any).userId;
      const { fileName, fileType, fileBase64, rawTextContent } = req.body;
      if (!fileName) {
        return res.status(400).json({ error: 'File name is required.' });
      }

      let extractedText = '';
      let fileSize = 0;
      let buffer: Buffer | undefined;

      if (fileBase64) {
        buffer = Buffer.from(fileBase64, 'base64');
        fileSize = buffer.length;
        if (fileSize > 12 * 1024 * 1024) {
          return res.status(400).json({ error: 'File size exceeds maximum 12MB limit.' });
        }
        extractedText = await extractTextFromBuffer(buffer, fileType || 'application/pdf', fileName);
      } else if (rawTextContent) {
        extractedText = rawTextContent;
        fileSize = Buffer.byteLength(rawTextContent, 'utf-8');
      } else {
        return res.status(400).json({ error: 'Please provide either a PDF/DOCX file or text content.' });
      }

      if (!extractedText || extractedText.trim().length < 30) {
        return res.status(422).json({
          error: 'Could not extract readable text from the uploaded file. Please ensure the document is not an image scan or password protected.'
        });
      }

      const parsedData = parseResumeSections(extractedText);

      // Persist resume and file to disk partitioned by userId
      const storedResume = db.saveUploadedResume(userId, {
        fileName,
        fileType: fileType || (fileBase64 ? 'application/pdf' : 'text/plain'),
        fileSize,
        fileBuffer: buffer,
        rawText: extractedText,
        parsedData
      });

      return res.json({
        success: true,
        resumeId: storedResume.id,
        fileName: storedResume.fileName,
        fileSize: storedResume.fileSize,
        fileUrl: storedResume.fileUrl,
        storagePath: storedResume.storagePath,
        rawText: extractedText,
        parsedData
      });
    } catch (err: any) {
      console.error('Error in /api/resume/upload:', err);
      return res.status(500).json({ error: 'Resume extraction failed: ' + (err.message || 'Unknown error') });
    }
  });

  // Run AI analysis and associate with user & resume ID
  app.post('/api/resume/analyze', requireAuth, async (req, res) => {
    try {
      const userId = (req as any).userId;
      const { resumeId, fileName, fileSize, rawText, parsedData } = req.body;
      const textToAnalyze = rawText || (parsedData && parsedData.rawText);
      if (!textToAnalyze || !fileName) {
        return res.status(400).json({ error: 'Missing resume text or filename.' });
      }

      // Check if resume exists and belongs to user
      let targetResumeId = resumeId;
      if (resumeId) {
        const existing = db.getResumeById(resumeId, userId);
        if (!existing) {
          return res.status(403).json({ error: 'Unauthorized: Resume not found or does not belong to your account.' });
        }
      } else {
        // If resumeId wasn't passed, create stored resume first
        const structuredParsed = parsedData || parseResumeSections(textToAnalyze);
        const stored = db.saveUploadedResume(userId, {
          fileName,
          fileType: 'text/plain',
          fileSize: fileSize || Buffer.byteLength(textToAnalyze, 'utf-8'),
          rawText: textToAnalyze,
          parsedData: structuredParsed
        });
        targetResumeId = stored.id;
      }

      const structuredParsedData = parsedData || parseResumeSections(textToAnalyze);
      const analysis = await analyzeResumeWithAI({
        fileName,
        fileSize: fileSize || Buffer.byteLength(textToAnalyze, 'utf-8'),
        rawText: textToAnalyze,
        parsedData: structuredParsedData
      });

      analysis.resumeId = targetResumeId;

      // Save analysis in persistent database
      const storedAnalysis = db.saveResumeAnalysis(analysis, userId);

      return res.json({ success: true, analysis: storedAnalysis.fullAnalysis });
    } catch (err: any) {
      console.error('Error in /api/resume/analyze:', err);
      return res.status(500).json({ error: 'AI Analysis failed: ' + (err.message || 'Unknown error') });
    }
  });

  // Re-run AI analysis on an existing stored resume
  app.post('/api/resume/:id/reanalyze', requireAuth, async (req, res) => {
    try {
      const userId = (req as any).userId;
      const { id } = req.params;

      const record = db.getResumeById(id, userId);
      if (!record) {
        return res.status(404).json({ error: 'Resume not found or unauthorized.' });
      }

      const { resume } = record;
      const textToAnalyze = resume.rawText;
      const structuredParsedData = resume.parsedData || parseResumeSections(textToAnalyze);

      const freshAnalysis = await analyzeResumeWithAI({
        fileName: resume.fileName,
        fileSize: resume.fileSize,
        rawText: textToAnalyze,
        parsedData: structuredParsedData
      });

      freshAnalysis.resumeId = resume.id;
      const storedAnalysis = db.saveResumeAnalysis(freshAnalysis, userId);

      return res.json({ success: true, analysis: storedAnalysis.fullAnalysis });
    } catch (err: any) {
      console.error('Error in /api/resume/:id/reanalyze:', err);
      return res.status(500).json({ error: 'Re-analysis failed: ' + (err.message || 'Unknown error') });
    }
  });

  // Get all resumes for the authenticated user
  app.get('/api/resume', requireAuth, (req, res) => {
    const userId = (req as any).userId;
    const resumes = db.getResumesByUser(userId);
    return res.json({ resumes });
  });

  // Get single resume by id with authorization check
  app.get('/api/resume/:id', requireAuth, (req, res) => {
    const userId = (req as any).userId;
    const { id } = req.params;

    const result = db.getResumeById(id, userId);
    if (!result) {
      return res.status(404).json({ error: 'Resume not found or unauthorized.' });
    }

    // Return analysis if available
    const analysis = result.analysis || db.getResumeAnalysis(id, userId);
    return res.json({ resume: result.resume, analysis });
  });

  // Stream or download original resume file with authentication & access control
  app.get('/api/resume/:id/file', (req, res) => {
    const user = extractAuthUser(req);
    if (!user) {
      return res.status(401).send('Authentication required to view resume file.');
    }

    const { id } = req.params;
    const fileInfo = db.getResumeFile(id, user.id);
    if (!fileInfo) {
      return res.status(404).send('File not found or unauthorized.');
    }

    res.setHeader('Content-Type', fileInfo.fileType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(fileInfo.fileName)}"`);
    res.setHeader('Content-Length', fileInfo.fileSize);
    return res.sendFile(fileInfo.fullPath);
  });

  // Delete resume with authorization check
  app.delete('/api/resume/:id', requireAuth, (req, res) => {
    try {
      const userId = (req as any).userId;
      const { id } = req.params;
      const deleted = db.deleteResume(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: 'Resume not found or unauthorized.' });
      }
      return res.json({ success: true, message: 'Resume and associated analysis deleted successfully.' });
    } catch (err: any) {
      return res.status(403).json({ error: err.message || 'Failed to delete resume.' });
    }
  });

  // ----------------------------------------------------
  // JOB MATCHER ROUTE
  // ----------------------------------------------------
  app.post('/api/job-match', requireAuth, async (req, res) => {
    try {
      const userId = (req as any).userId;
      const { resumeId, jobTitle, companyName, jobDescription } = req.body;
      if (!jobDescription || jobDescription.trim().length < 20) {
        return res.status(400).json({ error: 'Please paste a valid job description with at least 20 characters.' });
      }

      let resume = resumeId ? db.getResumeAnalysis(resumeId, userId) : undefined;
      if (!resume) {
        const userResumes = db.getResumesByUser(userId);
        resume = userResumes[0] || db.getSampleDemo();
      }

      const matchResult = await compareResumeWithJob(resume, jobTitle, companyName, jobDescription);
      db.saveJobMatch(matchResult, userId);
      return res.json({ success: true, matchResult });
    } catch (err: any) {
      console.error('Error in /api/job-match:', err);
      return res.status(500).json({ error: 'Job matching failed: ' + (err.message || 'Unknown error') });
    }
  });

  app.get('/api/job-match/:id', requireAuth, (req, res) => {
    const userId = (req as any).userId;
    const { id } = req.params;
    const match = db.getJobMatch(id, userId);
    if (!match) {
      return res.status(404).json({ error: 'Job match result not found.' });
    }
    return res.json({ matchResult: match });
  });

  // ----------------------------------------------------
  // AI SUMMARY REGENERATION ROUTE
  // ----------------------------------------------------
  app.post('/api/ai/summary', async (req, res) => {
    try {
      const { summary, tone, skills } = req.body;
      if (!summary || !tone) {
        return res.status(400).json({ error: 'Summary and tone are required.' });
      }

      const generated = await generateSummaryByTone(summary, tone, skills || []);
      return res.json({ success: true, summary: generated, tone });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to generate summary: ' + err.message });
    }
  });

  // ----------------------------------------------------
  // HACKATHON DEMO ROUTE (Instant sample for testing)
  // ----------------------------------------------------
  app.get('/api/demo/sample', (req, res) => {
    const sample = db.getSampleDemo();
    return res.json({
      success: true,
      analysis: sample,
      team: '404_codeX',
      tagline: 'Turn your resume into your career roadmap.'
    });
  });

  // ----------------------------------------------------
  // VITE / STATIC MIDDLEWARE
  // ----------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isHmrDisabled ? false : undefined,
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[404_codeX] AI Resume Analyser server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
