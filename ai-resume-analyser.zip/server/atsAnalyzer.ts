import { ATSCheckItem, ParsedResumeData } from '../src/types.js';

export interface ATSAnalysisOutput {
  atsScore: number;
  checks: ATSCheckItem[];
  wordCount: number;
  detectedHeadings: string[];
  quantifiableMetricsCount: number;
  actionVerbsCount: number;
  readabilityScore: string;
  explanation: string;
}

export function performATSAnalysis(parsed: ParsedResumeData, rawText: string): ATSAnalysisOutput {
  const checks: ATSCheckItem[] = [];
  let score = 100;

  const words = rawText.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  // 1. Contact Information Check
  const hasEmail = Boolean(parsed.email && parsed.email.includes('@'));
  const hasPhone = Boolean(parsed.phone && parsed.phone.length > 7);
  const hasLocation = Boolean(parsed.location && parsed.location.length > 3);
  const hasLinkedIn = Boolean(parsed.linkedin || rawText.toLowerCase().includes('linkedin'));

  if (hasEmail && hasPhone && hasLocation) {
    checks.push({
      id: 'contact_info',
      title: 'Contact Information Completeness',
      status: 'passed',
      description: 'Full name, email, phone number, and location are cleanly detectable in the header.',
      scoreImpact: 0,
      recommendation: 'Header is optimized for automated ATS candidate record creation.'
    });
  } else {
    const missing: string[] = [];
    if (!hasEmail) missing.push('Email');
    if (!hasPhone) missing.push('Phone');
    if (!hasLocation) missing.push('Location');
    score -= 10;
    checks.push({
      id: 'contact_info',
      title: 'Incomplete Contact Details',
      status: 'failed',
      description: `Missing contact attributes: ${missing.join(', ')}.`,
      scoreImpact: -10,
      recommendation: 'Place email, phone, location, and LinkedIn URL in clear plain text at the very top.'
    });
  }

  // 2. Standard Section Headings
  const expectedHeadings = ['Experience', 'Education', 'Skills', 'Projects', 'Summary'];
  const detectedHeadings: string[] = [];
  const lowerText = rawText.toLowerCase();

  if (/(experience|work history|employment)/i.test(lowerText)) detectedHeadings.push('Experience');
  if (/(education|academics|degree)/i.test(lowerText)) detectedHeadings.push('Education');
  if (/(skills|competencies|technologies)/i.test(lowerText)) detectedHeadings.push('Skills');
  if (/(projects|portfolio|technical work)/i.test(lowerText)) detectedHeadings.push('Projects');
  if (/(summary|profile|about me|objective)/i.test(lowerText)) detectedHeadings.push('Summary');
  if (/(certifications|certificates|licenses)/i.test(lowerText)) detectedHeadings.push('Certifications');

  const missingHeadings = expectedHeadings.filter(h => !detectedHeadings.includes(h));
  if (missingHeadings.length === 0) {
    checks.push({
      id: 'standard_headings',
      title: 'Standard Section Hierarchy',
      status: 'passed',
      description: 'Used conventional, unambiguous section headings recognized by Taleo, Greenhouse, and Workday.',
      scoreImpact: 0,
      recommendation: 'Maintains clear structural boundaries for high parsing fidelity.'
    });
  } else {
    score -= 8;
    checks.push({
      id: 'standard_headings',
      title: 'Non-Standard or Missing Headings',
      status: 'warning',
      description: `Potential missing standard sections: ${missingHeadings.join(', ')}.`,
      scoreImpact: -8,
      recommendation: 'Use standard titles like "Work Experience", "Education", and "Technical Skills".'
    });
  }

  // 3. Action Verbs
  const strongActionVerbs = [
    'spearheaded', 'architected', 'engineered', 'optimized', 'accelerated',
    'automated', 'orchestrated', 'built', 'deployed', 'scaled', 'implemented',
    'designed', 'refactored', 'streamlined', 'mentored', 'developed', 'delivered'
  ];
  const foundVerbs = strongActionVerbs.filter(v => new RegExp(`\\b${v}\\b`, 'i').test(rawText));
  const actionVerbsCount = foundVerbs.length;

  if (actionVerbsCount >= 6) {
    checks.push({
      id: 'action_verbs',
      title: 'High-Impact Action Verbs',
      status: 'passed',
      description: `Found ${actionVerbsCount} strong power verbs (${foundVerbs.slice(0, 4).join(', ')}, etc.).`,
      scoreImpact: 0,
      recommendation: 'Strong verb usage drives active responsibility perception.'
    });
  } else {
    score -= 6;
    checks.push({
      id: 'action_verbs',
      title: 'Passive Action Verbs',
      status: 'warning',
      description: `Only found ${actionVerbsCount} strong action verbs. Many bullets may rely on passive verbs like "responsible for" or "worked on".`,
      scoreImpact: -6,
      recommendation: 'Begin every bullet point with strong active verbs (e.g., "Engineered", "Reduced", "Orchestrated").'
    });
  }

  // 4. Quantifiable Achievements & Metrics
  const metricRegex = /(\d+%\s*|\$\d+[\d,.]*(?:k|m|b)?|\b\d+(?:x|\+)\b|\b\d+\s*(?:ms|seconds|minutes|hours|days|users|requests|events|stars)\b)/gi;
  const matches = rawText.match(metricRegex) || [];
  const quantifiableMetricsCount = matches.length;

  if (quantifiableMetricsCount >= 4) {
    checks.push({
      id: 'quantifiable_metrics',
      title: 'Quantified Business Impact',
      status: 'passed',
      description: `Found ${quantifiableMetricsCount} measurable metrics and numeric indicators demonstrating tangible business impact.`,
      scoreImpact: 0,
      recommendation: 'Numbers catch both recruiter eye-tracking and ATS ranking algorithms.'
    });
  } else {
    score -= 10;
    checks.push({
      id: 'quantifiable_metrics',
      title: 'Missing Quantifiable Achievements',
      status: 'warning',
      description: `Only detected ${quantifiableMetricsCount} numeric achievements. ATS and recruiters favor measurable metrics (e.g. "reduced latency by 35%").`,
      scoreImpact: -10,
      recommendation: 'Convert generic duties into XYZ formulas: "Accomplished [X], as measured by [Y], by doing [Z]".'
    });
  }

  // 5. Length & Word Density
  let lengthStatus: 'passed' | 'warning' = 'passed';
  if (wordCount >= 350 && wordCount <= 1100) {
    checks.push({
      id: 'word_density',
      title: 'Optimal Word Density',
      status: 'passed',
      description: `Resume length is ${wordCount} words, within the golden 1-to-2 page standard ratio.`,
      scoreImpact: 0,
      recommendation: 'Preserves balanced white space and readable density.'
    });
  } else if (wordCount < 350) {
    score -= 8;
    checks.push({
      id: 'word_density',
      title: 'Resume Too Short or Underdeveloped',
      status: 'warning',
      description: `Resume contains only ${wordCount} words, which may suggest insufficient depth or brief descriptions.`,
      scoreImpact: -8,
      recommendation: 'Elaborate on technical project implementations, measurable outcomes, and toolchains.'
    });
  } else {
    score -= 5;
    checks.push({
      id: 'word_density',
      title: 'High Word Count / Potential Overcrowding',
      status: 'warning',
      description: `Resume contains ${wordCount} words, exceeding standard single/two-page density.`,
      scoreImpact: -5,
      recommendation: 'Trim older or secondary roles to keep bullet points high-signal and punchy.'
    });
  }

  // 6. Tables, Columns & Unusual Formatting Detection
  const hasTabularNoise = /\|\s*[-–]+\s*\||\t{2,}|(\s{6,})/.test(rawText);
  if (!hasTabularNoise) {
    checks.push({
      id: 'table_parsing',
      title: 'Linear Single-Column Parser Friendly',
      status: 'passed',
      description: 'No convoluted table structures or complex multi-column blocks that scramble parser reading order.',
      scoreImpact: 0,
      recommendation: 'Safe for legacy and modern ATS parsers.'
    });
  } else {
    score -= 4;
    checks.push({
      id: 'table_parsing',
      title: 'Complex Columns or Tables Detected',
      status: 'warning',
      description: 'Detected multi-column tab stops or table formatting that may cause ATS to read text out of order.',
      scoreImpact: -4,
      recommendation: 'Stick to clean linear top-to-bottom hierarchy without multi-column body tables.'
    });
  }

  // 7. Skills Section Separation
  const totalSkills = (parsed.skills.technical?.length || 0) + (parsed.skills.frameworks?.length || 0) + (parsed.skills.languages?.length || 0);
  if (totalSkills >= 8) {
    checks.push({
      id: 'skill_extraction',
      title: 'Explicit Skills Inventory',
      status: 'passed',
      description: `Extracted ${totalSkills} core technical skills, frameworks, and programming languages.`,
      scoreImpact: 0,
      recommendation: 'High keyword density enhances algorithmic query ranking.'
    });
  } else {
    score -= 8;
    checks.push({
      id: 'skill_extraction',
      title: 'Low Explicit Skill Keyword Density',
      status: 'warning',
      description: `Only ${totalSkills} industry keywords were explicitly recognized in your skills section.`,
      scoreImpact: -8,
      recommendation: 'Add a dedicated categorized skills section listing languages, frameworks, cloud tools, and databases.'
    });
  }

  // Clamp score between 40 and 99
  const finalAtsScore = Math.max(45, Math.min(96, Math.round(score)));

  return {
    atsScore: finalAtsScore,
    checks,
    wordCount,
    detectedHeadings,
    quantifiableMetricsCount,
    actionVerbsCount,
    readabilityScore: wordCount > 700 ? '9th - 10th Grade (Optimal Professional)' : '8th - 9th Grade (Fast Recruiter Scan)',
    explanation: `Calculated from 7 core ATS algorithmic filters: Header integrity, standard heading hierarchy, action verb frequency (${actionVerbsCount} detected), quantifiable achievement density (${quantifiableMetricsCount} metrics), and clean linear parsing syntax. ATS scoring evaluates readability and keyword matching; it does not guarantee hiring decisions.`
  };
}
