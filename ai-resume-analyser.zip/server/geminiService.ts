import { GoogleGenAI } from '@google/genai';
import {
  ParsedResumeData,
  ResumeAnalysis,
  ScoreBreakdown,
  SkillCategory,
  AIRecommendation,
  JobRoleRecommendation,
  JobMatchResult
} from '../src/types.js';
import { performATSAnalysis } from './atsAnalyzer.js';

let geminiClient: GoogleGenAI | null = null;

function getGemini(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY || process.env.AI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey === 'MY_AI_API_KEY') {
    return null;
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

export interface AnalyzeResumeInput {
  fileName: string;
  fileSize: number;
  rawText: string;
  parsedData: ParsedResumeData;
}

// Resilient multi-model executor with automatic fallback on 503 high-demand or rate-limits
async function callGeminiModelsWithFallback(
  ai: GoogleGenAI,
  prompt: string,
  isJson: boolean = true
): Promise<any> {
  // Prioritize high-availability, low-latency models; avoid deprecated or overloaded aliases
  const modelsToTry = [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-3.8-flash',
    'gemini-flash-latest'
  ];

  let lastError: any = null;

  for (const model of modelsToTry) {
    try {
      console.log(`[GeminiService] Attempting generation via model: ${model}`);

      // 7-second safeguard timeout per model to prevent stalling on high-demand 503 queues
      const responsePromise = ai.models.generateContent({
        model,
        contents: prompt,
        config: isJson
          ? { responseMimeType: 'application/json', temperature: 0.15 }
          : { temperature: 0.2 }
      });

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Model ${model} timed out after 7000ms`)), 7000)
      );

      const response: any = await Promise.race([responsePromise, timeoutPromise]);
      const responseText = response.text?.trim() || '';
      if (!responseText) {
        throw new Error(`Empty response returned from model ${model}`);
      }

      if (isJson) {
        // Strip markdown code fences if present in JSON mode
        const cleanedJson = responseText.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim();
        const parsed = JSON.parse(cleanedJson);
        console.log(`[GeminiService] Successfully generated structured output via ${model}`);
        return parsed;
      }

      console.log(`[GeminiService] Successfully generated text output via ${model}`);
      return responseText;
    } catch (err: any) {
      // Gracefully handle high-demand 503 or transient unavailability
      const errMsg = err?.message || String(err);
      console.info(`[GeminiService] Model ${model} unavailable (${errMsg.slice(0, 100)}). Falling back...`);
      lastError = err;
    }
  }

  throw lastError || new Error('All candidate Gemini models were temporarily busy.');
}

export async function analyzeResumeWithAI(input: AnalyzeResumeInput): Promise<ResumeAnalysis> {
  const { fileName, fileSize, rawText, parsedData } = input;
  const atsOutput = performATSAnalysis(parsedData, rawText);
  const ai = getGemini();

  if (ai) {
    try {
      const prompt = `You are a Principal Technical Recruiter and Career Strategist at a tier-1 company.
Your job is to thoroughly, rigorously, and objectively analyze the following resume.
DO NOT provide generic or random advice. Every critique, strength, weakness, and example MUST be directly grounded in the candidate's actual text provided below.

==================================================
RESUME DOCUMENT: ${fileName}
RAW TEXT CONTENT:
---
${rawText.slice(0, 10000)}
---
==================================================

CRITICAL ANALYSIS MANDATES:
1. IDENTIFY THE REAL CANDIDATE: Extract their actual full name, email, phone, location, LinkedIn, GitHub, and real background. Never substitute generic placeholders.
2. GROUNDED "beforeExample" AND "afterExample":
   - In "recommendations", every "beforeExample" MUST BE AN ACTUAL SENTENCE OR BULLET POINT EXTRACTED VERBATIM FROM THE RESUME TEXT ABOVE. Do NOT fabricate generic text like "Managed a web development team".
   - "afterExample" MUST BE an elevated, high-impact rewrite of that EXACT sentence, following Google's XYZ formula ("Accomplished [X], as measured by [Y], by doing [Z]").
3. REAL STRENGTHS & WEAKNESSES:
   - In "strengths", cite concrete details from their resume (e.g. specific metrics, specific libraries, specific systems they built).
   - In "weaknesses", point out genuine gaps found in their document (e.g. unquantified bullets, missing sections, passive language).
4. TAILORED JOB ROLES:
   - Identify 3-4 job roles that accurately match THIS candidate's actual specialization (e.g. Senior Frontend, Cloud Platform Engineer, Data Scientist, Full Stack, Mobile Developer).
   - "matchingSkills" must only list skills present in their resume.
   - "missingSkills" must list high-leverage skills that would make them more competitive for that role.
5. OBJECTIVE SCORING RUBRIC (CRITICAL: BE REALISTIC AND HONEST - NEVER DEFAULT TO ~84):
   Evaluate the resume with genuine professional scrutiny across 7 independent dimensions on a 35 to 98 scale:
   - "skills" (35-98):
     * <4 skills or only basic markup/syntax: 35-55
     * 4-7 basic or isolated skills: 56-69
     * 8-13 well-rounded modern skills (languages, frameworks, DBs, tools): 70-84
     * 14+ rich multi-stack mastery including cloud infrastructure, testing, and modern frameworks: 85-98
   - "experience" (35-98):
     * Vague duty lists ("responsible for", "worked on"), 0 quantifiable metrics: 40-62
     * 1-2 minor metrics, routine maintenance tasks: 63-74
     * 3-5 solid metrics (% improvements, latency reductions, user scale), active power verbs: 75-86
     * 6+ outstanding XYZ formula metrics, enterprise impact, leadership trajectory: 87-98
   - "projects" (35-98):
     * 0 projects or only brief coursework titles: 35-52
     * 1 simple project with minimal stack details: 53-68
     * 2 well-defined projects with modern stack and clear architecture: 69-84
     * 3+ deployed, high-impact systems with repositories/links: 85-98
   - "education" (35-98):
     * No education listed: 35-50
     * Incomplete, unaccredited, or unrelated coursework: 51-68
     * Accredited Bachelor's in CS / Engineering / STEM: 75-86
     * Master's, PhD, or top recognized certifications (AWS Solution Architect, CKA): 87-98
   - "formatting" (35-98):
     * Multi-column tables, parse errors, inconsistent dates, poor line spacing: 40-65
     * Acceptable linear structure with minor spacing/bullet issues: 66-78
     * Clean standard margins, consistent typography, perfect bullet hierarchy: 79-95
   - "keywords" (35-98):
     * Missing modern industry terminology, architectures, and methodologies: 40-64
     * Moderate keyword alignment: 65-78
     * Strong keyword presence aligned with recruiter search indexing: 79-95
   - "overall" (35-98):
     * Must be an accurate weighted mathematical composite:
       round(atsCompatibility * 0.25 + experience * 0.25 + skills * 0.20 + projects * 0.12 + education * 0.10 + formatting * 0.08)
     * DO NOT force scores into the 80s! If the candidate is junior, incomplete, or lacking numbers, score them honestly (e.g. 52, 64, 71). If exceptional, score them high (88-95).
6. STRICT JSON OUTPUT: Return ONLY a valid JSON object matching the schema below without markdown formatting or commentary.

SCHEMA:
{
  "candidateInfo": {
    "name": string,
    "email": string,
    "phone": string,
    "location": string,
    "linkedin": string,
    "github": string,
    "portfolio": string,
    "summary": string (a customized 2-3 sentence executive summary accurately reflecting this candidate's career level and tech stack)
  },
  "extractedProfile": {
    "education": [
      { "degree": string, "institution": string, "year": string, "gpa": string }
    ],
    "experience": [
      { "role": string, "company": string, "period": string, "highlights": string[] }
    ],
    "projects": [
      { "title": string, "techStack": string[], "description": string }
    ],
    "skills": {
      "technical": string[],
      "frameworks": string[],
      "languages": string[],
      "tools": string[],
      "soft": string[]
    },
    "certifications": string[],
    "achievements": string[]
  },
  "scores": {
    "overall": number (35-98, realistic mathematical composite),
    "resumeQuality": number (35-98),
    "skills": number (35-98),
    "experience": number (35-98),
    "projects": number (35-98),
    "education": number (35-98),
    "formatting": number (35-98),
    "keywords": number (35-98)
  },
  "strengths": string[] (3-5 specific strengths citing real details from their resume),
  "weaknesses": string[] (3-5 actionable critiques directly addressing their text),
  "recommendations": [
    {
      "id": string (e.g. "rec-1"),
      "priority": "HIGH" | "MEDIUM" | "LOW",
      "category": "Impact" | "Keywords" | "Formatting" | "Structure" | "Skills",
      "problem": string,
      "whyItMatters": string,
      "suggestedImprovement": string,
      "beforeExample": string (MUST be an exact quote from their resume),
      "afterExample": string (an elevated, metric-driven rewrite of that exact quote)
    }
  ],
  "jobRoleRecommendations": [
    {
      "id": string,
      "role": string,
      "matchPercentage": number (55-98),
      "description": string,
      "requiredSkills": string[],
      "matchingSkills": string[],
      "missingSkills": string[],
      "salaryRange": string,
      "demandLevel": "High" | "Very High" | "Moderate"
    }
  ],
  "missingRecommendedSkills": [
    {
      "role": string,
      "skills": string[]
    }
  ],
  "professionalSummary": {
    "Professional": string,
    "Technical": string,
    "Concise": string,
    "Recruiter-Friendly": string
  }
}`;

      const parsedAi = await callGeminiModelsWithFallback(ai, prompt);

      // Merge real candidate data extracted by Gemini
      const mergedParsedData: ParsedResumeData = {
        name: (parsedAi.candidateInfo?.name && parsedAi.candidateInfo.name !== 'Candidate')
          ? parsedAi.candidateInfo.name
          : (parsedData.name || 'Candidate'),
        email: parsedAi.candidateInfo?.email || parsedData.email || '',
        phone: parsedAi.candidateInfo?.phone || parsedData.phone || '',
        location: parsedAi.candidateInfo?.location || parsedData.location || '',
        linkedin: parsedAi.candidateInfo?.linkedin || parsedData.linkedin,
        github: parsedAi.candidateInfo?.github || parsedData.github,
        portfolio: parsedAi.candidateInfo?.portfolio || parsedData.portfolio,
        summary: parsedAi.candidateInfo?.summary || parsedData.summary,
        education: (parsedAi.extractedProfile?.education && parsedAi.extractedProfile.education.length > 0)
          ? parsedAi.extractedProfile.education
          : parsedData.education,
        experience: (parsedAi.extractedProfile?.experience && parsedAi.extractedProfile.experience.length > 0)
          ? parsedAi.extractedProfile.experience
          : parsedData.experience,
        projects: (parsedAi.extractedProfile?.projects && parsedAi.extractedProfile.projects.length > 0)
          ? parsedAi.extractedProfile.projects
          : parsedData.projects,
        skills: {
          technical: parsedAi.extractedProfile?.skills?.technical?.length
            ? parsedAi.extractedProfile.skills.technical
            : parsedData.skills.technical,
          soft: parsedAi.extractedProfile?.skills?.soft?.length
            ? parsedAi.extractedProfile.skills.soft
            : parsedData.skills.soft,
          tools: parsedAi.extractedProfile?.skills?.tools?.length
            ? parsedAi.extractedProfile.skills.tools
            : parsedData.skills.tools,
          frameworks: parsedAi.extractedProfile?.skills?.frameworks?.length
            ? parsedAi.extractedProfile.skills.frameworks
            : parsedData.skills.frameworks,
          languages: parsedAi.extractedProfile?.skills?.languages?.length
            ? parsedAi.extractedProfile.skills.languages
            : parsedData.skills.languages
        },
        certifications: parsedAi.extractedProfile?.certifications?.length
          ? parsedAi.extractedProfile.certifications
          : parsedData.certifications,
        achievements: parsedAi.extractedProfile?.achievements?.length
          ? parsedAi.extractedProfile.achievements
          : parsedData.achievements,
        extracurricular: parsedAi.extractedProfile?.extracurricular?.length
          ? parsedAi.extractedProfile.extracurricular
          : parsedData.extracurricular,
        rawText: parsedData.rawText || rawText
      };

      const updatedAts = performATSAnalysis(mergedParsedData, rawText);
      const skillsBreakdown = buildSkillsBreakdown(mergedParsedData);

      // Validate recommendations: ensure beforeExample is grounded in the document or patched dynamically
      const candidateBullets = mergedParsedData.experience.flatMap(e => e.highlights || []);
      const sanitizedRecommendations = (parsedAi.recommendations && parsedAi.recommendations.length > 0)
        ? parsedAi.recommendations.map((rec: any, index: number) => {
            let before = rec.beforeExample || '';
            let after = rec.afterExample || '';

            // If the model did not supply an exact quote or supplied a generic phrase, grab one from the candidate's actual parsed bullets
            const isGenericPlaceholder = /managed a web development team|deployed applications to the cloud|software engineer looking/i.test(before);
            if (!before || before.length < 10 || isGenericPlaceholder || !rawText.toLowerCase().includes(before.slice(0, 15).toLowerCase())) {
              if (candidateBullets[index]) {
                before = candidateBullets[index];
                after = `Spearheaded ${before.replace(/^[-•*]\s*/, '').toLowerCase()}, delivering measurable business impact and boosting team productivity.`;
              }
            }

            return {
              id: rec.id || `rec-${index + 1}`,
              priority: rec.priority || 'HIGH',
              category: rec.category || 'Impact',
              problem: rec.problem || 'Experience statement can be upgraded with stronger quantifiable impact.',
              whyItMatters: rec.whyItMatters || 'Hiring managers look for measurable metrics when evaluating top candidates.',
              suggestedImprovement: rec.suggestedImprovement || 'Quantify achievements using numbers, percentages, or scale metrics.',
              beforeExample: before,
              afterExample: after
            };
          })
        : getDynamicallyGroundedRecommendations(mergedParsedData);

      return {
        id: 'res_' + Math.random().toString(36).substring(2, 9),
        resumeId: 'doc_' + Math.random().toString(36).substring(2, 9),
        resumeFileName: fileName,
        fileSize,
        uploadedAt: new Date().toISOString(),
        scores: computeNaturalScores(mergedParsedData, updatedAts, rawText, parsedAi.scores),
        parsedData: mergedParsedData,
        strengths: parsedAi.strengths?.length ? parsedAi.strengths : getDynamicallyGroundedStrengths(mergedParsedData),
        weaknesses: parsedAi.weaknesses?.length ? parsedAi.weaknesses : getDynamicallyGroundedWeaknesses(mergedParsedData, updatedAts),
        recommendations: sanitizedRecommendations,
        skillsBreakdown,
        missingRecommendedSkills: parsedAi.missingRecommendedSkills?.length ? parsedAi.missingRecommendedSkills : getDefaultMissingSkills(),
        jobRoleRecommendations: parsedAi.jobRoleRecommendations?.length ? parsedAi.jobRoleRecommendations : getDynamicallyGroundedJobRoles(mergedParsedData),
        atsChecks: updatedAts.checks,
        atsExplanation: {
          summary: updatedAts.explanation,
          parsedWordCount: updatedAts.wordCount,
          detectedHeadings: updatedAts.detectedHeadings,
          quantifiableMetricsFound: updatedAts.quantifiableMetricsCount,
          actionVerbsCount: updatedAts.actionVerbsCount,
          readabilityScore: updatedAts.readabilityScore
        },
        professionalSummary: {
          original: mergedParsedData.summary,
          tones: {
            Professional: parsedAi.professionalSummary?.Professional || getGeneratedSummary('Professional', mergedParsedData),
            Technical: parsedAi.professionalSummary?.Technical || getGeneratedSummary('Technical', mergedParsedData),
            Concise: parsedAi.professionalSummary?.Concise || getGeneratedSummary('Concise', mergedParsedData),
            'Recruiter-Friendly': parsedAi.professionalSummary?.['Recruiter-Friendly'] || getGeneratedSummary('Recruiter-Friendly', mergedParsedData)
          },
          currentTone: 'Professional'
        }
      };
    } catch (error) {
      console.info('[GeminiService] External models busy or unavailable. Seamlessly activating dynamic heuristic engine.');
    }
  } else {
    console.info('[GeminiService] No external Gemini API key provided. Utilizing modular dynamic heuristic AI engine.');
  }

  // Realistic Fallback / Deterministic AI Engine
  return generateDeterministicAnalysis(fileName, fileSize, rawText, parsedData, atsOutput);
}

export async function generateSummaryByTone(
  summary: string,
  tone: 'Professional' | 'Technical' | 'Concise' | 'Recruiter-Friendly',
  skills: string[]
): Promise<string> {
  const ai = getGemini();
  if (ai) {
    try {
      const prompt = `Rewrite this candidate's resume summary in a ${tone} tone. Keep it within 3-4 lines, high impact, emphasizing skills: ${skills.slice(0, 6).join(', ')}.\nOriginal: "${summary}"`;
      const text = await callGeminiModelsWithFallback(ai, prompt, false);
      if (text) {
        return text.replace(/["\n]/g, ' ').trim();
      }
    } catch (e) {
      console.info('[GeminiService] Summary generation via external model busy. Utilizing precision tone generator.');
    }
  }

  // Heuristic Tone Generator
  switch (tone) {
    case 'Technical':
      return `Systems-oriented software engineer specializing in ${skills.slice(0, 4).join(', ')}. Proven track record of implementing resilient distributed services, microservice architectures, and automated CI/CD pipelines with sub-100ms latency targets.`;
    case 'Concise':
      return `High-velocity software engineer with strong expertise in ${skills.slice(0, 3).join(', ')}. Delivering scalable cloud applications and high-impact product features.`;
    case 'Recruiter-Friendly':
      return `Collaborative and proactive engineer with extensive background building modern web applications. Passionate about product quality, clean code, and cross-functional team success with expertise in ${skills.slice(0, 4).join(', ')}.`;
    case 'Professional':
    default:
      return `Results-driven software engineer with deep proficiency in ${skills.slice(0, 4).join(', ')}. Dedicated to architecting robust enterprise systems, optimizing application performance, and accelerating product roadmap delivery.`;
  }
}

export async function compareResumeWithJob(
  resume: ResumeAnalysis,
  jobTitle: string,
  companyName: string,
  jobDescription: string
): Promise<JobMatchResult> {
  const ai = getGemini();
  const resumeSkills = [
    ...resume.parsedData.skills.technical,
    ...resume.parsedData.skills.frameworks,
    ...resume.parsedData.skills.languages,
    ...resume.parsedData.skills.tools
  ];

  if (ai) {
    try {
      const prompt = `You are a Principal Talent Acquisition Partner and Technical Recruiter.
Perform a rigorous, objective, and deeply grounded comparison between the candidate's resume and the target Job Description below.

==================================================
TARGET JOB:
Role: ${jobTitle || 'Target Position'}
Company: ${companyName || 'Target Organization'}
Job Description:
---
${jobDescription.slice(0, 8000)}
---
==================================================

CANDIDATE RESUME:
Name: ${resume.parsedData.name || 'Candidate'}
Summary: ${resume.parsedData.summary || 'None'}
Identified Skills: ${resumeSkills.join(', ') || 'None'}
Experience Roles:
${resume.parsedData.experience.map(e => `• ${e.role} at ${e.company} (${e.period}) - Highlights: ${e.highlights?.join('; ') || 'N/A'}`).join('\n')}
Education:
${resume.parsedData.education.map(e => `• ${e.degree} at ${e.institution} (${e.year || ''})`).join('\n')}
Projects:
${resume.parsedData.projects.map(p => `• ${p.title} [${p.techStack.join(', ')}]: ${p.description}`).join('\n')}
Resume Text Excerpt:
---
${resume.parsedData.rawText.slice(0, 4000)}
---
==================================================

ANALYSIS MANDATES:
1. "matchingSkills": Extract technical skills, libraries, tools, and methodologies that are EXPLICITLY mentioned in the Job Description AND are genuinely evidenced in this candidate's resume.
2. "missingSkills": Extract skills and tools explicitly requested in the Job Description that the candidate does NOT have in their resume.
3. "matchingKeywords": Domain terminology, architectures, and concepts present in both the Job Description and the resume.
4. "missingKeywords": Critical keywords and concepts present in the Job Description that the candidate should add to pass ATS scans.
5. "overallMatchScore": An accurate 0-100 percentage reflecting true role readiness based on required vs optional qualifications.
6. "experienceMatch":
   - "score": number (50-98)
   - "status": "Strong" | "Moderate" | "Low"
   - "notes": Detailed critique of how their past job titles, seniority, and responsibilities match this JD.
7. "educationMatch":
   - "score": number (50-98)
   - "status": "Qualified" | "Partial Match" | "Under-Qualified"
   - "notes": Detailed evaluation of degrees/certifications vs JD requirements.
8. "recommendations": 3-5 concrete, actionable tips explaining exactly what the candidate should tweak, emphasize, or add to pass the ATS filter and interview for THIS job.

Return ONLY a valid JSON object matching the schema below:
{
  "overallMatchScore": number,
  "matchPercentage": number,
  "matchingSkills": string[],
  "missingSkills": string[],
  "matchingKeywords": string[],
  "missingKeywords": string[],
  "experienceMatch": {
    "score": number,
    "status": "Strong" | "Moderate" | "Low",
    "notes": string
  },
  "educationMatch": {
    "score": number,
    "status": "Qualified" | "Partial Match" | "Under-Qualified",
    "notes": string
  },
  "recommendations": string[]
}`;

      const aiMatch = await callGeminiModelsWithFallback(ai, prompt);

      return {
        id: 'match_' + Math.random().toString(36).substring(2, 9),
        resumeId: resume.id,
        jobTitle: jobTitle || 'Target Position',
        companyName: companyName || 'Target Organization',
        jobDescription,
        overallMatchScore: aiMatch.overallMatchScore || aiMatch.matchPercentage || 75,
        matchPercentage: aiMatch.matchPercentage || aiMatch.overallMatchScore || 75,
        matchingSkills: Array.isArray(aiMatch.matchingSkills) ? aiMatch.matchingSkills : [],
        missingSkills: Array.isArray(aiMatch.missingSkills) ? aiMatch.missingSkills : [],
        matchingKeywords: Array.isArray(aiMatch.matchingKeywords) ? aiMatch.matchingKeywords : [],
        missingKeywords: Array.isArray(aiMatch.missingKeywords) ? aiMatch.missingKeywords : [],
        experienceMatch: aiMatch.experienceMatch || {
          score: 78,
          status: 'Moderate',
          notes: `Candidate work history demonstrates relevant technical capability with opportunities to align closer to ${jobTitle} responsibilities.`
        },
        educationMatch: {
          score: aiMatch.educationMatch?.score || 88,
          status: (['Qualified', 'Matches Requirements', 'Gap Detected'].includes(aiMatch.educationMatch?.status)
            ? aiMatch.educationMatch.status
            : 'Qualified') as 'Qualified' | 'Matches Requirements' | 'Gap Detected',
          notes: aiMatch.educationMatch?.notes || 'Candidate educational credentials satisfy standard role prerequisites.'
        },
        recommendations: Array.isArray(aiMatch.recommendations) && aiMatch.recommendations.length > 0
          ? aiMatch.recommendations
          : [
              `Explicitly incorporate keywords from the ${jobTitle} description into your experience bullets.`,
              'Quantify business metrics around performance, latency, or team scale to demonstrate senior impact.'
            ],
        analyzedAt: new Date().toISOString()
      };
    } catch (err) {
      console.info('[GeminiService] AI job matching external service busy. Seamlessly using dynamic NLP matcher.');
    }
  }

  // Dynamic heuristic/NLP matcher fallback
  return performDynamicJobMatch(resume, jobTitle, companyName, jobDescription);
}

// Broad dynamic NLP job matcher taxonomy for non-AI fallback
function performDynamicJobMatch(
  resume: ResumeAnalysis,
  jobTitle: string,
  companyName: string,
  jobDescription: string
): JobMatchResult {
  const jdLower = jobDescription.toLowerCase();
  const rawTextLower = (resume.parsedData.rawText || '').toLowerCase();
  const resumeSkills = [
    ...resume.parsedData.skills.technical,
    ...resume.parsedData.skills.frameworks,
    ...resume.parsedData.skills.languages,
    ...resume.parsedData.skills.tools
  ];

  // Comprehensive tech & domain dictionary covering 100+ modern technologies
  const TECH_TAXONOMY = [
    'React', 'TypeScript', 'JavaScript', 'Node.js', 'Express', 'Python', 'Django', 'FastAPI', 'Flask',
    'Go', 'Golang', 'Rust', 'Java', 'Spring Boot', 'C++', 'C#', '.NET', 'PHP', 'Ruby', 'Rails',
    'Next.js', 'Vue.js', 'Angular', 'Svelte', 'Tailwind CSS', 'GraphQL', 'REST APIs', 'gRPC',
    'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'Cassandra', 'Elasticsearch', 'DynamoDB', 'Snowflake',
    'AWS', 'Azure', 'GCP', 'Google Cloud', 'Docker', 'Kubernetes', 'Terraform', 'Helm', 'CI/CD',
    'GitHub Actions', 'GitLab', 'Linux', 'Microservices', 'Distributed Systems', 'Kafka', 'RabbitMQ',
    'PyTorch', 'TensorFlow', 'Machine Learning', 'Deep Learning', 'Pandas', 'NumPy', 'Scikit-learn',
    'Spark', 'Airflow', 'Datadog', 'Prometheus', 'Grafana', 'Jest', 'Cypress', 'Playwright', 'Selenium',
    'WebSockets', 'Core Web Vitals', 'Observability', 'Security', 'OAuth', 'JWT', 'Agile', 'Scrum'
  ];

  const DOMAIN_KEYWORDS = [
    'high availability', 'scalability', 'distributed systems', 'system architecture', 'microservices',
    'ci/cd', 'container orchestration', 'cloud native', 'rest api', 'automated testing',
    'cross-functional', 'mentorship', 'code reviews', 'performance optimization', 'data pipeline',
    'security compliance', 'agile development', 'product roadmap', 'low latency', 'concurrency'
  ];

  // Detect skills present in the JD
  const detectedJdSkills: string[] = [];
  for (const tech of TECH_TAXONOMY) {
    const pattern = new RegExp(`\\b${tech.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (pattern.test(jobDescription)) {
      detectedJdSkills.push(tech);
    }
  }

  // Find matching vs missing skills
  const matchingSkills: string[] = [];
  const missingSkills: string[] = [];

  detectedJdSkills.forEach((tech) => {
    const techLower = tech.toLowerCase();
    const isPresent = resumeSkills.some(s => s.toLowerCase() === techLower) ||
      new RegExp(`\\b${tech.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(rawTextLower);

    if (isPresent) {
      matchingSkills.push(tech);
    } else {
      missingSkills.push(tech);
    }
  });

  // Find matching vs missing domain keywords
  const matchingKeywords: string[] = [];
  const missingKeywords: string[] = [];

  DOMAIN_KEYWORDS.forEach((kw) => {
    if (jdLower.includes(kw)) {
      if (rawTextLower.includes(kw)) {
        matchingKeywords.push(kw.charAt(0).toUpperCase() + kw.slice(1));
      } else {
        missingKeywords.push(kw.charAt(0).toUpperCase() + kw.slice(1));
      }
    }
  });

  // Score computation
  const totalSkills = Math.max(detectedJdSkills.length, 4);
  const skillRatio = matchingSkills.length / totalSkills;
  const keywordRatio = matchingKeywords.length / Math.max(matchingKeywords.length + missingKeywords.length, 2);

  const rawScore = Math.round(skillRatio * 70 + keywordRatio * 30);
  const overallMatchScore = Math.min(96, Math.max(48, rawScore));

  // Analyze experience requirements from JD
  const yearsExpMatch = jobDescription.match(/(\d+)\+?\s*(?:-\s*\d+\+?\s*)?years?(?:\s+of)?(?:\s+experience)?/i);
  const requiredYears = yearsExpMatch ? parseInt(yearsExpMatch[1], 10) : 3;
  const candidateYears = Math.max(resume.parsedData.experience.length * 1.5, 2);

  const expScore = candidateYears >= requiredYears ? 88 : Math.round((candidateYears / requiredYears) * 85);
  const expStatus = expScore >= 82 ? 'Strong' : expScore >= 68 ? 'Moderate' : 'Low';

  // Analyze education requirements from JD
  const hasDegree = resume.parsedData.education.length > 0;
  const eduScore = hasDegree ? 90 : 75;
  const eduStatus: 'Qualified' | 'Matches Requirements' | 'Gap Detected' = hasDegree ? 'Qualified' : 'Matches Requirements';

  // Build grounded recommendations
  const recommendations: string[] = [];
  if (missingSkills.length > 0) {
    recommendations.push(
      `Add explicit proficiency in ${missingSkills.slice(0, 3).join(', ')} to your skills and project sections to satisfy target qualifications.`
    );
  }
  if (missingKeywords.length > 0) {
    recommendations.push(
      `Incorporate target phrases such as "${missingKeywords.slice(0, 2).join('", "')}" into your recent job responsibilities.`
    );
  }
  recommendations.push(
    `Align your top bullet points with the primary deliverable for ${jobTitle || 'this role'}, highlighting quantifiable business impact.`
  );

  return {
    id: 'match_' + Math.random().toString(36).substring(2, 9),
    resumeId: resume.id,
    jobTitle: jobTitle || 'Target Position',
    companyName: companyName || 'Target Organization',
    jobDescription,
    overallMatchScore,
    matchPercentage: overallMatchScore,
    matchingSkills: Array.from(new Set(matchingSkills)),
    missingSkills: Array.from(new Set(missingSkills)),
    matchingKeywords: Array.from(new Set(matchingKeywords)),
    missingKeywords: Array.from(new Set(missingKeywords)),
    experienceMatch: {
      score: expScore,
      status: expStatus,
      notes: `Candidate possesses ~${Math.round(candidateYears)}+ years of relevant technical background compared against the ~${requiredYears}+ years stated in the role description.`
    },
    educationMatch: {
      score: eduScore,
      status: eduStatus,
      notes: hasDegree
        ? `Educational profile (${resume.parsedData.education[0]?.degree || 'Degree'} from ${resume.parsedData.education[0]?.institution || 'University'}) satisfies academic prerequisites.`
        : 'Ensure any relevant professional certifications or equivalent industry experience are clearly positioned.'
    },
    recommendations,
    analyzedAt: new Date().toISOString()
  };
}

// Helpers for Dynamic & Deterministic AI Analysis

export function computeDynamicSkillsScore(parsedData: ParsedResumeData): number {
  const technical = parsedData.skills.technical || [];
  const frameworks = parsedData.skills.frameworks || [];
  const languages = parsedData.skills.languages || [];
  const tools = parsedData.skills.tools || [];

  const allSkills = Array.from(new Set([...technical, ...frameworks, ...languages, ...tools]));
  const count = allSkills.length;

  if (count === 0) return 36;

  let score = 42;
  if (count <= 3) {
    score = 42 + count * 5; // 47 - 57
  } else if (count <= 7) {
    score = 57 + (count - 3) * 3.5; // 60.5 - 71
  } else if (count <= 12) {
    score = 71 + (count - 7) * 2.5; // 73.5 - 83.5
  } else if (count <= 18) {
    score = 84 + (count - 12) * 1.8; // 85.8 - 94.8
  } else {
    score = Math.min(97, 94 + (count - 18) * 0.4);
  }

  // Check category diversity
  const categoriesPresent = [technical.length > 0, frameworks.length > 0, languages.length > 0, tools.length > 0].filter(Boolean).length;
  if (categoriesPresent >= 3) {
    score += 4;
  } else if (categoriesPresent <= 1) {
    score -= 8;
  }

  // Check for modern cloud/DevOps/infrastructure keywords
  const hasCloud = tools.some(t => /aws|gcp|azure|docker|kubernetes|terraform|ci\/cd|linux/i.test(t)) ||
                   technical.some(t => /aws|gcp|azure|docker|kubernetes|terraform|ci\/cd|linux/i.test(t));
  if (hasCloud) score += 3;

  return Math.max(35, Math.min(97, Math.round(score)));
}

export function computeDynamicExperienceScore(parsedData: ParsedResumeData, ats: ReturnType<typeof performATSAnalysis>): number {
  const roles = parsedData.experience || [];
  const rolesCount = roles.length;
  const metricsCount = ats.quantifiableMetricsCount;
  const verbsCount = ats.actionVerbsCount;

  // Base score from roles count & seniority
  let score = 42;
  if (rolesCount === 0) {
    score = 38;
  } else if (rolesCount === 1) {
    score = 56;
  } else if (rolesCount === 2) {
    score = 71;
  } else if (rolesCount === 3) {
    score = 80;
  } else {
    score = Math.min(90, 84 + (rolesCount - 3) * 2);
  }

  // Quantifiable metrics: critical discriminator for technical evaluation
  if (metricsCount === 0) {
    score -= 14; // Significant penalty for 0 quantified achievements
  } else if (metricsCount <= 2) {
    score += 3;
  } else if (metricsCount <= 5) {
    score += 8;
  } else {
    score += Math.min(13, 8 + (metricsCount - 5) * 1.2);
  }

  // Action power verbs
  if (verbsCount < 3) {
    score -= 6;
  } else if (verbsCount <= 5) {
    score += 2;
  } else {
    score += Math.min(6, 2 + (verbsCount - 5) * 1);
  }

  // Depth of bullet points
  const allHighlights = roles.flatMap(r => r.highlights || []);
  if (allHighlights.length > 0) {
    const avgLength = allHighlights.reduce((acc, h) => acc + h.length, 0) / allHighlights.length;
    if (avgLength < 30) {
      score -= 8;
    } else if (avgLength > 65) {
      score += 3;
    }
  }

  return Math.max(35, Math.min(97, Math.round(score)));
}

export function computeDynamicProjectsScore(parsedData: ParsedResumeData): number {
  const projects = parsedData.projects || [];
  const count = projects.length;

  if (count === 0) return 42;
  if (count === 1) {
    const hasStack = projects[0].techStack && projects[0].techStack.length > 1;
    return hasStack ? 68 : 60;
  }
  if (count === 2) {
    const detailed = projects.every(p => p.description && p.description.length > 40);
    return detailed ? 83 : 75;
  }

  // 3+ projects
  const richStack = projects.filter(p => p.techStack && p.techStack.length > 1).length;
  return Math.min(97, Math.round(85 + richStack * 2.5));
}

export function computeDynamicEducationScore(parsedData: ParsedResumeData): number {
  const education = parsedData.education || [];
  const certifications = parsedData.certifications || [];

  let baseScore = 48;
  if (education.length === 0) {
    baseScore = 46;
  } else {
    const rawEduText = education.map(e => `${e.degree} ${e.institution}`).join(' ').toLowerCase();
    if (/ph\.?d|doctorate/i.test(rawEduText)) {
      baseScore = 95;
    } else if (/master|m\.s\.|m\.tech|m\.e\./i.test(rawEduText)) {
      baseScore = 90;
    } else if (/bachelor|b\.s\.|b\.tech|b\.e\.|undergraduate/i.test(rawEduText)) {
      baseScore = 83;
    } else if (/associate|diploma|bootcamp/i.test(rawEduText)) {
      baseScore = 70;
    } else {
      baseScore = 64;
    }

    const hasHighGpa = education.some(e => e.gpa && parseFloat(e.gpa) >= 3.6);
    if (hasHighGpa) baseScore += 3;
  }

  if (certifications.length > 0) {
    baseScore = Math.min(98, baseScore + Math.min(certifications.length * 3, 7));
  }

  return Math.max(35, Math.min(98, Math.round(baseScore)));
}

export function computeDynamicFormattingScore(ats: ReturnType<typeof performATSAnalysis>, rawText: string): number {
  let score = 86;

  if (ats.checks.some(c => c.id === 'table_parsing' && c.status === 'warning')) {
    score -= 14;
  }

  if (ats.wordCount < 250) {
    score -= 16;
  } else if (ats.wordCount < 350) {
    score -= 8;
  } else if (ats.wordCount > 1200) {
    score -= 10;
  } else if (ats.wordCount >= 400 && ats.wordCount <= 900) {
    score += 5;
  }

  if (ats.checks.some(c => c.id === 'standard_headings' && c.status === 'warning')) {
    score -= 8;
  }

  return Math.max(38, Math.min(96, Math.round(score)));
}

export function computeDynamicKeywordsScore(parsedData: ParsedResumeData, rawText: string): number {
  const targetKeywords = [
    'architecture', 'ci/cd', 'microservices', 'rest api', 'graphql', 'docker', 'kubernetes',
    'cloud', 'aws', 'gcp', 'azure', 'git', 'testing', 'agile', 'scrum', 'scalability',
    'security', 'database', 'sql', 'nosql', 'performance', 'optimization', 'distributed'
  ];

  const lower = rawText.toLowerCase();
  const matched = targetKeywords.filter(kw => lower.includes(kw));
  const count = matched.length;

  if (count <= 2) return 46;
  if (count <= 5) return Math.round(60 + (count - 2) * 3);
  if (count <= 9) return Math.round(72 + (count - 5) * 2.5);
  if (count <= 14) return Math.round(84 + (count - 9) * 1.8);
  return Math.min(96, Math.round(94 + (count - 14) * 0.4));
}

export function computeDynamicOverallScore(
  atsScore: number,
  experienceScore: number,
  skillsScore: number,
  projectsScore: number,
  educationScore: number,
  formattingScore: number
): number {
  const overall = Math.round(
    atsScore * 0.25 +
    experienceScore * 0.25 +
    skillsScore * 0.20 +
    projectsScore * 0.12 +
    educationScore * 0.10 +
    formattingScore * 0.08
  );
  return Math.max(38, Math.min(97, overall));
}

export function computeNaturalScores(
  parsedData: ParsedResumeData,
  atsOutput: ReturnType<typeof performATSAnalysis>,
  rawText: string,
  aiScores?: Partial<ScoreBreakdown>
): ScoreBreakdown {
  const dynamicSkills = computeDynamicSkillsScore(parsedData);
  const dynamicExperience = computeDynamicExperienceScore(parsedData, atsOutput);
  const dynamicProjects = computeDynamicProjectsScore(parsedData);
  const dynamicEducation = computeDynamicEducationScore(parsedData);
  const dynamicFormatting = computeDynamicFormattingScore(atsOutput, rawText);
  const dynamicKeywords = computeDynamicKeywordsScore(parsedData, rawText);

  // Blend AI qualitative judgment with document-grounded empirical baseline
  const resolveSubScore = (aiVal: number | undefined, dynamicVal: number): number => {
    if (typeof aiVal === 'number' && !isNaN(aiVal) && aiVal >= 35 && aiVal <= 98) {
      return Math.max(35, Math.min(98, Math.round(aiVal * 0.55 + dynamicVal * 0.45)));
    }
    return dynamicVal;
  };

  const atsCompatibility = atsOutput.atsScore;
  const skills = resolveSubScore(aiScores?.skills, dynamicSkills);
  const experience = resolveSubScore(aiScores?.experience, dynamicExperience);
  const projects = resolveSubScore(aiScores?.projects, dynamicProjects);
  const education = resolveSubScore(aiScores?.education, dynamicEducation);
  const formatting = resolveSubScore(aiScores?.formatting, dynamicFormatting);
  const keywords = resolveSubScore(aiScores?.keywords, dynamicKeywords);

  // Overall is strictly the weighted mathematical composite of the evaluated pillars
  const overall = computeDynamicOverallScore(
    atsCompatibility,
    experience,
    skills,
    projects,
    education,
    formatting
  );

  return {
    overall,
    atsCompatibility,
    skills,
    experience,
    projects,
    education,
    formatting,
    keywords
  };
}

function generateDeterministicAnalysis(
  fileName: string,
  fileSize: number,
  rawText: string,
  parsedData: ParsedResumeData,
  atsOutput: ReturnType<typeof performATSAnalysis>
): ResumeAnalysis {
  const scores = computeNaturalScores(parsedData, atsOutput, rawText);

  return {
    id: 'res_' + Math.random().toString(36).substring(2, 9),
    resumeId: 'doc_' + Math.random().toString(36).substring(2, 9),
    resumeFileName: fileName,
    fileSize,
    uploadedAt: new Date().toISOString(),
    scores,
    parsedData,
    strengths: getDynamicallyGroundedStrengths(parsedData),
    weaknesses: getDynamicallyGroundedWeaknesses(parsedData, atsOutput),
    recommendations: getDynamicallyGroundedRecommendations(parsedData),
    skillsBreakdown: buildSkillsBreakdown(parsedData),
    missingRecommendedSkills: getDefaultMissingSkills(),
    jobRoleRecommendations: getDynamicallyGroundedJobRoles(parsedData),
    atsChecks: atsOutput.checks,
    atsExplanation: {
      summary: atsOutput.explanation,
      parsedWordCount: atsOutput.wordCount,
      detectedHeadings: atsOutput.detectedHeadings,
      quantifiableMetricsFound: atsOutput.quantifiableMetricsCount,
      actionVerbsCount: atsOutput.actionVerbsCount,
      readabilityScore: atsOutput.readabilityScore
    },
    professionalSummary: {
      original: parsedData.summary,
      tones: {
        Professional: getGeneratedSummary('Professional', parsedData),
        Technical: getGeneratedSummary('Technical', parsedData),
        Concise: getGeneratedSummary('Concise', parsedData),
        'Recruiter-Friendly': getGeneratedSummary('Recruiter-Friendly', parsedData)
      },
      currentTone: 'Professional'
    }
  };
}

function buildSkillsBreakdown(parsedData: ParsedResumeData): SkillCategory[] {
  const rawLower = parsedData.rawText?.toLowerCase() || '';
  const highlightsText = parsedData.experience.flatMap(e => e.highlights || []).join(' ').toLowerCase();

  const calculateProficiency = (skillName: string, defaultLevel: number): number => {
    const sLower = skillName.toLowerCase();
    let level = defaultLevel;
    if (highlightsText.includes(sLower)) {
      level += 7;
    }
    const escaped = sLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`\\b${escaped}\\b`, 'g');
    const occurrences = (rawLower.match(regex) || []).length;
    if (occurrences >= 3) {
      level += 5;
    } else if (occurrences === 1 && !highlightsText.includes(sLower)) {
      level -= 5;
    }
    return Math.max(50, Math.min(96, level));
  };

  return [
    {
      name: 'Technical Skills',
      skills: parsedData.skills.technical.slice(0, 6).map((name, i) => ({
        name,
        level: calculateProficiency(name, 88 - i * 4),
        category: 'Technical',
        verifiedInResume: true
      }))
    },
    {
      name: 'Frameworks & Libraries',
      skills: parsedData.skills.frameworks.slice(0, 5).map((name, i) => ({
        name,
        level: calculateProficiency(name, 86 - i * 4),
        category: 'Frameworks',
        verifiedInResume: true
      }))
    },
    {
      name: 'Programming Languages',
      skills: parsedData.skills.languages.slice(0, 4).map((name, i) => ({
        name,
        level: calculateProficiency(name, 90 - i * 5),
        category: 'Languages',
        verifiedInResume: true
      }))
    },
    {
      name: 'Cloud & Developer Tools',
      skills: parsedData.skills.tools.slice(0, 5).map((name, i) => ({
        name,
        level: calculateProficiency(name, 84 - i * 4),
        category: 'Tools',
        verifiedInResume: true
      }))
    }
  ];
}

function getDynamicallyGroundedStrengths(parsedData: ParsedResumeData): string[] {
  const strengths: string[] = [];
  const allSkills = [
    ...parsedData.skills.technical,
    ...parsedData.skills.frameworks,
    ...parsedData.skills.languages,
    ...parsedData.skills.tools
  ];

  if (allSkills.length > 0) {
    strengths.push(`Rich technical competency with ${allSkills.length} identified modern technologies (including ${allSkills.slice(0, 5).join(', ')}).`);
  }

  const companies = parsedData.experience.map(e => e.company).filter(c => c && c !== 'Company');
  if (companies.length > 0) {
    strengths.push(`Documented career progression across ${companies.length} organization(s) including ${companies.slice(0, 2).join(' and ')}.`);
  }

  if (parsedData.projects.length > 0) {
    strengths.push(`Project portfolio showcases practical engineering execution with ${parsedData.projects.map(p => p.title).slice(0, 2).join(' and ')}.`);
  }

  if (parsedData.education.length > 0) {
    strengths.push(`Educational credentials verified with ${parsedData.education[0].degree} from ${parsedData.education[0].institution}.`);
  }

  if (parsedData.linkedin || parsedData.github) {
    strengths.push('Candidate maintains accessible digital profiles (LinkedIn/GitHub) for background verification.');
  }

  if (strengths.length < 3) {
    strengths.push('Linear chronological resume structure compatible with ATS parsing algorithms.');
  }

  return strengths.slice(0, 5);
}

function getDynamicallyGroundedWeaknesses(parsedData: ParsedResumeData, ats: any): string[] {
  const weaknesses: string[] = [];

  if (ats.quantifiableMetricsCount < 2) {
    weaknesses.push(`Low density of quantifiable metrics (${ats.quantifiableMetricsCount} detected). Bullet points should feature % gains, latency reductions, or scale metrics.`);
  }

  if (ats.actionVerbsCount < 4) {
    weaknesses.push(`Action verb variety is limited (${ats.actionVerbsCount} strong verbs detected). Replace passive phrasing with impact-driven verbs like "Architected", "Engineered", or "Spearheaded".`);
  }

  if (ats.wordCount < 250) {
    weaknesses.push(`Resume length (${ats.wordCount} words) is below the recommended 350-600 word benchmark, leaving potential technical accomplishments under-described.`);
  }

  if (parsedData.projects.length === 0) {
    weaknesses.push('No dedicated technical projects section detected to demonstrate independent system design and problem solving.');
  }

  if (!parsedData.summary || parsedData.summary.length < 40) {
    weaknesses.push('Professional summary is missing or too brief to frame career trajectory for the 6-second recruiter glance.');
  }

  if (weaknesses.length < 3) {
    weaknesses.push('Could expand on cross-functional team collaboration, agile mentorship, and code review leadership.');
  }

  return weaknesses.slice(0, 4);
}

function getDynamicallyGroundedRecommendations(parsedData: ParsedResumeData): AIRecommendation[] {
  const bullets = parsedData.experience.flatMap(e => e.highlights || []).filter(b => b.length > 15);
  const recs: AIRecommendation[] = [];

  // Bullet 1 transformation
  if (bullets[0]) {
    const raw = bullets[0].replace(/^[-•*]\s*/, '');
    recs.push({
      id: 'rec-1',
      priority: 'HIGH',
      category: 'Impact',
      problem: 'Experience bullet describes responsibilities without measurable business or engineering impact metrics.',
      whyItMatters: 'Hiring managers screen for proof of delivery and ROI rather than duty descriptions.',
      suggestedImprovement: 'Adopt the XYZ formula: Accomplished [X], as measured by [Y], by doing [Z].',
      beforeExample: raw,
      afterExample: `Engineered solution for ${raw.toLowerCase()}, reducing operational turnaround by 32% and accelerating release cycles.`
    });
  }

  // Bullet 2 transformation
  if (bullets[1]) {
    const raw = bullets[1].replace(/^[-•*]\s*/, '');
    recs.push({
      id: 'rec-2',
      priority: 'HIGH',
      category: 'Keywords',
      problem: 'Technical implementation details could better emphasize architectural scale and industry-standard toolchains.',
      whyItMatters: 'ATS search filters prioritize candidates who specify exact tooling, concurrency, or cloud environments.',
      suggestedImprovement: 'Integrate exact frameworks, containerization tools, or automated testing metrics.',
      beforeExample: raw,
      afterExample: `Spearheaded ${raw.toLowerCase()} using automated CI/CD workflows and Docker containerization, cutting error rates by 40%.`
    });
  }

  // Bullet 3 or summary transformation
  if (bullets[2]) {
    const raw = bullets[2].replace(/^[-•*]\s*/, '');
    recs.push({
      id: 'rec-3',
      priority: 'MEDIUM',
      category: 'Structure',
      problem: 'Sentence phrasing starts with passive or administrative verbs.',
      whyItMatters: 'Lead with decisive active verbs to convey seniority, initiative, and technical ownership.',
      suggestedImprovement: 'Replace introductory phrasing with verbs such as "Architected", "Pioneered", or "Orchestrated".',
      beforeExample: raw,
      afterExample: `Architected ${raw.toLowerCase()}, streamlining team delivery across multiple sprint cycles.`
    });
  }

  if (recs.length === 0) {
    recs.push({
      id: 'rec-1',
      priority: 'HIGH',
      category: 'Impact',
      problem: 'No clear quantifiable achievement metrics detected in the work history.',
      whyItMatters: 'Recruiters and ATS scorecards rely on metrics to differentiate top 10% talent.',
      suggestedImprovement: 'Incorporate percentages, time reductions, user counts, or revenue impact.',
      beforeExample: 'Worked on software components and assisted team with deployments.',
      afterExample: 'Optimized deployment pipelines with Docker and GitHub Actions, slashing deploy times from 45 to 8 minutes.'
    });
  }

  return recs;
}

function getDefaultMissingSkills() {
  return [
    {
      role: 'Senior Full Stack Engineer',
      skills: ['Kubernetes', 'Terraform', 'System Architecture', 'Microservices', 'GraphQL']
    },
    {
      role: 'Cloud / DevOps Engineer',
      skills: ['Terraform', 'AWS ECS/EKS', 'Prometheus', 'Grafana', 'Ansible']
    },
    {
      role: 'Frontend Architect',
      skills: ['Web Vitals Optimization', 'Server-Driven UI', 'Micro-Frontends', 'Cypress']
    }
  ];
}

function getDynamicallyGroundedJobRoles(parsed: ParsedResumeData): JobRoleRecommendation[] {
  const tech = [
    ...parsed.skills.technical,
    ...parsed.skills.frameworks,
    ...parsed.skills.languages,
    ...parsed.skills.tools
  ].map(s => s.toLowerCase());

  const hasFrontend = tech.some(t => /react|vue|angular|next|svelte|html|css|tailwind/i.test(t));
  const hasBackend = tech.some(t => /node|express|python|django|fastapi|java|spring|go|golang|rust|sql|postgres|mongo/i.test(t));
  const hasCloud = tech.some(t => /aws|azure|gcp|docker|kubernetes|k8s|terraform|ci\/cd|linux/i.test(t));
  const hasData = tech.some(t => /pytorch|tensorflow|pandas|numpy|scikit|spark|hadoop|tableau|machine learning|data/i.test(t));

  const roles: JobRoleRecommendation[] = [];

  if (hasFrontend && hasBackend) {
    roles.push({
      id: 'role-fullstack',
      role: 'Full Stack Software Engineer',
      matchPercentage: 92,
      description: 'Architect, develop, and maintain end-to-end web applications and high-availability microservices.',
      requiredSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'REST APIs'],
      matchingSkills: parsed.skills.technical.filter(t => /react|typescript|node|sql|api/i.test(t)).concat(['REST APIs']),
      missingSkills: ['Kubernetes Helm', 'Microservice Cache Topologies'],
      salaryRange: '$125,000 - $170,000',
      demandLevel: 'Very High'
    });
  }

  if (hasFrontend) {
    const matching = parsed.skills.frameworks.concat(parsed.skills.languages).filter(s => /react|next|vue|typescript|tailwind|css/i.test(s));
    const matchPct = Math.min(96, Math.max(48, Math.round(58 + (matching.length / 6) * 36)));
    roles.push({
      id: 'role-frontend',
      role: 'Senior Frontend Engineer',
      matchPercentage: matchPct,
      description: 'Lead client application architecture, state design, web performance optimization, and UI design systems.',
      requiredSkills: ['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'Web Vitals', 'Testing'],
      matchingSkills: matching,
      missingSkills: ['Core Web Vitals Optimization', 'Server-Driven UI'],
      salaryRange: '$120,000 - $160,000',
      demandLevel: 'High'
    });
  }

  if (hasBackend || hasCloud) {
    const matching = parsed.skills.technical.filter(t => /node|go|python|sql|docker|aws|linux/i.test(t));
    const matchPct = Math.min(95, Math.max(50, Math.round(55 + (matching.length / 6) * 38)));
    roles.push({
      id: 'role-backend',
      role: 'Backend & Cloud Systems Engineer',
      matchPercentage: matchPct,
      description: 'Design distributed services, API routing layers, database persistence models, and cloud infrastructure.',
      requiredSkills: ['Node.js/Go/Python', 'PostgreSQL', 'Redis', 'Docker', 'AWS/GCP', 'CI/CD'],
      matchingSkills: matching,
      missingSkills: ['Distributed Tracing', 'Terraform IaC'],
      salaryRange: '$130,000 - $175,000',
      demandLevel: 'High'
    });
  }

  if (hasData) {
    const matching = parsed.skills.technical.filter(t => /python|sql|torch|flow|pandas|data/i.test(t));
    const matchPct = Math.min(96, Math.max(50, Math.round(55 + (matching.length / 6) * 38)));
    roles.push({
      id: 'role-data',
      role: 'Machine Learning / Data Platform Engineer',
      matchPercentage: matchPct,
      description: 'Build predictive data pipelines, model inference servers, and distributed analytics platforms.',
      requiredSkills: ['Python', 'SQL', 'PyTorch/TensorFlow', 'Pandas', 'Spark', 'Docker'],
      matchingSkills: matching,
      missingSkills: ['MLOps Feature Stores', 'Kubeflow'],
      salaryRange: '$135,000 - $185,000',
      demandLevel: 'Very High'
    });
  }

  if (roles.length < 3) {
    const matching = parsed.skills.tools.filter(t => /git|docker|linux|ci/i.test(t));
    const matchPct = hasCloud ? Math.min(92, 70 + matching.length * 4) : 62 + matching.length * 3;
    roles.push({
      id: 'role-platform',
      role: 'DevOps / Platform Associate',
      matchPercentage: matchPct,
      description: 'Automate build and deployment pipelines, maintain container orchestrations, and safeguard system uptime.',
      requiredSkills: ['Docker', 'Kubernetes', 'CI/CD', 'AWS', 'Terraform', 'Linux'],
      matchingSkills: matching,
      missingSkills: ['Terraform IaC', 'Prometheus & Grafana Observability'],
      salaryRange: '$115,000 - $155,000',
      demandLevel: 'Moderate'
    });
  }

  return roles.slice(0, 4);
}

function getGeneratedSummary(tone: string, parsed: ParsedResumeData): string {
  const topSkills = [...parsed.skills.technical, ...parsed.skills.frameworks].slice(0, 4).join(', ') || 'modern web technologies';
  switch (tone) {
    case 'Technical':
      return `Systems-focused software engineer with deep proficiency in ${topSkills}. Track record of designing scalable cloud architectures, microservices, and reducing API response latencies.`;
    case 'Concise':
      return `High-impact software engineer specialized in ${topSkills}. Proven success delivering resilient, user-centric web applications and scalable products.`;
    case 'Recruiter-Friendly':
      return `Collaborative, product-minded engineer with hands-on expertise across ${topSkills}. Passionate about agile teamwork, fast feedback loops, and delivering outstanding customer value.`;
    case 'Professional':
    default:
      return `Results-driven software engineer with proven experience in ${topSkills}. Dedicated to architecting robust enterprise systems, optimizing application performance, and accelerating product roadmap delivery.`;
  }
}
