import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { ResumeAnalysis, User, JobMatchResult, ParsedResumeData, SkillCategory, AIRecommendation, JobRoleRecommendation, ATSCheckItem } from '../src/types.js';

// File Paths
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

// Ensure base storage directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

export interface StoredUser extends User {
  passwordHash: string;
  lastLoginAt?: string;
  bio?: string;
  phone?: string;
  location?: string;
  preferences?: {
    theme?: 'dark' | 'light' | 'system';
    emailNotifications?: boolean;
    atsAutoEnhance?: boolean;
  };
}

export interface StoredResume {
  id: string; // resumeId
  userId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  storagePath: string;
  fileUrl: string;
  uploadedAt: string;
  rawText: string;
  parsedData: ParsedResumeData;
  latestAnalysisId?: string;
  isDemo?: boolean;
}

export interface StoredAnalysis {
  id: string; // analysisId
  userId: string;
  resumeId: string;
  score: number;
  atsScore: number;
  skills: SkillCategory[];
  missingSkills: { role: string; skills: string[] }[];
  strengths: string[];
  weaknesses: string[];
  recommendations: AIRecommendation[];
  jobRoleRecommendations: JobRoleRecommendation[];
  atsChecks: ATSCheckItem[];
  atsExplanation: any;
  professionalSummary: any;
  analyzedAt: string;
  fullAnalysis: ResumeAnalysis;
}

export interface StoredToken {
  userId: string;
  createdAt: string;
}

export interface StoredReview {
  id: string;
  userId: string;
  userName: string;
  userRole?: string;
  rating: number; // 1 to 5
  reviewText: string;
  isApproved: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DBStore {
  users: Record<string, StoredUser>; // Keyed by userId
  tokens: Record<string, StoredToken>; // Keyed by token string
  resumes: Record<string, StoredResume>; // Keyed by resumeId
  analyses: Record<string, StoredAnalysis>; // Keyed by analysisId
  jobMatches: Record<string, JobMatchResult & { userId: string }>; // Keyed by matchId
  reviews: Record<string, StoredReview>; // Keyed by reviewId
}

// ----------------------------------------------------
// DEMO SEED CONSTANTS
// ----------------------------------------------------
export const DEMO_USER_ID = 'user_demo_404codex';
export const DEMO_RESUME_ID = 'doc_alex_rivera_resume';
export const DEMO_ANALYSIS_ID = 'demo_analysis_404codex';

export const SAMPLE_DEMO_ANALYSIS: ResumeAnalysis = {
  id: DEMO_ANALYSIS_ID,
  resumeId: DEMO_RESUME_ID,
  resumeFileName: 'Alex_Rivera_Senior_FullStack_Resume.pdf',
  fileSize: 142800,
  uploadedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
  isDemo: true,
  scores: {
    overall: 84,
    atsCompatibility: 81,
    skills: 88,
    experience: 79,
    projects: 85,
    education: 90,
    formatting: 84,
    keywords: 82
  },
  parsedData: {
    name: 'Alex Rivera',
    email: 'alex.rivera@codex404.dev',
    phone: '+1 (415) 555-0198',
    location: 'San Francisco, CA',
    linkedin: 'https://linkedin.com/in/alex-rivera-dev',
    github: 'https://github.com/alexrivera-codex',
    portfolio: 'https://alexrivera.dev',
    summary: 'Senior Full Stack Engineer with 5+ years of experience designing high-throughput web applications, microservices, and distributed cloud systems. Skilled in TypeScript, React, Node.js, and AWS with a track record of driving 40%+ performance gains.',
    education: [
      {
        degree: 'B.S. in Computer Science & Applied Mathematics',
        institution: 'University of California, Berkeley',
        year: '2017 - 2021',
        gpa: '3.86 / 4.0'
      }
    ],
    experience: [
      {
        role: 'Senior Full Stack Engineer',
        company: 'Vanguard Cloud Systems',
        period: '2022 - Present',
        highlights: [
          'Architected and led the development of a real-time event ingestion engine processing 1.5M transactions daily with 99.99% uptime.',
          'Reduced web application p95 response latency by 38% through Redis tier caching and PostgreSQL query optimization.',
          'Spearheaded CI/CD migration to GitHub Actions & AWS ECS, cutting deployment duration from 45 to 6 minutes.'
        ]
      },
      {
        role: 'Full Stack Software Engineer',
        company: 'Apex Data Labs',
        period: '2020 - 2022',
        highlights: [
          'Engineered customer-facing analytics dashboards using React, TypeScript, and Tailwind CSS serving 80,000+ monthly active enterprise users.',
          'Developed microservice REST APIs in Node.js and Express with automated Jest test suites achieving 89% code coverage.',
          'Collaborated in Agile sprints with cross-functional product and UX design teams to ship 14 major feature releases on schedule.'
        ]
      }
    ],
    projects: [
      {
        title: 'Distributed Task Queue & Scheduler',
        techStack: ['TypeScript', 'Node.js', 'Redis', 'Docker'],
        description: 'Built a fault-tolerant async worker pool capable of processing 10,000 concurrent jobs with dead-letter queue recovery.',
        link: 'https://github.com/alexrivera-codex/task-queue'
      },
      {
        title: 'Collaborative Real-Time Whiteboard',
        techStack: ['React', 'WebSockets', 'Canvas API', 'Tailwind CSS'],
        description: 'Engineered sub-50ms peer-to-peer sync engine supporting up to 50 active canvas collaborators simultaneously.',
        link: 'https://github.com/alexrivera-codex/collab-canvas'
      }
    ],
    skills: {
      technical: ['TypeScript', 'JavaScript', 'Node.js', 'Python', 'PostgreSQL', 'Redis', 'Docker', 'AWS', 'GraphQL', 'REST APIs'],
      soft: ['Cross-functional Leadership', 'Agile/Scrum', 'Technical Mentorship', 'System Architecture', 'Problem Solving'],
      tools: ['Docker', 'Git', 'AWS ECS', 'Postman', 'Jira', 'Figma', 'Datadog'],
      frameworks: ['React', 'Next.js', 'Express', 'Tailwind CSS', 'Prisma', 'Jest'],
      languages: ['TypeScript', 'JavaScript', 'Python', 'SQL', 'Bash', 'HTML5', 'CSS3']
    },
    certifications: [
      'AWS Certified Solutions Architect – Associate (SAA-C03)',
      'Meta Professional Frontend Developer Certification'
    ],
    achievements: [
      'Hackathon 1st Place Champion - Global FinTech Hackathon 2023',
      'Author of open-source TypeScript caching utility with 2,400+ GitHub stars'
    ],
    extracurricular: [
      'Lead Mentor for underrepresented youth in tech at CodeForward SF',
      'Regular speaker on Web Performance & Distributed Systems at SF Bay Meetups'
    ],
    rawText: `Alex Rivera\nSenior Full Stack Engineer\nSan Francisco, CA • alex.rivera@codex404.dev • +1 (415) 555-0198\nLinkedIn: linkedin.com/in/alex-rivera-dev • GitHub: github.com/alexrivera-codex\n\nPROFESSIONAL SUMMARY\nSenior Full Stack Engineer with 5+ years of experience designing high-throughput web applications, microservices, and distributed cloud systems. Skilled in TypeScript, React, Node.js, and AWS with a track record of driving 40%+ performance gains.\n\nEXPERIENCE\nSenior Full Stack Engineer | Vanguard Cloud Systems (2022 - Present)\n- Architected and led the development of a real-time event ingestion engine processing 1.5M transactions daily with 99.99% uptime.\n- Reduced web application p95 response latency by 38% through Redis tier caching and PostgreSQL query optimization.\n- Spearheaded CI/CD migration to GitHub Actions & AWS ECS, cutting deployment duration from 45 to 6 minutes.\n\nFull Stack Software Engineer | Apex Data Labs (2020 - 2022)\n- Engineered customer-facing analytics dashboards using React, TypeScript, and Tailwind CSS serving 80,000+ monthly active enterprise users.\n- Developed microservice REST APIs in Node.js and Express with automated Jest test suites achieving 89% code coverage.\n\nEDUCATION\nUniversity of California, Berkeley\nB.S. in Computer Science & Applied Mathematics | 2017 - 2021 | GPA: 3.86/4.0`
  },
  strengths: [
    'Outstanding technical breadth: 16+ industry keywords across modern TypeScript, React, Node.js, and AWS ecosystems.',
    'Quantifiable engineering impact: 6 distinct business metrics including 1.5M transactions daily, 38% p95 latency reduction, and 45 to 6 min deployment acceleration.',
    'Robust structural chronology: Clear career progression from Software Engineer to Senior Engineer with consistent bullet point syntax.',
    'Parser-friendly format: Single-column clean hierarchy, standard section titles, and zero problematic multi-column tables.'
  ],
  weaknesses: [
    'Cloud infrastructure tools could feature Kubernetes, Terraform, and Observability (Datadog/OpenTelemetry) more explicitly for Staff-level roles.',
    'Certain early career bullets could emphasize product-level revenue or customer conversion outcomes alongside raw technical metrics.',
    'Summary section can be dynamically tuned to highlight technical leadership and cross-functional team scaling.'
  ],
  recommendations: [
    {
      id: 'rec-1',
      priority: 'HIGH',
      category: 'Impact',
      problem: 'Apex Data Labs experience bullets could demonstrate dollar impact or business conversion rate metrics.',
      whyItMatters: 'Hiring managers at Tier-1 companies prioritize engineers who connect technical features to bottom-line business ROI.',
      suggestedImprovement: 'Quantify customer retention or revenue attributed to the 80,000 MAU enterprise analytics dashboard.',
      beforeExample: 'Engineered customer-facing analytics dashboards using React and TypeScript serving 80,000+ monthly active enterprise users.',
      afterExample: 'Engineered enterprise analytics dashboard serving 80,000+ MAU, directly driving a 22% increase in quarterly upsell retention ($1.4M ARR impact).'
    },
    {
      id: 'rec-2',
      priority: 'MEDIUM',
      category: 'Keywords',
      problem: 'DevOps & infrastructure keywords (Terraform, Kubernetes, Helm) are absent from the formal skills inventory.',
      whyItMatters: 'Senior engineering screening filters prioritize Infrastructure-as-Code (IaC) and container orchestration competencies.',
      suggestedImprovement: 'Add a "Cloud & Infrastructure" skill sub-category explicitly citing Terraform, Docker, and Kubernetes.',
      beforeExample: 'Tools: Docker, Git, AWS ECS, Postman',
      afterExample: 'Cloud & Infrastructure: Docker, Kubernetes, Terraform, AWS (ECS, S3, RDS, CloudWatch), CI/CD'
    },
    {
      id: 'rec-3',
      priority: 'LOW',
      category: 'Structure',
      problem: 'Summary is standard and doesn’t immediately emphasize domain leadership or architecture philosophy.',
      whyItMatters: 'Recruiters spend an average of 6.2 seconds on initial resume triage before deciding on a phone screen.',
      suggestedImprovement: 'Open with a specialized value proposition tailored specifically to high-scale Distributed Systems.',
      beforeExample: 'Senior Full Stack Engineer with 5+ years of experience designing web applications...',
      afterExample: 'Principal-track Full Stack Software Architect with 5+ years specializing in distributed systems, event-driven streaming pipelines, and sub-second web platforms.'
    }
  ],
  skillsBreakdown: [
    {
      name: 'Frontend & UI Engineering',
      skills: [
        { name: 'React 19 / Next.js', level: 95, category: 'Frameworks', verifiedInResume: true },
        { name: 'TypeScript', level: 94, category: 'Languages', verifiedInResume: true },
        { name: 'Tailwind CSS', level: 90, category: 'Frameworks', verifiedInResume: true },
        { name: 'WebSockets & Real-Time Sync', level: 86, category: 'Technical', verifiedInResume: true }
      ]
    },
    {
      name: 'Backend & Cloud Infrastructure',
      skills: [
        { name: 'Node.js / Express', level: 92, category: 'Frameworks', verifiedInResume: true },
        { name: 'PostgreSQL & Query Tuning', level: 88, category: 'Technical', verifiedInResume: true },
        { name: 'Redis Cache Topology', level: 85, category: 'Tools', verifiedInResume: true },
        { name: 'AWS & Docker', level: 82, category: 'Tools', verifiedInResume: true }
      ]
    },
    {
      name: 'Architecture & DevOps',
      skills: [
        { name: 'Microservices & REST APIs', level: 91, category: 'Technical', verifiedInResume: true },
        { name: 'CI/CD Automation (GitHub Actions)', level: 88, category: 'Tools', verifiedInResume: true },
        { name: 'System Design & Scalability', level: 85, category: 'Technical', verifiedInResume: true },
        { name: 'Jest & Automated Testing', level: 84, category: 'Tools', verifiedInResume: true }
      ]
    }
  ],
  missingRecommendedSkills: [
    {
      role: 'Staff / Principal Software Engineer',
      skills: ['Terraform (IaC)', 'Kubernetes Cluster Management', 'OpenTelemetry / Datadog APM', 'Domain-Driven Design', 'Kafka Partitioning']
    },
    {
      role: 'Cloud Solutions Architect',
      skills: ['Multi-Region Failover Architecture', 'SOC2 / HIPAA Compliance', 'FinOps Cloud Cost Optimization', 'Serverless EventBridge']
    }
  ],
  jobRoleRecommendations: [
    {
      id: 'role-1',
      role: 'Senior Full Stack Software Engineer',
      matchPercentage: 94,
      description: 'Lead architecture and end-to-end delivery of customer-facing products, scalable APIs, and distributed microservices.',
      requiredSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'AWS', 'Docker'],
      matchingSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'AWS', 'Docker'],
      missingSkills: ['Kubernetes Helm'],
      salaryRange: '$155,000 - $195,000',
      demandLevel: 'Very High'
    },
    {
      id: 'role-2',
      role: 'Lead Frontend / Web Platform Engineer',
      matchPercentage: 92,
      description: 'Oversee web architecture, design system implementation, performance budgets, and developer experience tooling.',
      requiredSkills: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Performance Optimization', 'Design Systems'],
      matchingSkills: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Performance Optimization'],
      missingSkills: ['Micro-Frontends Architecture'],
      salaryRange: '$150,000 - $185,000',
      demandLevel: 'High'
    },
    {
      id: 'role-3',
      role: 'Backend Distributed Systems Engineer',
      matchPercentage: 86,
      description: 'Develop low-latency distributed databases, caching architectures, and resilient async queue processing engines.',
      requiredSkills: ['Node.js', 'Python', 'Redis', 'PostgreSQL', 'Distributed Systems', 'Kafka'],
      matchingSkills: ['Node.js', 'Redis', 'PostgreSQL', 'Distributed Systems'],
      missingSkills: ['Apache Kafka', 'gRPC / Protocol Buffers'],
      salaryRange: '$160,000 - $205,000',
      demandLevel: 'High'
    },
    {
      id: 'role-4',
      role: 'DevOps & Cloud Platform Associate',
      matchPercentage: 78,
      description: 'Maintain containerized deployments, automated infrastructure pipelines, and observability monitoring systems.',
      requiredSkills: ['Docker', 'Kubernetes', 'AWS', 'Terraform', 'CI/CD', 'Linux'],
      matchingSkills: ['Docker', 'AWS', 'CI/CD', 'Linux'],
      missingSkills: ['Terraform IaC', 'Kubernetes Clusters'],
      salaryRange: '$140,000 - $175,000',
      demandLevel: 'Moderate'
    }
  ],
  atsChecks: [
    {
      id: 'contact_info',
      title: 'Contact Information Completeness',
      status: 'passed',
      description: 'All 6 critical contact attributes detected cleanly in top header (Name, Email, Phone, Location, LinkedIn, GitHub).',
      scoreImpact: 0,
      recommendation: 'Header is optimal for applicant tracking system field mapping.'
    },
    {
      id: 'standard_headings',
      title: 'Standard Heading Recognition',
      status: 'passed',
      description: 'Sections strictly use canonical industry labels (Experience, Education, Skills, Projects, Summary).',
      scoreImpact: 0,
      recommendation: 'Unanimously supported by Taleo, Greenhouse, and Workday parsing dictionaries.'
    },
    {
      id: 'action_verbs',
      title: 'Active Power Verb Density',
      status: 'passed',
      description: 'Identified 8 high-impact action verbs (Architected, Spearheaded, Engineered, Reduced, Collaborated, Built, Developed).',
      scoreImpact: 0,
      recommendation: 'Active voice strengthens evaluation across both AI scanners and hiring committees.'
    },
    {
      id: 'quantifiable_metrics',
      title: 'Quantified Achievement Ratios',
      status: 'passed',
      description: 'Detected 6 concrete numeric performance benchmarks (1.5M transactions, 38% latency drop, 45 to 6 min deploy, 80k MAU).',
      scoreImpact: 0,
      recommendation: 'Outstanding quantification of business outcomes.'
    },
    {
      id: 'table_parsing',
      title: 'Linear Hierarchy (No Complex Tables)',
      status: 'passed',
      description: 'Clean single-column layout without nested grid columns or tabular artifacts that confuse screen readers.',
      scoreImpact: 0,
      recommendation: 'Guarantees zero scrambled text lines in parsing databases.'
    },
    {
      id: 'keyword_coverage',
      title: 'Industry Keyword Coverage',
      status: 'passed',
      description: 'Contains 18 validated tech keywords aligned with modern Senior Full Stack job postings.',
      scoreImpact: 0,
      recommendation: 'Ranks in the top 15th percentile for keyword relevance queries.'
    },
    {
      id: 'word_density',
      title: 'Resume Length & Spacing',
      status: 'passed',
      description: 'Document contains 542 words, placing it in the golden 1-page density sweet spot (450 - 650 words).',
      scoreImpact: 0,
      recommendation: 'Easy to scan within standard 6-second recruiter screen.'
    }
  ],
  atsExplanation: {
    summary: 'Alex Rivera\'s resume scored 81/100 on ATS compatibility. It demonstrates pristine structural hierarchy, zero nested tables, 6 quantifiable metrics, and comprehensive contact details. Minor point deductions stem from opportunities to incorporate Infrastructure-as-Code and distributed messaging keywords.',
    parsedWordCount: 542,
    detectedHeadings: ['Professional Summary', 'Work Experience', 'Technical Projects', 'Education', 'Technical Skills', 'Certifications'],
    quantifiableMetricsFound: 6,
    actionVerbsCount: 8,
    readabilityScore: '9th Grade (Professional Sweet Spot)'
  },
  professionalSummary: {
    original: 'Senior Full Stack Engineer with 5+ years of experience designing high-throughput web applications, microservices, and distributed cloud systems. Skilled in TypeScript, React, Node.js, and AWS with a track record of driving 40%+ performance gains.',
    tones: {
      Professional: 'Results-driven Senior Full Stack Engineer with 5+ years architecting high-throughput web platforms and distributed cloud systems. Proven record of driving a 38% latency drop for 1.5M daily users and scaling engineering team velocity via automated CI/CD pipelines.',
      Technical: 'Systems-focused Full Stack Architect specializing in TypeScript, React, Node.js, and PostgreSQL. Expert in optimizing event-driven architectures, Redis cache topologies, and database indexing to consistently satisfy sub-100ms p95 SLAs at enterprise scale.',
      Concise: 'Senior Full Stack Engineer with 5+ years scaling distributed web systems across React, Node.js, and AWS. Proven track record delivering 38% latency cuts and managing 1.5M+ daily event pipelines.',
      'Recruiter-Friendly': 'Dynamic and collaborative Senior Engineer who bridges product vision and robust engineering execution. Passionate about mentoring developers, elevating code quality, and building resilient web products in React, TypeScript, and Node.js.'
    },
    currentTone: 'Professional'
  }
};

// ----------------------------------------------------
// PERSISTENT DATABASE ENGINE
// ----------------------------------------------------
let store: DBStore = {
  users: {},
  tokens: {},
  resumes: {},
  analyses: {},
  jobMatches: {}
};

function saveToDisk(): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('[DB] Error persisting database to disk:', err);
  }
}

function initializeDefaultSeed(): void {
  // 1. Seed Demo User
  const demoUser: StoredUser = {
    id: DEMO_USER_ID,
    name: 'Alex Rivera',
    email: 'alex.rivera@codex404.dev',
    passwordHash: hashPassword('password123'),
    targetRole: 'Senior Full Stack Software Engineer',
    experienceLevel: 'Senior',
    preferredIndustry: 'Cloud Software & AI SaaS',
    skills: ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Docker', 'AWS', 'Next.js', 'Redis'],
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    lastLoginAt: new Date().toISOString(),
    preferences: {
      theme: 'dark',
      emailNotifications: true,
      atsAutoEnhance: true
    }
  };
  store.users[demoUser.id] = demoUser;

  // 2. Seed Demo Session Token
  const demoToken = 'token_user_demo_404codex';
  store.tokens[demoToken] = {
    userId: DEMO_USER_ID,
    createdAt: new Date().toISOString()
  };

  // 3. Seed Demo Resume file on disk
  const userUploadDir = path.join(UPLOADS_DIR, DEMO_USER_ID);
  if (!fs.existsSync(userUploadDir)) {
    fs.mkdirSync(userUploadDir, { recursive: true });
  }
  const demoResumePath = path.join(userUploadDir, `${DEMO_RESUME_ID}_Alex_Rivera_Senior_FullStack_Resume.txt`);
  if (!fs.existsSync(demoResumePath)) {
    fs.writeFileSync(demoResumePath, SAMPLE_DEMO_ANALYSIS.parsedData.rawText, 'utf-8');
  }

  // 4. Seed Demo Resume Record
  const demoResume: StoredResume = {
    id: DEMO_RESUME_ID,
    userId: DEMO_USER_ID,
    fileName: 'Alex_Rivera_Senior_FullStack_Resume.pdf',
    fileType: 'application/pdf',
    fileSize: 142800,
    storagePath: path.relative(process.cwd(), demoResumePath),
    fileUrl: `/api/resume/${DEMO_RESUME_ID}/file`,
    uploadedAt: SAMPLE_DEMO_ANALYSIS.uploadedAt,
    rawText: SAMPLE_DEMO_ANALYSIS.parsedData.rawText,
    parsedData: SAMPLE_DEMO_ANALYSIS.parsedData,
    latestAnalysisId: DEMO_ANALYSIS_ID,
    isDemo: true
  };
  store.resumes[demoResume.id] = demoResume;

  // 5. Seed Demo Analysis Record
  const demoAnalysis: StoredAnalysis = {
    id: DEMO_ANALYSIS_ID,
    userId: DEMO_USER_ID,
    resumeId: DEMO_RESUME_ID,
    score: SAMPLE_DEMO_ANALYSIS.scores.overall,
    atsScore: SAMPLE_DEMO_ANALYSIS.scores.atsCompatibility,
    skills: SAMPLE_DEMO_ANALYSIS.skillsBreakdown,
    missingSkills: SAMPLE_DEMO_ANALYSIS.missingRecommendedSkills,
    strengths: SAMPLE_DEMO_ANALYSIS.strengths,
    weaknesses: SAMPLE_DEMO_ANALYSIS.weaknesses,
    recommendations: SAMPLE_DEMO_ANALYSIS.recommendations,
    jobRoleRecommendations: SAMPLE_DEMO_ANALYSIS.jobRoleRecommendations,
    atsChecks: SAMPLE_DEMO_ANALYSIS.atsChecks,
    atsExplanation: SAMPLE_DEMO_ANALYSIS.atsExplanation,
    professionalSummary: SAMPLE_DEMO_ANALYSIS.professionalSummary,
    analyzedAt: SAMPLE_DEMO_ANALYSIS.uploadedAt,
    fullAnalysis: SAMPLE_DEMO_ANALYSIS
  };
  store.analyses[demoAnalysis.id] = demoAnalysis;

  saveToDisk();
}

function loadFromDisk(): void {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      if (parsed && typeof parsed === 'object' && parsed.users) {
        store = {
          users: parsed.users || {},
          tokens: parsed.tokens || {},
          resumes: parsed.resumes || {},
          analyses: parsed.analyses || {},
          jobMatches: parsed.jobMatches || {}
        };

        // Ensure demo user is present
        if (!store.users[DEMO_USER_ID]) {
          initializeDefaultSeed();
        }
        return;
      }
    } catch (err) {
      console.warn('[DB] Failed to parse database.json, initializing fresh store:', err);
    }
  }

  // File does not exist, initialize seed
  initializeDefaultSeed();
}

// Initialize on module load
loadFromDisk();

// ----------------------------------------------------
// CRYPTO & SECURITY UTILITIES
// ----------------------------------------------------
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash) return false;

  // Support demo passwords
  if (storedHash === 'demo_hashed_password' || storedHash.startsWith('hash_')) {
    if (
      password === 'demo_password' ||
      password === 'demo' ||
      password === 'password123' ||
      password === '123456' ||
      storedHash === 'hash_' + password
    ) {
      return true;
    }
  }

  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, key] = parts;
  try {
    const testKey = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(Buffer.from(key, 'hex'), testKey);
  } catch {
    return false;
  }
}

// ----------------------------------------------------
// DATABASE API IMPLEMENTATION
// ----------------------------------------------------
export const db = {
  // User Operations
  getUserByEmail(email: string): StoredUser | null {
    const cleanEmail = email.toLowerCase().trim();
    for (const user of Object.values(store.users)) {
      if (user.email.toLowerCase() === cleanEmail) {
        return user;
      }
    }
    return null;
  },

  getUserById(id: string): StoredUser | null {
    return store.users[id] || null;
  },

  getUserByToken(token: string): StoredUser | null {
    if (!token) return null;
    const cleanToken = token.trim();

    // Check tokens collection
    if (store.tokens[cleanToken]) {
      const userId = store.tokens[cleanToken].userId;
      return store.users[userId] || null;
    }

    // Support legacy format 'token_user_...'
    if (cleanToken.startsWith('token_user_')) {
      const rawUserId = cleanToken.replace('token_', '');
      if (store.users[rawUserId]) {
        return store.users[rawUserId];
      }
    }

    return null;
  },

  createUser(
    name: string,
    email: string,
    plainPassword: string,
    targetRole?: string,
    experienceLevel?: 'Entry' | 'Mid' | 'Senior' | 'Lead' | 'Executive'
  ): { user: User; token: string } {
    const cleanEmail = email.toLowerCase().trim();
    if (this.getUserByEmail(cleanEmail)) {
      throw new Error('An account with this email address already exists. Please log in.');
    }

    const userId = 'usr_' + Date.now().toString(36) + '_' + crypto.randomBytes(4).toString('hex');
    const passwordHash = hashPassword(plainPassword);

    const newUser: StoredUser = {
      id: userId,
      name: name.trim(),
      email: cleanEmail,
      targetRole: targetRole?.trim() || 'Software Engineer',
      experienceLevel: experienceLevel || 'Mid',
      preferredIndustry: 'Technology',
      skills: ['TypeScript', 'React', 'Node.js'],
      passwordHash,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      preferences: {
        theme: 'dark',
        emailNotifications: true,
        atsAutoEnhance: true
      }
    };

    store.users[userId] = newUser;

    // Generate secure 256-bit session token
    const token = 'tok_' + crypto.randomBytes(32).toString('hex');
    store.tokens[token] = {
      userId,
      createdAt: new Date().toISOString()
    };

    saveToDisk();

    const { passwordHash: _, ...safeUser } = newUser;
    return { user: safeUser, token };
  },

  createSession(userId: string): string {
    const token = 'tok_' + crypto.randomBytes(32).toString('hex');
    store.tokens[token] = {
      userId,
      createdAt: new Date().toISOString()
    };

    if (store.users[userId]) {
      store.users[userId].lastLoginAt = new Date().toISOString();
    }

    saveToDisk();
    return token;
  },

  revokeSession(token: string): boolean {
    if (store.tokens[token]) {
      delete store.tokens[token];
      saveToDisk();
      return true;
    }
    return false;
  },

  resetUserPassword(email: string, newPlainPassword: string): boolean {
    const user = this.getUserByEmail(email);
    if (!user) return false;
    user.passwordHash = hashPassword(newPlainPassword);
    saveToDisk();
    return true;
  },

  updateUserProfile(id: string, updates: Partial<StoredUser>): User {
    const target = store.users[id];
    if (!target) throw new Error('User not found');

    if (updates.name) target.name = updates.name.trim();
    if (updates.targetRole) target.targetRole = updates.targetRole.trim();
    if (updates.experienceLevel) target.experienceLevel = updates.experienceLevel;
    if (updates.preferredIndustry) target.preferredIndustry = updates.preferredIndustry.trim();
    if (updates.skills) target.skills = updates.skills;
    if (updates.bio !== undefined) target.bio = updates.bio;
    if (updates.phone !== undefined) target.phone = updates.phone;
    if (updates.location !== undefined) target.location = updates.location;
    if (updates.preferences) {
      target.preferences = { ...target.preferences, ...updates.preferences };
    }

    saveToDisk();
    const { passwordHash: _, ...safeUser } = target;
    return safeUser;
  },

  // ----------------------------------------------------
  // RESUME STORAGE & FILE MANAGEMENT
  // ----------------------------------------------------
  saveUploadedResume(
    userId: string,
    data: {
      fileName: string;
      fileType: string;
      fileSize: number;
      fileBuffer?: Buffer;
      rawText: string;
      parsedData: ParsedResumeData;
    }
  ): StoredResume {
    const resumeId = 'res_' + Date.now().toString(36) + '_' + crypto.randomBytes(4).toString('hex');

    // Create user-partitioned upload directory
    const userDir = path.join(UPLOADS_DIR, userId);
    if (!fs.existsSync(userDir)) {
      fs.mkdirSync(userDir, { recursive: true });
    }

    // Save actual file on disk
    const safeName = data.fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const diskFileName = `${resumeId}_${safeName}`;
    const fullDiskPath = path.join(userDir, diskFileName);

    if (data.fileBuffer) {
      fs.writeFileSync(fullDiskPath, data.fileBuffer);
    } else {
      // If uploaded as text, write txt file
      fs.writeFileSync(fullDiskPath, data.rawText, 'utf-8');
    }

    const relativeStoragePath = path.relative(process.cwd(), fullDiskPath);

    const storedResume: StoredResume = {
      id: resumeId,
      userId,
      fileName: data.fileName,
      fileType: data.fileType || 'application/pdf',
      fileSize: data.fileSize || data.rawText.length,
      storagePath: relativeStoragePath,
      fileUrl: `/api/resume/${resumeId}/file`,
      uploadedAt: new Date().toISOString(),
      rawText: data.rawText,
      parsedData: data.parsedData
    };

    store.resumes[resumeId] = storedResume;
    saveToDisk();
    return storedResume;
  },

  getResumeFile(resumeId: string, userId: string): { fullPath: string; fileName: string; fileType: string; fileSize: number } | null {
    const resume = store.resumes[resumeId];
    if (!resume) return null;

    // Security Check: enforce user-isolation
    if (resume.userId !== userId && !resume.isDemo) {
      return null;
    }

    const fullPath = path.resolve(process.cwd(), resume.storagePath);
    if (!fs.existsSync(fullPath)) return null;

    const stats = fs.statSync(fullPath);
    return {
      fullPath,
      fileName: resume.fileName,
      fileType: resume.fileType,
      fileSize: stats.size
    };
  },

  getResumeById(id: string, userId: string): { resume: StoredResume; analysis?: ResumeAnalysis } | null {
    const resume = store.resumes[id];
    if (!resume) return null;

    // Security check: Only allow access to own resumes or public demo
    if (resume.userId !== userId && !resume.isDemo) {
      return null;
    }

    let analysis: ResumeAnalysis | undefined;
    if (resume.latestAnalysisId && store.analyses[resume.latestAnalysisId]) {
      analysis = store.analyses[resume.latestAnalysisId].fullAnalysis;
    }

    return { resume, analysis };
  },

  getResumesByUser(userId: string): ResumeAnalysis[] {
    const userResumes = Object.values(store.resumes).filter(
      (r) => r.userId === userId || (userId === DEMO_USER_ID && r.isDemo)
    );

    // Return combined ResumeAnalysis objects for all user resumes
    const results: ResumeAnalysis[] = [];

    for (const r of userResumes) {
      if (r.latestAnalysisId && store.analyses[r.latestAnalysisId]) {
        results.push(store.analyses[r.latestAnalysisId].fullAnalysis);
      } else {
        // Construct analysis skeleton if not yet analyzed
        results.push({
          id: 'anl_' + r.id,
          resumeId: r.id,
          resumeFileName: r.fileName,
          fileSize: r.fileSize,
          uploadedAt: r.uploadedAt,
          isDemo: r.isDemo,
          scores: {
            overall: 70,
            atsCompatibility: 70,
            skills: 70,
            experience: 70,
            projects: 70,
            education: 70,
            formatting: 70,
            keywords: 70
          },
          parsedData: r.parsedData,
          strengths: ['Uploaded document received and parsed successfully.'],
          weaknesses: ['Awaiting comprehensive AI analysis.'],
          recommendations: [],
          skillsBreakdown: [],
          missingRecommendedSkills: [],
          jobRoleRecommendations: [],
          atsChecks: [],
          atsExplanation: {
            summary: 'Resume parsed. Click "Analyze Resume" to generate full ATS telemetry.',
            parsedWordCount: r.rawText.split(/\s+/).length,
            detectedHeadings: [],
            quantifiableMetricsFound: 0,
            actionVerbsCount: 0,
            readabilityScore: 'Standard'
          },
          professionalSummary: {
            original: r.parsedData?.summary || '',
            tones: {
              Professional: r.parsedData?.summary || '',
              Technical: r.parsedData?.summary || '',
              Concise: r.parsedData?.summary || '',
              'Recruiter-Friendly': r.parsedData?.summary || ''
            },
            currentTone: 'Professional'
          }
        });
      }
    }

    return results.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
  },

  saveResumeAnalysis(analysis: ResumeAnalysis, userId: string): StoredAnalysis {
    const analysisId = analysis.id || 'anl_' + Date.now().toString(36) + '_' + crypto.randomBytes(4).toString('hex');
    const resumeId = analysis.resumeId;

    const storedAnalysis: StoredAnalysis = {
      id: analysisId,
      userId,
      resumeId,
      score: analysis.scores.overall,
      atsScore: analysis.scores.atsCompatibility,
      skills: analysis.skillsBreakdown,
      missingSkills: analysis.missingRecommendedSkills,
      strengths: analysis.strengths,
      weaknesses: analysis.weaknesses,
      recommendations: analysis.recommendations,
      jobRoleRecommendations: analysis.jobRoleRecommendations,
      atsChecks: analysis.atsChecks,
      atsExplanation: analysis.atsExplanation,
      professionalSummary: analysis.professionalSummary,
      analyzedAt: new Date().toISOString(),
      fullAnalysis: { ...analysis, id: analysisId, resumeId }
    };

    store.analyses[analysisId] = storedAnalysis;

    // Link in resume
    if (store.resumes[resumeId]) {
      store.resumes[resumeId].latestAnalysisId = analysisId;
    }

    saveToDisk();
    return storedAnalysis;
  },

  getResumeAnalysis(id: string, userId: string): ResumeAnalysis | undefined {
    // Check by analysis id
    if (store.analyses[id]) {
      const a = store.analyses[id];
      if (a.userId === userId || a.userId === DEMO_USER_ID) {
        return a.fullAnalysis;
      }
    }

    // Check by resume id
    for (const a of Object.values(store.analyses)) {
      if (a.resumeId === id && (a.userId === userId || a.userId === DEMO_USER_ID)) {
        return a.fullAnalysis;
      }
    }

    return undefined;
  },

  deleteResume(id: string, userId: string): boolean {
    const resume = store.resumes[id];
    if (!resume) return false;

    // Security authorization: Cannot delete another user's resume
    if (resume.userId !== userId) {
      throw new Error('Unauthorized: You can only delete your own resumes.');
    }

    // Remove file from disk
    try {
      const fullPath = path.resolve(process.cwd(), resume.storagePath);
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
    } catch (err) {
      console.warn('[DB] Could not delete physical file:', err);
    }

    // Delete associated analyses
    for (const [aId, a] of Object.entries(store.analyses)) {
      if (a.resumeId === id) {
        delete store.analyses[aId];
      }
    }

    // Delete associated job matches
    for (const [mId, m] of Object.entries(store.jobMatches)) {
      if (m.resumeId === id) {
        delete store.jobMatches[mId];
      }
    }

    delete store.resumes[id];
    saveToDisk();
    return true;
  },

  saveJobMatch(match: JobMatchResult, userId: string): JobMatchResult {
    store.jobMatches[match.id] = { ...match, userId };
    saveToDisk();
    return match;
  },

  getJobMatch(id: string, userId: string): JobMatchResult | undefined {
    const match = store.jobMatches[id];
    if (!match) return undefined;
    if (match.userId !== userId && match.userId !== DEMO_USER_ID) {
      return undefined;
    }
    return match;
  },

  getSampleDemo(): ResumeAnalysis {
    return SAMPLE_DEMO_ANALYSIS;
  }
};
