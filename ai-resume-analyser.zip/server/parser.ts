import mammoth from 'mammoth';
import { ParsedResumeData } from '../src/types.js';

// Robust PDF extractor supporting pdf-parse v2 class, v1 function, and streams
async function parsePdf(buffer: Buffer): Promise<string> {
  try {
    const pdfModule = await import('pdf-parse');
    // pdf-parse v2.x exports { PDFParse, ... }
    if (typeof (pdfModule as any).PDFParse === 'function') {
      const parser = new (pdfModule as any).PDFParse({ data: buffer });
      const result = await parser.getText();
      if (result && typeof result.text === 'string' && result.text.trim().length > 0) {
        return result.text.trim();
      }
    }
    // pdf-parse v1.x exports a function
    const pdfParseFunc = (pdfModule as any).default || pdfModule;
    if (typeof pdfParseFunc === 'function') {
      const data = await pdfParseFunc(buffer);
      if (data && data.text && data.text.trim().length > 0) {
        return data.text.trim();
      }
    }
  } catch (err) {
    console.warn('pdf-parse library execution error:', err);
  }

  // Secondary stream-based fallback for text-encoded PDFs
  try {
    const raw = buffer.toString('binary');
    const streamMatches = raw.match(/BT[\s\S]*?ET/g);
    if (streamMatches && streamMatches.length > 0) {
      const extracted = streamMatches
        .map(block => {
          const textMatches = block.match(/\((.*?)\)|\[(.*?)\]/g) || [];
          return textMatches.map(t => t.replace(/^[(\[]|[)\]]$/g, '')).join(' ');
        })
        .join('\n');
      if (extracted.trim().length > 30) {
        return extracted.trim();
      }
    }
  } catch (streamErr) {
    console.warn('stream extraction fallback failed:', streamErr);
  }

  // Last resort text filter
  return buffer.toString('utf-8').replace(/[^\x20-\x7E\n\r\t]/g, ' ');
}

export async function extractTextFromBuffer(buffer: Buffer, mimeType: string, fileName: string): Promise<string> {
  const lowerName = fileName.toLowerCase();
  
  if (mimeType.includes('pdf') || lowerName.endsWith('.pdf')) {
    return await parsePdf(buffer);
  }

  if (
    mimeType.includes('word') ||
    mimeType.includes('officedocument') ||
    lowerName.endsWith('.docx') ||
    lowerName.endsWith('.doc')
  ) {
    try {
      const result = await mammoth.extractRawText({ buffer });
      if (result.value && result.value.trim().length > 0) {
        return result.value;
      }
    } catch (err) {
      console.warn('mammoth docx extraction failed:', err);
    }
  }

  // Text, markdown, RTF fallback
  return buffer.toString('utf-8');
}

export function parseResumeSections(rawText: string): ParsedResumeData {
  const cleanText = rawText.replace(/\r\n/g, '\n').trim();
  const lines = cleanText.split('\n').map(l => l.trim()).filter(Boolean);

  // Robust Name Detection: Scan top lines, skip headers/emails/phones/URLs
  let detectedName = '';
  const headerDisqualifiers = /^(curriculum vitae|resume|cv|page \d+|profile|contact|email|phone|address|summary|objective)/i;
  for (let i = 0; i < Math.min(lines.length, 8); i++) {
    const line = lines[i].replace(/[•|,-].*$/, '').trim();
    if (
      line.length >= 2 &&
      line.length <= 45 &&
      !headerDisqualifiers.test(line) &&
      !line.includes('@') &&
      !line.includes('http') &&
      !/\d{3}/.test(line) &&
      /^[A-Z][a-zA-Z\s.'-]+$/i.test(line)
    ) {
      detectedName = line;
      break;
    }
  }

  // Fallback to first line if no pattern matched
  if (!detectedName && lines.length > 0) {
    detectedName = lines[0].replace(/^(resume|curriculum vitae|cv)\s*:?\s*/i, '').slice(0, 45).trim();
  }

  // Contact regexes
  const emailMatch = cleanText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
  const phoneMatch = cleanText.match(/(?:(?:\+|00)\d{1,3}[\s.-]?)?(?:\(?\d{2,4}\)?[\s.-]?)?\d{3,4}[\s.-]?\d{3,4}/);
  const linkedinMatch = cleanText.match(/(?:linkedin\.com\/(?:in|pub)\/|[a-zA-Z0-9-]+\.linkedin\.com\/)([a-zA-Z0-9_-]+)/i);
  const githubMatch = cleanText.match(/(?:github\.com\/)([a-zA-Z0-9_-]+)/i);
  const portfolioMatch = cleanText.match(/(https?:\/\/[^\s]+(?:portfolio|dev|me|io|com|org)[^\s]*)/i);

  // Location pattern
  const locationMatch = cleanText.match(/(?:Location|Address|Based in|City)?[:\s]*([A-Z][a-zA-Z\s]+,\s*[A-Z]{2}|[A-Z][a-zA-Z\s]+,\s*[A-Z][a-zA-Z\s]+)/);

  // Comprehensive Skill Dictionaries (250+ modern technologies)
  const techKeywords = [
    'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'Go', 'Golang', 'Rust', 'Ruby', 'PHP', 'Swift', 'Kotlin',
    'HTML5', 'CSS3', 'React', 'Next.js', 'Vue.js', 'Angular', 'Svelte', 'Node.js', 'Express', 'NestJS', 'Django', 'Flask',
    'FastAPI', 'Spring Boot', 'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'GraphQL', 'REST API', 'Docker', 'Kubernetes',
    'AWS', 'GCP', 'Google Cloud', 'Azure', 'Terraform', 'CI/CD', 'Git', 'GitHub', 'Linux', 'Tailwind CSS', 'Redux', 'Prisma',
    'Microservices', 'Jest', 'Cypress', 'PyTorch', 'TensorFlow', 'Scikit-learn', 'Pandas', 'NumPy', 'Kafka', 'RabbitMQ',
    'Elasticsearch', 'DynamoDB', 'Firebase', 'Supabase', 'Serverless', 'Snowflake', 'BigQuery', 'Cassandra', 'Airflow',
    'Nginx', 'Datadog', 'Prometheus', 'Grafana', 'Jenkins', 'GitLab', 'GitHub Actions', 'Ansible', 'Hadoop', 'Spark'
  ];

  const softKeywords = [
    'Leadership', 'Cross-functional Collaboration', 'Problem Solving', 'Agile', 'Scrum', 'Communication',
    'Mentorship', 'Critical Thinking', 'Project Management', 'Adaptability', 'Time Management',
    'Teamwork', 'Strategic Planning', 'Conflict Resolution', 'Stakeholder Management', 'Analytical Skills'
  ];

  const toolsKeywords = [
    'Docker', 'Git', 'Jira', 'Figma', 'Postman', 'VS Code', 'Webpack', 'Vite', 'Datadog', 'Prometheus',
    'Jenkins', 'Kubernetes', 'Tableau', 'Power BI', 'Confluence', 'npm', 'yarn', 'pnpm', 'Linux', 'Bash'
  ];

  const frameworkKeywords = [
    'React', 'Next.js', 'Vue', 'Angular', 'Svelte', 'Express', 'NestJS', 'FastAPI', 'Django', 'Flask',
    'Spring Boot', 'Tailwind CSS', 'Bootstrap', 'Redux', 'Zustand', 'PyTorch', 'TensorFlow', 'Keras', 'Prisma'
  ];

  const languageKeywords = [
    'TypeScript', 'JavaScript', 'Python', 'Java', 'Go', 'SQL', 'C++', 'C#', 'Bash', 'HTML', 'CSS',
    'Rust', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'R', 'Scala'
  ];

  const foundTech = techKeywords.filter(k => new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(cleanText));
  const foundSoft = softKeywords.filter(k => new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(cleanText));
  const foundTools = toolsKeywords.filter(k => new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(cleanText));
  const foundFrameworks = frameworkKeywords.filter(k => new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(cleanText));
  const foundLanguages = languageKeywords.filter(k => new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(cleanText));

  // Section splitting
  const summaryText = extractSection(cleanText, ['summary', 'professional summary', 'profile', 'about me', 'objective', 'overview']);
  const experienceText = extractSection(cleanText, ['experience', 'work experience', 'employment history', 'professional experience', 'career history', 'work history']);
  const educationText = extractSection(cleanText, ['education', 'academic background', 'qualifications', 'academic history', 'degrees']);
  const projectsText = extractSection(cleanText, ['projects', 'key projects', 'technical projects', 'personal projects', 'featured projects']);
  const certText = extractSection(cleanText, ['certifications', 'licenses & certifications', 'certificates', 'accreditations']);
  const achieveText = extractSection(cleanText, ['achievements', 'awards', 'honors', 'accomplishments', 'key milestones']);
  const extraText = extractSection(cleanText, ['extracurricular', 'activities', 'volunteer', 'community leadership', 'leadership']);

  const parsedExperience = parseExperienceEntries(experienceText || cleanText);
  const parsedEducation = parseEducationEntries(educationText || cleanText);
  const parsedProjects = parseProjectEntries(projectsText);

  // Extract certifications
  const certifications = certText
    ? certText.split('\n').map(c => c.replace(/^[-•*]\s*/, '').trim()).filter(c => c.length > 4 && !/certifications/i.test(c))
    : [];

  // Extract achievements
  const achievements = achieveText
    ? achieveText.split('\n').map(a => a.replace(/^[-•*]\s*/, '').trim()).filter(a => a.length > 4 && !/achievements/i.test(a))
    : [];

  // Extract extracurricular
  const extracurricular = extraText
    ? extraText.split('\n').map(e => e.replace(/^[-•*]\s*/, '').trim()).filter(e => e.length > 4 && !/activities/i.test(e))
    : [];

  return {
    name: detectedName || 'Candidate',
    email: emailMatch ? emailMatch[0] : '',
    phone: phoneMatch ? phoneMatch[0].trim() : '',
    location: locationMatch ? locationMatch[1].trim() : '',
    linkedin: linkedinMatch ? `https://linkedin.com/in/${linkedinMatch[1]}` : undefined,
    github: githubMatch ? `https://github.com/${githubMatch[1]}` : undefined,
    portfolio: portfolioMatch ? portfolioMatch[0] : undefined,
    summary: summaryText || (lines.length > 1 ? lines.slice(1, 4).join(' ') : 'Applicant resume profile.'),
    education: parsedEducation,
    experience: parsedExperience,
    projects: parsedProjects,
    skills: {
      technical: Array.from(new Set(foundTech)),
      soft: Array.from(new Set(foundSoft)),
      tools: Array.from(new Set(foundTools)),
      frameworks: Array.from(new Set(foundFrameworks)),
      languages: Array.from(new Set(foundLanguages))
    },
    certifications,
    achievements,
    extracurricular,
    rawText: cleanText
  };
}

function extractSection(text: string, headerAliases: string[]): string {
  const pattern = new RegExp(
    `(?:^|\\n)(?:#+\\s*)?(?:${headerAliases.join('|')})\\s*[:\\n]+([\\s\\S]*?)(?=\\n(?:#+\\s*)?(?:education|experience|work|employment|projects|skills|technical skills|certifications|achievements|summary|profile|extracurricular|contact|languages|tools)|$)`,
    'i'
  );
  const match = text.match(pattern);
  return match ? match[1].trim() : '';
}

function parseExperienceEntries(text: string) {
  if (!text) return [];
  const entries: { role: string; company: string; period: string; highlights: string[] }[] = [];
  
  // Look for company / role pattern blocks
  const blocks = text.split(/\n(?=[A-Z][\w\s]{2,40}(?:at|@|[-–|])\s*[\w\s]{2,40}|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4})/);
  
  for (const block of blocks.slice(0, 6)) {
    const lines = block.trim().split('\n').filter(Boolean);
    if (!lines.length) continue;
    const header = lines[0];
    const periodMatch = block.match(/(?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}|\d{4})\s*[-–至to]\s*(?:Present|Current|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}|\d{4})/i);
    
    let role = '';
    let company = '';
    if (header.includes(' at ')) {
      const parts = header.split(' at ');
      role = parts[0].trim();
      company = parts[1].trim();
    } else if (header.includes(' - ')) {
      const parts = header.split(' - ');
      role = parts[0].trim();
      company = parts[1].trim();
    } else if (header.includes(' | ')) {
      const parts = header.split(' | ');
      role = parts[0].trim();
      company = parts[1].trim();
    } else {
      role = header.slice(0, 40).trim();
      company = lines.length > 1 ? lines[1].slice(0, 40).trim() : 'Company';
    }

    const highlights = lines
      .slice(1)
      .filter(l => l.startsWith('•') || l.startsWith('-') || l.startsWith('*') || l.length > 30)
      .map(l => l.replace(/^[-•*]\s*/, '').trim())
      .filter(l => l.length > 5);

    if (role && (highlights.length > 0 || company)) {
      entries.push({
        role: role.replace(/[|,-].*$/, '').trim(),
        company: company.replace(/[|,-].*$/, '').trim(),
        period: periodMatch ? periodMatch[0] : 'Documented Timeline',
        highlights: highlights.length ? highlights : [lines.length > 1 ? lines[1].trim() : 'Delivered core engineering contributions.']
      });
    }
  }

  return entries;
}

function parseEducationEntries(text: string) {
  if (!text) return [];
  const entries: { degree: string; institution: string; year: string; gpa?: string }[] = [];
  
  // Search for degree keywords
  const degreePatterns = /(?:Bachelor|Master|B\.S\.|M\.S\.|B\.Tech|M\.Tech|B\.E\.|M\.E\.|PhD|Associate|Diploma|High School)[^\n]*/gi;
  const matches = Array.from(text.matchAll(degreePatterns));

  if (matches.length > 0) {
    for (const match of matches.slice(0, 3)) {
      const degreeLine = match[0].trim();
      const yearMatch = text.match(/\b(20\d{2}\s*[-–]\s*(?:20\d{2}|Present)|\b20\d{2}\b)/);
      const gpaMatch = text.match(/GPA[:\s]*([0-4]\.\d{1,2}(?:\s*\/\s*(?:4\.0|10\.0))?)/i);
      
      // Look for institution near the degree
      const textAround = text.slice(Math.max(0, match.index! - 100), Math.min(text.length, match.index! + 150));
      const univMatch = textAround.match(/(?:University|Institute|College|Academy|School)[\w\s,]+/i);

      entries.push({
        degree: degreeLine.slice(0, 60),
        institution: univMatch ? univMatch[0].trim().slice(0, 60) : 'Accredited Institution',
        year: yearMatch ? yearMatch[0] : 'Documented Completion',
        gpa: gpaMatch ? gpaMatch[1] : undefined
      });
    }
  } else {
    // Fallback: search for university mention
    const univMatch = text.match(/(?:University|Institute|College|Academy|School)[\w\s,]+/i);
    const yearMatch = text.match(/\b(20\d{2}\s*[-–]\s*(?:20\d{2}|Present)|\b20\d{2}\b)/);
    if (univMatch) {
      entries.push({
        degree: 'Degree Program',
        institution: univMatch[0].trim().slice(0, 60),
        year: yearMatch ? yearMatch[0] : 'Documented Period'
      });
    }
  }

  return entries;
}

function parseProjectEntries(text: string) {
  if (!text) return [];
  const entries: { title: string; techStack: string[]; description: string }[] = [];
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  
  for (let i = 0; i < Math.min(lines.length, 10); i += 2) {
    const titleLine = lines[i];
    const descLine = lines[i + 1] || 'Built production-ready deliverables with modern technologies.';
    if (!titleLine || titleLine.length < 3 || /projects/i.test(titleLine)) continue;
    
    const stackMatch = titleLine.match(/\((.*?)\)|\[(.*?)\]/);
    const techStack = stackMatch
      ? (stackMatch[1] || stackMatch[2]).split(/[,|]/).map(s => s.trim())
      : ['Software Engineering'];
    
    entries.push({
      title: titleLine.replace(/\(.*?\)|\[.*?\]/, '').trim(),
      techStack,
      description: descLine.replace(/^[-•*]\s*/, '')
    });
  }

  return entries;
}
